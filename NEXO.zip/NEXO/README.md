# NEXO

Plataforma de agente de IA pessoal para Android. O **Alfredo** é o primeiro agente que vive nela.

- Conecta qualquer IA (grátis ou paga) com troca automática quando uma falha.
- Agente com loop **Observar → Pensar → Agir → Avaliar**, que para depois de 2 falhas seguidas.
- Regras em `AGENTS.md`, aprendizado em `MEMORY.md`, lidos a cada mensagem.
- Ferramentas do dia a dia, Skills, Rotinas automáticas, conectores MCP e voz com reserva.

## Estrutura

```
NEXO/
├── .github/workflows/build.yml   compila e publica o APK em Lançamentos
├── keystore/nexo.jks             chave fixa (versões novas instalam por cima)
├── docs/                         ARQUITETURA, STATUS, INSTALAR
└── app/src/main/
    ├── assets/                   AGENTS.md, MEMORY.md e skills iniciais
    └── java/com/jeconias/nexo/
        ├── core/        Container, Settings, Notificações, Registro de ações
        ├── agent/       Loop do agente
        ├── context/     AGENTS.md, MEMORY.md e Skills
        ├── providers/   IAs + roteador com fallback
        ├── tools/       Ferramentas (builtin/) e registro
        ├── mcp/         Cliente MCP por HTTP
        ├── voice/       Gemini, ElevenLabs e voz do celular
        ├── scheduler/   Lembretes e rotinas (WorkManager)
        ├── service/     Modo 24/7 e reinício com o celular
        └── ui/          Telas (Conversa, IAs, Voz, Cérebro, Sistema)
```

Veja `docs/INSTALAR.md` para colocar no celular e `docs/STATUS.md` para o que funciona.
