# MEMORY.md — O que o Alfredo aprendeu

Fatos, correções e preferências, organizados por assunto. O Alfredo acrescenta linhas
com a ferramenta `lembrar` e revisa tudo uma vez por semana (a versão anterior fica guardada).
Você pode editar ou apagar qualquer linha na aba Cérebro.

## Pessoas

## Preferências

## Lugares

## Rotina

## Finanças

## Regras

## Outros
