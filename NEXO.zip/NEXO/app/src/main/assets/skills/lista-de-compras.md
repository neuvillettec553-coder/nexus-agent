# Lista de compras — adiciona, remove e lê itens da lista

1. Use `listar_notas` e procure a nota "lista de compras".
2. Para adicionar ou remover, monte a lista completa atualizada (um item por linha).
3. Salve com `salvar_nota`, título "lista de compras".
4. Confirme em uma frase o que mudou e quantos itens a lista tem.
