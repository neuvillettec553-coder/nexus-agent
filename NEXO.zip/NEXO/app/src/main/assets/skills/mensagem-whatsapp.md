# Mensagem no WhatsApp — escreve e deixa pronta para enviar

1. Confirme com o usuário o número (com DDD) e o texto, se ele não deu os dois.
2. Se o número da pessoa estiver na MEMÓRIA, use; se não, pergunte e ofereça gravar com `lembrar`.
3. Use `whatsapp_mensagem`.
4. Avise que a mensagem está pronta e que falta ele tocar em enviar.
