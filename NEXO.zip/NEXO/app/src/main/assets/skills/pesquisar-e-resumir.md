# Pesquisar e resumir — responde perguntas atuais com fonte

1. Use `buscar_web` com uma consulta curta e objetiva.
2. Se os resumos não bastarem, use `ler_pagina` no resultado mais confiável (site oficial ou jornal conhecido).
3. Responda em poucas frases e diga de onde veio a informação.
4. Se as fontes discordarem, diga isso.
