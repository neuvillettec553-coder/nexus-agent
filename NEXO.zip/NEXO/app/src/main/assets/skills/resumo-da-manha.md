# Resumo da manhã — começa o dia com data, clima e notícias principais

1. Use `data_hora` para saber o dia.
2. Use `buscar_web` com "previsão do tempo hoje" e a cidade do usuário (se estiver na MEMÓRIA; se não, pergunte uma vez e grave com `lembrar`).
3. Use `buscar_web` com "principais notícias do Brasil hoje".
4. Use `listar_notas` para ver se há algo pendente.
5. Responda em até 5 frases: dia, clima, 2 ou 3 notícias e pendências.
