package com.jeconias.nexo.core

import android.app.NotificationManager
import android.content.Context
import android.os.PowerManager
import com.jeconias.nexo.agent.LocalEngine
import com.jeconias.nexo.live.LiveData
import com.jeconias.nexo.providers.ProviderCatalog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * DIAGNÓSTICO: testa de verdade cada função e mostra o que passou e o que falhou.
 * Nada aqui é "achismo": cada item executa a função ou confere o estado real do celular.
 */
object Diagnostics {
    enum class State { OK, WARN, FAIL }
    data class Check(val name: String, val state: State, val detail: String)

    suspend fun runAll(ctx: Context, report: (Check) -> Unit) {
        suspend fun check(name: String, timeoutMs: Long = 20_000, block: suspend () -> Check) {
            val c = try {
                withTimeout(timeoutMs) { block() }
            } catch (e: CancellationException) {
                if (e is kotlinx.coroutines.TimeoutCancellationException) Check(name, State.FAIL, "Demorou demais para responder.")
                else throw e
            } catch (e: Exception) {
                Check(name, State.FAIL, e.message?.take(200) ?: e.javaClass.simpleName)
            }
            report(c)
        }

        check("Internet") {
            val net = LiveData.network(ctx)
            if (net == "Offline") return@check Check("Internet", State.FAIL, "Sem conexão.")
            val ok = withContext(Dispatchers.IO) {
                Container.http.newCall(Request.Builder().url("https://www.google.com/generate_204").build()).execute().use { it.code in 200..299 }
            }
            Check("Internet", if (ok) State.OK else State.FAIL, "$net · ${if (ok) "respondendo" else "sem resposta"}")
        }

        val settings = Container.settings
        val withKey = settings.providerOrder().filter { settings.isEnabled(it) && settings.apiKey(it).isNotBlank() }
        if (withKey.isEmpty()) {
            report(Check("IAs", State.FAIL, "Nenhuma IA ligada com chave. O Alfredo não consegue pensar."))
        }
        for (id in withKey) {
            val name = ProviderCatalog.byId(id)?.name ?: id
            check("IA: $name", 40_000) {
                val r = Container.router.test(id)
                Check("IA: $name", if (r.startsWith("✅")) State.OK else State.FAIL, r.removePrefix("✅ ").removePrefix("❌ "))
            }
        }
        if (withKey.size == 1) report(Check("Conselho de IAs", State.WARN, "Só 1 IA ativa. O Conselho precisa de pelo menos 2."))
        if (withKey.size >= 2) report(Check("Conselho de IAs", State.OK, "${withKey.size} IAs disponíveis · modo: ${settings.councilMode()}"))

        check("AGENTS.md e MEMORY.md") {
            val a = Container.context.readAgents()
            val m = Container.context.readMemory()
            val lines = a.lines().size
            when {
                a.isBlank() -> Check("AGENTS.md e MEMORY.md", State.FAIL, "AGENTS.md vazio.")
                lines > 200 -> Check("AGENTS.md e MEMORY.md", State.WARN, "AGENTS.md com $lines linhas (limite 200).")
                else -> Check("AGENTS.md e MEMORY.md", State.OK, "Regras: $lines linhas · Memória: ${m.lines().size} linhas")
            }
        }

        check("Gravar arquivos") {
            val f = File(ctx.filesDir, "diag.tmp")
            f.writeText("teste")
            val ok = f.readText() == "teste"
            f.delete()
            Check("Gravar arquivos", if (ok) State.OK else State.FAIL, if (ok) "Memória do celular gravando normalmente." else "Falha ao gravar.")
        }

        suspend fun tool(label: String, name: String, args: JSONObject = JSONObject(), expect: (String) -> Boolean = { true }) {
            check(label) {
                val t = Container.tools.get(name) ?: return@check Check(label, State.FAIL, "Ferramenta $name não existe.")
                val r = t.run(args)
                val ok = r.ok && expect(r.output)
                Check(label, if (ok) State.OK else State.FAIL, r.output.take(140))
            }
        }
        tool("Ferramenta: data e hora", "data_hora")
        tool("Ferramenta: lista de apps", "listar_apps") { it.split(",").size > 3 }
        tool("Ferramenta: pesquisa na internet", "buscar_web", JSONObject().put("consulta", "previsão do tempo"))
        tool("Ferramenta: notas", "listar_notas")

        check("Motor Local") {
            val engine = LocalEngine(Container.shortcuts)
            val samples = mapOf(
                "que horas são" to "data_hora",
                "abre o youtube" to "abrir_app",
                "coloca um alarme às 6:30" to "criar_alarme",
                "me lembra daqui 10 minutos de beber água" to "criar_lembrete",
                "anota comprar pão" to "anotar",
            )
            val wrong = samples.filter { (frase, esperado) -> engine.match(frase)?.tool != esperado }.keys
            val learned = Container.shortcuts.all().size
            if (wrong.isEmpty()) Check("Motor Local", State.OK, "Entendeu as ${samples.size} frases de teste · $learned atalhos aprendidos")
            else Check("Motor Local", State.FAIL, "Não entendeu: ${wrong.joinToString()}")
        }

        check("Notificações") {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.areNotificationsEnabled()) Check("Notificações", State.OK, "Liberadas: lembretes e rotinas vão aparecer.")
            else Check("Notificações", State.FAIL, "Bloqueadas: lembretes e rotinas NÃO vão aparecer. Libere nas configurações do celular.")
        }

        check("Bateria") {
            val pm = ctx.getSystemService(PowerManager::class.java)
            if (pm.isIgnoringBatteryOptimizations(ctx.packageName)) Check("Bateria", State.OK, "NEXO liberado da economia de bateria.")
            else Check("Bateria", State.WARN, "A economia de bateria pode atrasar lembretes e rotinas. Use “Liberar bateria”.")
        }

        check("Voz") {
            val engines = Container.voice.engines
            val active = settings.activeVoice()
            val ready = engines.filter { it.available() }.map { it.label }
            val activeOk = engines.firstOrNull { it.id == active }?.available() == true
            when {
                ready.isEmpty() -> Check("Voz", State.FAIL, "Nenhuma voz pronta.")
                !activeOk -> Check("Voz", State.WARN, "A voz escolhida não está pronta; vai usar a reserva. Prontas: ${ready.joinToString()}")
                else -> Check("Voz", State.OK, "Em uso: ${engines.first { it.id == active }.label} · Prontas: ${ready.joinToString()}")
            }
        }

        check("Backup") {
            val last = settings.lastBackup()
            when {
                settings.backupPassword().length < 4 -> Check("Backup", State.WARN, "Sem senha de backup definida. Seus dados não estão protegidos contra perda.")
                last == 0L -> Check("Backup", State.WARN, "Nenhum backup feito ainda.")
                else -> {
                    val days = (System.currentTimeMillis() - last) / 86_400_000L
                    val quando = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(last))
                    Check("Backup", if (days <= 7) State.OK else State.WARN, "Último backup: $quando")
                }
            }
        }
    }
}
