package com.jeconias.nexo.tools.builtin

import android.content.Context
import com.jeconias.nexo.scheduler.RoutineStore
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import com.jeconias.nexo.core.Container
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CriarLembreteTool(private val ctx: Context) : Tool {
    override val name = "criar_lembrete"
    override val description =
        "Agenda uma notificação de lembrete. Informe 'minutos' (daqui a X minutos) OU 'data_hora' no formato AAAA-MM-DD HH:MM."
    override val parameters = schema(
        Param("mensagem", "string", "Texto do lembrete"),
        Param("minutos", "integer", "Daqui a quantos minutos", required = false),
        Param("data_hora", "string", "Data e hora exatas, formato AAAA-MM-DD HH:MM", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val msg = args.optString("mensagem").ifBlank { "Lembrete" }
        val now = System.currentTimeMillis()
        val target: Long = when {
            args.has("minutos") && args.optInt("minutos", 0) > 0 -> now + args.optInt("minutos") * 60_000L
            args.optString("data_hora").isNotBlank() -> try {
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(args.optString("data_hora"))?.time ?: 0L
            } catch (_: Exception) { 0L }
            else -> 0L
        }
        if (target <= now) return ToolResult(false, "Horário inválido ou no passado. Nada foi agendado.")
        Container.routines.scheduleReminder(msg, target - now)
        val quando = SimpleDateFormat("dd/MM 'às' HH:mm", Locale("pt", "BR")).format(Date(target))
        return ToolResult(true, "Lembrete agendado para $quando: $msg (pode atrasar alguns minutos se o celular estiver em economia de bateria).")
    }
}

class AgendarRotinaTool(private val routines: RoutineStore) : Tool {
    override val name = "agendar_rotina"
    override val description =
        "Cria uma rotina automática: o agente executa a instrução sozinho e manda o resultado numa notificação. tipo 'diaria' usa 'hora' (HH:MM); tipo 'intervalo' usa 'horas'."
    override val parameters = schema(
        Param("nome", "string", "Nome curto da rotina"),
        Param("instrucao", "string", "O que o agente deve fazer a cada execução"),
        Param("tipo", "string", "'diaria' ou 'intervalo'"),
        Param("hora", "string", "HH:MM, para rotina diária", required = false),
        Param("horas", "integer", "A cada quantas horas, para intervalo (mínimo 1)", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val tipo = if (args.optString("tipo") == "intervalo") "intervalo" else "diaria"
        val r = routines.add(
            args.optString("nome").ifBlank { "Rotina" },
            args.optString("instrucao"),
            tipo,
            args.optString("hora").ifBlank { "08:00" },
            args.optInt("horas", 24),
        )
        val quando = if (tipo == "diaria") "todo dia às ${r.hora}" else "a cada ${r.horas}h"
        return ToolResult(routines.get(r.id) != null, "Rotina '${r.nome}' criada ($quando). ID ${r.id}.")
    }
}

class ListarRotinasTool(private val routines: RoutineStore) : Tool {
    override val level = Level.READ
    override val name = "listar_rotinas"
    override val description = "Lista as rotinas automáticas ativas."
    override val parameters = schema()
    override suspend fun run(args: JSONObject): ToolResult {
        val all = routines.all()
        return ToolResult(true, if (all.isEmpty()) "Nenhuma rotina." else all.joinToString("\n") {
            "• ${it.nome} (ID ${it.id}) — " + (if (it.tipo == "diaria") "diária ${it.hora}" else "a cada ${it.horas}h") + ": ${it.instrucao}"
        })
    }
}

class CancelarRotinaTool(private val routines: RoutineStore) : Tool {
    override val level = Level.SENSITIVE
    override val name = "cancelar_rotina"
    override val description = "Cancela uma rotina pelo ID ou pelo nome."
    override val parameters = schema(Param("id_ou_nome", "string", "ID ou nome da rotina"))
    override suspend fun run(args: JSONObject): ToolResult {
        val ok = routines.remove(args.optString("id_ou_nome"))
        return ToolResult(ok, if (ok) "Rotina cancelada." else "Rotina não encontrada.")
    }
}
