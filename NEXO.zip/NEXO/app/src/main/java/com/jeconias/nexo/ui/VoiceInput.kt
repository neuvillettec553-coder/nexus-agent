package com.jeconias.nexo.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/** Abre o ditado por voz do Android e manda o texto direto para o Alfredo. */
@Composable
fun rememberVoiceInput(vm: ChatViewModel): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        vm.setListening(false)
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) vm.send(text)
        }
    }
    return remember(launcher) {
        {
            vm.stopSpeaking()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Pode falar")
            try {
                vm.setListening(true)
                launcher.launch(intent)
            } catch (e: ActivityNotFoundException) {
                vm.setListening(false)
                Toast.makeText(ctx, "Reconhecimento de voz não disponível", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
