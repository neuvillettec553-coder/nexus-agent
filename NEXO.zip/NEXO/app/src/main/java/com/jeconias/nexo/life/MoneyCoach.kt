package com.jeconias.nexo.life

import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.providers.ChatMessage
import org.json.JSONObject

/**
 * Coach financeiro: usa a IA com os dados REAIS do usuário para
 * (1) achar cortes, (2) preparar negociação de dívidas, (3) gerar oportunidades de renda
 * com primeiro passo para HOJE, e (4) preparar o material de trabalho de cada oportunidade.
 * Regras: nada de promessa de dinheiro fácil, nada de apostas, pirâmides ou "tarefinhas que pagam".
 */
class MoneyCoach(private val store: LifeStore) {

    private val ethics = """
        Você é o coach financeiro do Alfredo. Português do Brasil, prático e honesto.
        PROIBIDO sugerir: apostas, jogos de azar, pirâmides, "ganhe dinheiro fazendo tarefas/assistindo vídeos",
        empréstimo para investir, cripto especulativa, qualquer coisa ilegal ou que dependa de pagar para começar.
        Sempre diga o risco e que os valores são estimativas. Você não é consultor financeiro certificado:
        organize e sugira; a decisão é do usuário.
    """.trimIndent()

    private suspend fun ask(stage: String, prompt: String): String {
        val t0 = System.currentTimeMillis()
        val r = Container.router.chat(listOf(ChatMessage("system", ethics), ChatMessage("user", prompt)), emptyList())
        FlowLog.add("FINANÇAS", r.providerName, stage, System.currentTimeMillis() - t0)
        return r.text.replace(Regex("(?s)<think>.*?</think>"), "").trim()
    }

    fun profile(): JSONObject = store.list(LifeStore.PROFILE).firstOrNull() ?: JSONObject().put("id", "perfil")

    fun saveProfile(p: JSONObject) = store.save(LifeStore.PROFILE, listOf(p.put("id", "perfil")))

    private fun profileText(): String {
        val p = profile()
        return buildString {
            append("Habilidades: ${p.optString("habilidades").ifBlank { "não informado" }}\n")
            append("Tempo livre por semana: ${p.optString("tempo").ifBlank { "não informado" }}\n")
            append("Recursos: ${p.optString("recursos").ifBlank { "celular" }}\n")
            append("Cidade/região: ${p.optString("cidade").ifBlank { Container.settings.city().ifBlank { "não informado" } }}\n")
            append("O que NÃO quer fazer: ${p.optString("evitar").ifBlank { "—" }}\n")
        }
    }

    /** Frente 1: estancar o aperto. */
    suspend fun cutPlan(): String = ask(
        "Plano de cortes",
        "Situação real do mês:\n${store.financeReport()}\n\nMonte um plano curto para aliviar o aperto ESTE mês: " +
            "1) 3 a 5 cortes concretos com valor estimado de economia; 2) quais contas priorizar; " +
            "3) uma regra simples para a próxima semana. Use no máximo 15 linhas.",
    )

    /** Mensagem pronta para negociar uma dívida. */
    suspend fun negotiation(creditor: String, total: Double, installment: Double, rate: Double): String = ask(
        "Negociação: $creditor",
        "Escreva uma mensagem educada e firme (WhatsApp/e-mail) para negociar uma dívida com $creditor. " +
            "Valor devido ${FinanceMath.money(total)}, parcela atual ${FinanceMath.money(installment)}, juros $rate% ao mês. " +
            "Peça: desconto para quitação à vista ou parcelamento sem juros/juros menores, e confirmação por escrito. " +
            "Depois da mensagem, dê 3 dicas curtas para a negociação e lembre de conferir canais oficiais do credor " +
            "e de nunca pagar boleto recebido de contato desconhecido.",
    )

    data class Opportunity(val title: String, val firstStep: String, val expected: String, val time: String, val risk: String, val kind: String)

    /** Frente 2: oportunidades de renda com o que o usuário já tem. */
    suspend fun opportunities(): List<Opportunity> {
        val text = ask(
            "Oportunidades de renda",
            "PERFIL DO USUÁRIO:\n${profileText()}\nSITUAÇÃO:\n${store.financeReport()}\n\n" +
                "Ele usa o NEXO, que cria sites/apps simples com IA (Estúdio), escreve textos, propostas e posts. " +
                "Sugira 5 formas REALISTAS e legais de renda extra para ele, que comecem com o que já tem e possam começar esta semana. " +
                "Priorize: serviços para pequenos negócios locais, uso das habilidades técnicas dele, venda de produtos digitais próprios, " +
                "e coisas que o NEXO ajude a produzir. " +
                "Responda SOMENTE com JSON: {\"oportunidades\":[{\"titulo\":\"\",\"primeiro_passo\":\"o que fazer HOJE\"," +
                "\"retorno\":\"faixa estimada e prazo\",\"tempo\":\"horas por semana\",\"risco\":\"baixo|médio|alto + motivo\"," +
                "\"tipo\":\"site|texto|servico|produto|outro\"}]}",
        )
        return parseOpportunities(text)
    }

    /** Material pronto para a oportunidade (proposta, mensagem de oferta, post, tabela de preço). */
    suspend fun prepare(o: JSONObject, what: String): String = ask(
        "Material: ${o.optString("titulo")}",
        "Oportunidade: ${o.optString("titulo")}\nPrimeiro passo: ${o.optString("primeiro_passo")}\nPerfil:\n${profileText()}\n\n" +
            "Prepare agora, pronto para usar: $what. Seja concreto, com preços sugeridos realistas para o Brasil " +
            "e uma mensagem curta de oferta para WhatsApp.",
    )

    companion object {
        fun parseOpportunities(text: String): List<Opportunity> {
            val clean = text.replace(Regex("(?s)<think>.*?</think>"), "")
            val start = clean.indexOf('{')
            val end = clean.lastIndexOf('}')
            if (start < 0 || end <= start) return emptyList()
            val arr = runCatching { JSONObject(clean.substring(start, end + 1)).getJSONArray("oportunidades") }.getOrNull() ?: return emptyList()
            return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
                Opportunity(
                    it.optString("titulo"), it.optString("primeiro_passo"), it.optString("retorno"),
                    it.optString("tempo"), it.optString("risco"), it.optString("tipo", "outro"),
                )
            }.filter { it.title.isNotBlank() }
        }
    }
}
