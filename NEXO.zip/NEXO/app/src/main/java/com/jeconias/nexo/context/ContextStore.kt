package com.jeconias.nexo.context

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Engenharia de contexto.
 *  - AGENTS.md: regras de conduta, tom, escopo (máximo 200 linhas).
 *  - MEMORY.md: o que o agente aprendeu (correções, preferências, regras novas).
 * Os dois são lidos de novo a CADA mensagem, então qualquer mudança vale na hora.
 */
class ContextStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "contexto").apply { mkdirs() }
    val agentsFile = File(dir, "AGENTS.md")
    val memoryFile = File(dir, "MEMORY.md")

    private val prefs = ctx.getSharedPreferences("nexo_contexto", Context.MODE_PRIVATE)

    init {
        if (!agentsFile.exists()) copyAsset("AGENTS.md", agentsFile)
        if (!memoryFile.exists()) copyAsset("MEMORY.md", memoryFile)
        // Atualiza as regras para a versão nova, a menos que você tenha editado o AGENTS.md.
        if (prefs.getInt("agents_ver", 1) < AGENTS_VERSION) {
            if (!prefs.getBoolean("agents_edited", false)) copyAsset("AGENTS.md", agentsFile)
            prefs.edit().putInt("agents_ver", AGENTS_VERSION).apply()
        }
    }

    private fun copyAsset(name: String, target: File) {
        ctx.assets.open(name).use { input -> target.outputStream().use { input.copyTo(it) } }
    }

    fun readAgents(): String = agentsFile.readText()
    fun readMemory(): String = memoryFile.readText()

    /** Retorna null se salvou, ou a mensagem de erro. */
    fun saveAgents(text: String): String? {
        val lines = text.lines().size
        if (lines > MAX_AGENTS_LINES) return "AGENTS.md tem $lines linhas. O limite é $MAX_AGENTS_LINES."
        agentsFile.writeText(text)
        prefs.edit().putBoolean("agents_edited", true).apply()
        return null
    }

    fun saveMemory(text: String) = memoryFile.writeText(text)

    fun resetAgents() {
        copyAsset("AGENTS.md", agentsFile)
        prefs.edit().putBoolean("agents_edited", false).apply()
    }

    /**
     * Memória organizada por assuntos: cada fato entra na seção "## Assunto" do MEMORY.md.
     * Assuntos: Pessoas, Preferências, Lugares, Rotina, Finanças, Regras, Outros.
     */
    @Synchronized
    fun appendMemory(entry: String, topic: String = "Outros") {
        val date = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date())
        val clean = entry.trim().replace("\n", " ")
        val section = TOPICS.firstOrNull { it.equals(topic.trim(), ignoreCase = true) } ?: "Outros"
        val line = "- [$date] $clean"
        val lines = readMemory().lines().toMutableList()
        val header = lines.indexOfFirst { it.trim().equals("## $section", ignoreCase = true) }
        if (header < 0) {
            if (lines.isNotEmpty() && lines.last().isNotBlank()) lines.add("")
            lines.add("## $section")
            lines.add(line)
        } else {
            var end = header + 1
            while (end < lines.size && !lines[end].startsWith("## ")) end++
            while (end > header + 1 && lines[end - 1].isBlank()) end--
            lines.add(end, line)
        }
        memoryFile.writeText(lines.joinToString("\n"))
    }

    /** Monta o prompt de sistema: AGENTS.md + MEMORY.md + skills + data/hora. */
    fun systemPrompt(skillsIndex: String, userName: String, city: String = ""): String {
        val memoryLines = readMemory().lines()
        val memory = if (memoryLines.size > MAX_MEMORY_LINES_IN_PROMPT)
            memoryLines.takeLast(MAX_MEMORY_LINES_IN_PROMPT).joinToString("\n")
        else memoryLines.joinToString("\n")
        val now = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
        return buildString {
            append(readAgents())
            append("\n\n---\n# MEMÓRIA (MEMORY.md)\n")
            append(memory)
            append("\n\n---\n# SKILLS SALVAS (use a ferramenta ler_skill para ver os passos)\n")
            append(skillsIndex.ifBlank { "(nenhuma)" })
            append("\n\n---\n# AGORA\nData e hora: $now. Você está falando com $userName.")
            if (city.isNotBlank()) append(" Cidade do usuário: $city.")
        }
    }

    companion object {
        const val MAX_AGENTS_LINES = 200
        const val AGENTS_VERSION = 5
        val TOPICS = listOf("Pessoas", "Preferências", "Lugares", "Rotina", "Finanças", "Regras", "Outros")
        const val MAX_MEMORY_LINES_IN_PROMPT = 300
    }
}
