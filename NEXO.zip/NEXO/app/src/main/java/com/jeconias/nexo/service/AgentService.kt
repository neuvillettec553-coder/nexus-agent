package com.jeconias.nexo.service

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.Notifications

/**
 * Modo 24/7: mantém o NEXO vivo em segundo plano com uma notificação fixa.
 * As rotinas e lembretes rodam pelo WorkManager mesmo sem este serviço;
 * ele serve para o Android não "matar" o app e, na próxima fase, para a palavra de ativação.
 */
class AgentService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = Notifications.persistent(this)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(Notifications.PERSISTENT_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(Notifications.PERSISTENT_ID, notification)
        }
        return START_STICKY
    }

    companion object {
        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, AgentService::class.java))

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AgentService::class.java))
        }
    }
}

/** Liga o modo 24/7 de novo quando o celular reinicia (se estava ligado). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Container.init(context)
        if (Container.settings.persistentMode()) {
            runCatching { AgentService.start(context) }
        }
    }
}
