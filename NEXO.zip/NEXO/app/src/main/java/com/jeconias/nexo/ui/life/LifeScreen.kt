package com.jeconias.nexo.ui.life

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.life.LifeStore
import com.jeconias.nexo.providers.ChatMessage
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private suspend fun coachAsk(stage: String, prompt: String): String {
    val t0 = System.currentTimeMillis()
    val r = Container.router.chat(
        listOf(
            ChatMessage("system", "Você é o Alfredo, mentor de desenvolvimento pessoal: prático, gentil e honesto. Português do Brasil. Respostas curtas e acionáveis."),
            ChatMessage("user", prompt),
        ), emptyList(),
    )
    FlowLog.add("VIDA", r.providerName, stage, System.currentTimeMillis() - t0)
    return r.text.replace(Regex("(?s)<think>.*?</think>"), "").trim()
}

/** VIDA: tarefas, hábitos, metas de desenvolvimento pessoal e diário de reflexão. */
@Composable
fun LifeScreen() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        SubTabs(listOf("TAREFAS", "HÁBITOS", "METAS", "DIÁRIO"), tab) { tab = it }
        when (tab) {
            0 -> TasksTab()
            1 -> HabitsTab()
            2 -> LifeGoalsTab()
            else -> JournalTab()
        }
    }
}

@Composable
private fun TasksTab() {
    val store = Container.life
    val v = store.version
    val open = remember(v) { store.openTasks() }
    val done = remember(v) { store.list(LifeStore.TASKS).filter { it.optBoolean("feita") }.takeLast(10).reversed() }
    var title by remember { mutableStateOf("") }
    var due by remember { mutableStateOf("") }
    var prio by remember { mutableStateOf("média") }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            GlassCard {
                SectionLabel("NOVA TAREFA")
                Field(title, { title = it }, "O que fazer")
                Field(due, { due = it }, "Prazo (AAAA-MM-DD, opcional)")
                Chips(listOf("baixa", "média", "alta"), prio) { prio = it }
                Button(onClick = {
                    store.add(LifeStore.TASKS, JSONObject().put("titulo", title).put("prazo", due.trim())
                        .put("prioridade", when (prio) { "alta" -> 3; "baixa" -> 1; else -> 2 }).put("feita", false))
                    title = ""; due = ""
                }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Adicionar") }
                Muted("Ou fale: “cria a tarefa pagar a internet até sexta, prioridade alta”.")
            }
        }
        item { SectionLabel("ABERTAS (MAIS URGENTES PRIMEIRO)") }
        if (open.isEmpty()) item { Empty("Tudo em dia.") }
        items(open, key = { it.optString("id") }) { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = false, onCheckedChange = { store.update(LifeStore.TASKS, t.optString("id")) { it.put("feita", true).put("feita_em", LifeStore.today()) } })
                Column(Modifier.weight(1f)) {
                    Text(t.optString("titulo"), color = NexoColors.text, fontSize = 14.sp)
                    Muted(listOfNotNull(
                        when (t.optInt("prioridade", 2)) { 3 -> "🔴 alta"; 1 -> "⚪ baixa"; else -> "🟡 média" },
                        t.optString("prazo").takeIf { it.isNotBlank() }?.let { "até $it" },
                    ).joinToString(" · "))
                }
                TextButton(onClick = { store.remove(LifeStore.TASKS, t.optString("id")) }) { Text("✕", color = NexoColors.muted) }
            }
        }
        if (done.isNotEmpty()) item { SectionLabel("CONCLUÍDAS") }
        items(done, key = { "d" + it.optString("id") }) { t ->
            Text("✓ " + t.optString("titulo"), color = NexoColors.muted, textDecoration = TextDecoration.LineThrough, fontSize = 13.sp)
        }
    }
}

@Composable
private fun HabitsTab() {
    val store = Container.life
    val v = store.version
    val habits = remember(v) { store.list(LifeStore.HABITS) }
    var name by remember { mutableStateOf("") }
    val today = LifeStore.today()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(habits, key = { it.optString("id") }) { h ->
            val doneToday = h.optString("dias").contains(today)
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.optString("nome"), color = NexoColors.text, fontWeight = FontWeight.Bold)
                        Text("🔥 ${store.habitStreak(h)} dia(s) seguidos", color = HoloOrange, fontSize = 12.sp)
                    }
                    if (doneToday) Text("✅ hoje", color = NexoColors.green)
                    else Button(onClick = {
                        store.update(LifeStore.HABITS, h.optString("id")) { it.put("dias", (it.optString("dias") + ",$today").trim(',')) }
                    }) { Text("Fiz hoje") }
                }
                TextButton(onClick = { store.remove(LifeStore.HABITS, h.optString("id")) }) { Text("Remover", color = NexoColors.muted) }
            }
        }
        if (habits.isEmpty()) item { Empty("Nenhum hábito ainda. Comece com um só, bem pequeno.") }
        item {
            GlassCard {
                Field(name, { name = it }, "Novo hábito (ex.: ler 10 páginas)")
                Button(onClick = { store.add(LifeStore.HABITS, JSONObject().put("nome", name).put("dias", "")); name = "" },
                    enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Criar hábito") }
            }
        }
    }
}

@Composable
private fun LifeGoalsTab() {
    val store = Container.life
    val scope = rememberCoroutineScope()
    val v = store.version
    val goals = remember(v) { store.list(LifeStore.LIFE_GOALS) }
    var title by remember { mutableStateOf("") }
    var horizon by remember { mutableStateOf("médio prazo") }
    var busy by remember { mutableStateOf("") }
    var review by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            GlassCard {
                SectionLabel("NOVA META DE VIDA")
                Field(title, { title = it }, "Meta (ex.: aprender programação de verdade)")
                Chips(listOf("curto prazo", "médio prazo", "longo prazo"), horizon) { horizon = it }
                Button(onClick = {
                    busy = "A IA está dividindo a meta em passos…"
                    scope.launch {
                        val text = runCatching {
                            coachAsk("Dividir meta", "Divida a meta \"$title\" ($horizon) em 5 a 8 passos práticos, pequenos e em ordem. " +
                                "Considere que a pessoa trabalha em turno numa fábrica e tem pouco tempo. Responda só com os passos, um por linha, sem numeração.")
                        }.getOrElse { "" }
                        val steps = JSONArray()
                        text.lines().map { it.trim().trimStart('-', '•', '*', ' ').replace(Regex("^\\d+[.)]\\s*"), "") }
                            .filter { it.length > 3 }.take(10).forEach { steps.put(JSONObject().put("texto", it).put("feito", false)) }
                        if (steps.length() == 0) steps.put(JSONObject().put("texto", "Definir o primeiro passo").put("feito", false))
                        store.add(LifeStore.LIFE_GOALS, JSONObject().put("titulo", title).put("prazo", horizon).put("passos", steps))
                        title = ""; busy = ""
                    }
                }, enabled = title.isNotBlank() && busy.isBlank(), modifier = Modifier.fillMaxWidth()) { Text("🤖 Criar com passos") }
                Busy(busy)
            }
        }
        items(goals, key = { it.optString("id") }) { g ->
            val steps = g.optJSONArray("passos") ?: JSONArray()
            val doneCount = (0 until steps.length()).count { steps.getJSONObject(it).optBoolean("feito") }
            GlassCard {
                Text(g.optString("titulo"), color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted("${g.optString("prazo")} · $doneCount de ${steps.length()} passos")
                Bar(if (steps.length() == 0) 0f else doneCount / steps.length().toFloat(), HoloBlue)
                for (i in 0 until steps.length()) {
                    val st = steps.getJSONObject(i)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = st.optBoolean("feito"), onCheckedChange = { checked ->
                            store.update(LifeStore.LIFE_GOALS, g.optString("id")) { obj -> obj.optJSONArray("passos")?.getJSONObject(i)?.put("feito", checked) }
                        })
                        Text(st.optString("texto"), color = if (st.optBoolean("feito")) NexoColors.muted else NexoColors.text, fontSize = 13.sp)
                    }
                }
                TextButton(onClick = { store.remove(LifeStore.LIFE_GOALS, g.optString("id")) }) { Text("Remover meta", color = NexoColors.muted) }
            }
        }
        item {
            GlassCard {
                SectionLabel("REVISÃO SEMANAL")
                Muted("A IA olha suas metas, tarefas, hábitos e diário e propõe o foco da próxima semana.")
                Button(onClick = {
                    busy = "Revisando sua semana…"
                    scope.launch {
                        val journal = store.list(LifeStore.JOURNAL).takeLast(7).joinToString("\n") { "${it.optString("data")}: ${it.optString("texto")}" }
                        review = runCatching {
                            coachAsk("Revisão semanal", "Dados reais:\n${store.lifeReport()}\nDiário da semana:\n$journal\n\n" +
                                "Faça a revisão semanal: o que avançou, o que travou e por quê, e 3 focos concretos para a próxima semana.")
                        }.getOrElse { "❌ ${it.message}" }
                        busy = ""
                    }
                }, enabled = busy.isBlank(), modifier = Modifier.fillMaxWidth()) { Text("🤖 Fazer revisão") }
            }
        }
        if (review.isNotBlank()) item { AiResult(review) }
    }
}

@Composable
private fun JournalTab() {
    val store = Container.life
    val scope = rememberCoroutineScope()
    val v = store.version
    val entries = remember(v) { store.list(LifeStore.JOURNAL).takeLast(30).reversed() }
    var text by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            GlassCard {
                SectionLabel("REFLEXÃO DO DIA")
                if (question.isNotBlank()) Text(question, color = HoloCyan, fontSize = 14.sp)
                TextButton(onClick = {
                    busy = "…"
                    scope.launch {
                        question = runCatching { coachAsk("Pergunta do diário", "Faça UMA pergunta curta e gentil de reflexão para o fim do dia. Contexto:\n${store.lifeReport()}") }
                            .getOrElse { "O que foi bom hoje, e o que você faria diferente?" }
                        busy = ""
                    }
                }) { Text("🤖 Me faça uma pergunta") }
                Field(text, { text = it }, "…Escreva como foi o seu dia")
                Button(onClick = {
                    store.add(LifeStore.JOURNAL, JSONObject().put("texto", (if (question.isNotBlank()) "[$question] " else "") + text).put("data", LifeStore.today()))
                    text = ""; question = ""
                }, enabled = text.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Salvar no diário") }
                Busy(if (busy == "…") "" else busy)
            }
        }
        items(entries, key = { it.optString("id") }) { e ->
            GlassCard {
                Text(e.optString("data"), color = HoloOrange, fontSize = 11.sp)
                Text(e.optString("texto"), color = NexoColors.text, fontSize = 13.sp)
            }
        }
        if (entries.isEmpty()) item { Muted("Seu diário é só seu e fica no celular.") }
    }
}
