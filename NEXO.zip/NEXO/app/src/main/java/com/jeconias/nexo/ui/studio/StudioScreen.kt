package com.jeconias.nexo.ui.studio

import android.annotation.SuppressLint
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.studio.CodeAssistant
import com.jeconias.nexo.studio.Language
import com.jeconias.nexo.studio.ProjectStore
import com.jeconias.nexo.studio.RunResult
import com.jeconias.nexo.studio.Runners
import com.jeconias.nexo.studio.Template
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** ESTÚDIO: projetos, editor, execução e IA programadora. */
@Composable
fun StudioScreen() {
    val ctx = LocalContext.current
    val store = remember { ProjectStore(ctx.applicationContext) }
    var project by rememberSaveable { mutableStateOf<String?>(null) }
    val open = project
    if (open == null) {
        ProjectList(store, onOpen = { project = it })
    } else {
        BackHandler { project = null }
        Workspace(store, open, onClose = { project = null })
    }
}

// =============================== LISTA DE PROJETOS ===============================

@Composable
private fun ProjectList(store: ProjectStore, onOpen: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    val projects = remember(refresh) { store.projects() }
    var creating by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<String?>(null) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            SectionTitle("ESTÚDIO")
            Muted("Programe com o Alfredo: projetos organizados, editor com cores, execução no celular e IA que escreve, revisa, testa e corrige.")
            Spacer(Modifier.height(6.dp))
            Button(onClick = { creating = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Novo projeto") }
        }
        if (projects.isEmpty()) item { Muted("Nenhum projeto ainda.") }
        items(projects, key = { it }) { name ->
            val files = remember(name, refresh) { store.files(name) }
            val date = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(store.dir(name).lastModified()))
            GlassCard(Modifier.clickable { onOpen(name) }) {
                Text(name, color = NexoColors.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Muted("${files.size} arquivo(s) · alterado em $date")
                Muted(files.take(5).joinToString("  ·  "))
                TextButton(onClick = { toDelete = name }) { Text("Apagar projeto", color = NexoColors.red) }
            }
        }
    }

    if (creating) {
        NewProjectDialog(
            onDismiss = { creating = false },
            onTemplate = { name, template ->
                val n = store.create(name, template)
                creating = false
                refresh++
                onOpen(n)
            },
            onAi = { description, done ->
                scope.launch {
                    val result = runCatching { Container.newCodeAssistant().scaffold(description) }
                    result.onSuccess { (name, files) ->
                        val n = store.createFromFiles(name, files)
                        creating = false
                        refresh++
                        onOpen(n)
                    }
                    done(result.exceptionOrNull()?.message)
                }
            },
        )
    }
    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Apagar “$del”?") },
            text = { Text("Todos os arquivos e o histórico deste projeto serão apagados do celular.") },
            confirmButton = { TextButton(onClick = { store.delete(del); toDelete = null; refresh++ }) { Text("Apagar", color = NexoColors.red) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun NewProjectDialog(
    onDismiss: () -> Unit,
    onTemplate: (String, Template) -> Unit,
    onAi: (String, (String?) -> Unit) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Novo projeto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome") }, singleLine = true)
                Text("Começar de um modelo:", color = NexoColors.muted, fontSize = 12.sp)
                Template.all.forEach { t ->
                    OutlinedButton(onClick = { onTemplate(name.ifBlank { t.id }, t) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text(t.label, maxLines = 1)
                    }
                }
                Text("Ou descreva e a IA monta o projeto inteiro:", color = NexoColors.muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = description, onValueChange = { description = it },
                    placeholder = { Text("Ex.: calculadora de horas extras com testes") }, minLines = 2,
                )
                Button(
                    onClick = {
                        busy = true
                        error = ""
                        onAi(description) { err -> busy = false; error = err ?: "" }
                    },
                    enabled = description.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth(),
                ) { Text(if (busy) "A IA está criando…" else "Criar com IA") }
                if (error.isNotBlank()) Text("❌ $error", color = NexoColors.red, fontSize = 12.sp)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Fechar") } },
    )
}

// =============================== ÁREA DE TRABALHO ===============================

private enum class Panel { NONE, BUILDER, OUTPUT, PREVIEW, AI }

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun Workspace(store: ProjectStore, project: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val assistant = remember { Container.newCodeAssistant() }

    var refresh by remember { mutableIntStateOf(0) }
    val files = remember(refresh) { store.files(project) }
    var current by rememberSaveable(project) {
        mutableStateOf(
            files.firstOrNull { it in listOf("main.py", "index.html", "main.js", "main.lua") } ?: files.firstOrNull() ?: ""
        )
    }
    var editor by remember { mutableStateOf(TextFieldValue("")) }
    var dirty by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var output by remember { mutableStateOf("") }
    var outputError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf("") }
    var previewKey by remember { mutableIntStateOf(0) }
    var answer by remember { mutableStateOf<CodeAssistant.Answer?>(null) }
    var showAiMenu by remember { mutableStateOf(false) }
    var showNewFile by remember { mutableStateOf(false) }
    var showFileMenu by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var request by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf<CodeAssistant.BuildPlan?>(null) }
    var convo by remember(project) { mutableStateOf(store.conversation(project)) }
    var showPush by remember { mutableStateOf(false) }

    val lang = Language.of(current)

    LaunchedEffect(current, refresh) {
        if (current.isNotBlank() && !dirty) editor = TextFieldValue(store.read(project, current))
    }

    fun save() {
        if (current.isNotBlank() && dirty) {
            store.write(project, current, editor.text)
            dirty = false
        }
    }

    fun openFile(path: String) {
        save()
        dirty = false
        current = path
        editor = TextFieldValue(store.read(project, path))
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            output = try { store.exportZip(ctx, project, uri); "✅ Projeto exportado." } catch (e: Exception) { "❌ ${e.message}" }
            panel = Panel.OUTPUT
        }
    }

    /** Roda o arquivo atual conforme a linguagem. Devolve null quando o resultado aparece na prévia. */
    suspend fun runCurrent(): RunResult? {
        save()
        val text = editor.text
        val file = current
        val language = Language.of(file)
        val hasIndex = store.files(project).contains("index.html")
        return when (language) {
            Language.HTML, Language.CSS -> null
            Language.JAVASCRIPT -> if (hasIndex && store.read(project, "index.html").contains(file)) null else Runners.javascript(ctx, text)
            Language.PYTHON -> Runners.pythonProject(ctx, store.allContents(project).filterKeys { it.endsWith(".py") }, file)
            Language.LUA -> Runners.lua(text)
            Language.SQL -> Runners.sql(text)
            Language.SHELL -> Runners.shell(store.dir(project), text)
            else -> RunResult(
                "${language.label} ainda não roda dentro do celular. Use “IA → Revisar” para conferir o código.",
                false, 0,
            )
        }
    }

    fun showResult(r: RunResult?) {
        if (r == null) {
            output = ""
            previewKey++
            panel = Panel.PREVIEW
        } else {
            output = r.output + "\n\n— ${if (r.error) "terminou com ERRO" else "terminou sem erros"} em ${"%.1f".format(r.ms / 1000f)} s"
            outputError = r.error
            panel = Panel.OUTPUT
        }
    }

    fun run() {
        busy = "Rodando…"
        scope.launch {
            try { showResult(runCurrent()) } finally { busy = "" }
        }
    }

    /** Ciclo profissional: rodar → ver o erro → a IA corrige → rodar de novo (até 3 vezes). */
    fun runAndFix() {
        scope.launch {
            FlowLog.newRequest("Estúdio: rodar e corrigir $current")
            val log = StringBuilder()
            try {
                for (attempt in 1..3) {
                    busy = "Tentativa $attempt: rodando…"
                    val r = runCurrent()
                    if (r == null) {
                        log.append("Este arquivo aparece na prévia. Confira lá; para erros de JavaScript, veja o console abaixo dela.\n")
                        showResult(null)
                        return@launch
                    }
                    if (!r.error) {
                        log.append("✅ Tentativa $attempt: rodou sem erros.\n\n").append(r.output)
                        FlowLog.add("ESTÚDIO", "execução", "Rodou sem erros na tentativa $attempt")
                        break
                    }
                    log.append("❌ Tentativa $attempt: erro.\n").append(r.output.take(1500)).append("\n\n")
                    FlowLog.add("ESTÚDIO", "execução", "Erro na tentativa $attempt", ok = false)
                    if (attempt == 3) { log.append("Parei depois de 3 tentativas. Veja o erro acima ou peça ajuda à IA."); break }
                    busy = "Tentativa $attempt: a IA está corrigindo…"
                    val a = assistant.ask(CodeAssistant.Action.FIX, current, editor.text, store.allContents(project), r.output)
                    val code = a.code
                    if (code == null) { log.append("A IA não devolveu código corrigido:\n${a.text}"); break }
                    log.append("🛠 Correção aplicada (${a.provider}): ${a.text.take(300)}\n\n")
                    editor = TextFieldValue(code)
                    dirty = true
                    save()
                }
            } catch (e: Exception) {
                log.append("❌ ${e.message}")
            } finally {
                busy = ""
                output = log.toString()
                outputError = Runners.looksLikeError(log.toString()) && !log.contains("rodou sem erros")
                panel = Panel.OUTPUT
            }
        }
    }

    fun askAi(action: CodeAssistant.Action, request: String = "") {
        busy = "A IA está trabalhando…"
        scope.launch {
            try {
                answer = assistant.ask(action, current, editor.text, store.allContents(project), output.takeIf { it.isNotBlank() }, request)
                panel = Panel.AI
            } catch (e: Exception) {
                answer = CodeAssistant.Answer("❌ ${e.message}", null, "")
                panel = Panel.AI
            } finally {
                busy = ""
            }
        }
    }

    fun build() {
        val text = request.trim()
        if (text.isBlank()) return
        save()
        busy = "A IA está planejando…"
        store.addConversation(project, "Você", text)
        convo = store.conversation(project)
        panel = Panel.BUILDER
        scope.launch {
            try {
                FlowLog.newRequest("Estúdio: $text")
                plan = assistant.build(text, store.allContents(project), store.conversation(project))
                request = ""
            } catch (e: Exception) {
                store.addConversation(project, "Alfredo", "❌ ${e.message}")
                convo = store.conversation(project)
            } finally {
                busy = ""
            }
        }
    }

    fun applyPlan(p: CodeAssistant.BuildPlan) {
        p.changes.forEach { c ->
            if (c.action.startsWith("apag")) store.deleteFile(project, c.path)
            else store.write(project, c.path, c.content)
        }
        store.addConversation(project, "Alfredo", p.plan + "\n" + p.changes.joinToString("\n") { "• ${it.action} ${it.path}" })
        convo = store.conversation(project)
        plan = null
        dirty = false
        refresh++
        val target = p.main?.takeIf { m -> store.files(project).contains(m) } ?: p.changes.firstOrNull { !it.action.startsWith("apag") }?.path
        if (target != null) {
            current = target
            editor = TextFieldValue(store.read(project, target))
        }
    }

    Column(Modifier.fillMaxSize()) {
        // ---------- Cabeçalho ----------
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { save(); onClose() }) { Text("‹ Projetos", color = NexoColors.cyan, maxLines = 1) }
            Text(
                project + if (dirty) " ●" else "", color = NexoColors.text, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            Text(lang.label, color = NexoColors.muted, fontSize = 11.sp, modifier = Modifier.padding(end = 8.dp))
        }

        // ---------- Construtor por conversa ----------
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = request, onValueChange = { request = it }, modifier = Modifier.weight(1f), maxLines = 4,
                placeholder = { Text("Descreva o que você quer criar ou mudar…", fontSize = 13.sp) },
            )
            Button(onClick = { build() }, enabled = busy.isBlank() && request.isNotBlank(), modifier = Modifier.padding(start = 6.dp)) { Text("Criar") }
        }
        TextButton(onClick = { panel = Panel.BUILDER }) { Text("💬 Conversa do projeto (${convo.size})", fontSize = 12.sp) }

        // ---------- Arquivos ----------
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            files.forEach { f ->
                val sel = f == current
                Text(
                    f, fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 1,
                    color = if (sel) NexoColors.deep else NexoColors.text,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                        .background(if (sel) NexoColors.cyan else Color.White.copy(alpha = 0.08f))
                        .clickable { if (!sel) openFile(f) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
            Text(
                "+ arquivo", fontSize = 12.sp, color = NexoColors.cyan,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, NexoColors.cyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .clickable { showNewFile = true }.padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }

        // ---------- Barra de ferramentas ----------
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolButton("💾 Salvar", enabled = dirty) { save() }
            ToolButton("▶ Rodar", enabled = busy.isBlank() && current.isNotBlank()) { run() }
            ToolButton("🔁 Rodar e corrigir", enabled = busy.isBlank() && lang.runnable) { runAndFix() }
            ToolButton("🤖 IA", enabled = busy.isBlank() && current.isNotBlank()) { showAiMenu = true }
            ToolButton("🔍 Buscar") { showSearch = !showSearch }
            ToolButton("🕘 Histórico", enabled = current.isNotBlank()) { save(); showHistory = true }
            ToolButton("📦 Exportar") { save(); exportLauncher.launch("$project.zip") }
            ToolButton("⬆ GitHub") { save(); showPush = true }
            ToolButton("☁ Drive", enabled = Container.connectors.googleConnected()) {
                save()
                busy = "Enviando para o Google Drive…"
                scope.launch {
                    output = try {
                        val bytes = java.io.ByteArrayOutputStream().also { bos ->
                            java.util.zip.ZipOutputStream(bos).use { zip ->
                                store.files(project).forEach { path ->
                                    zip.putNextEntry(java.util.zip.ZipEntry("$project/$path"))
                                    zip.write(store.read(project, path).toByteArray())
                                    zip.closeEntry()
                                }
                            }
                        }.toByteArray()
                        "✅ Projeto salvo no Drive (pasta NEXO): " + com.jeconias.nexo.connectors.GoogleServices.driveUpload(ctx, "$project.zip", bytes, "application/zip")
                    } catch (e: Exception) { "❌ ${e.message}" }
                    outputError = output.startsWith("❌")
                    panel = Panel.OUTPUT
                    busy = ""
                }
            }
            ToolButton("⋯ Arquivo", enabled = current.isNotBlank()) { showFileMenu = true }
        }
        if (busy.isNotBlank()) Text("  $busy", color = NexoColors.amber, fontSize = 12.sp)

        // ---------- Busca ----------
        if (showSearch) {
            val count = if (query.isBlank()) 0 else Regex(Regex.escape(query), RegexOption.IGNORE_CASE).findAll(editor.text).count()
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("Buscar no arquivo") }, modifier = Modifier.weight(1f),
                )
                TextButton(onClick = {
                    if (query.isNotBlank()) {
                        val from = editor.selection.end
                        var idx = editor.text.indexOf(query, from, ignoreCase = true)
                        if (idx < 0) idx = editor.text.indexOf(query, 0, ignoreCase = true)
                        if (idx >= 0) editor = editor.copy(selection = TextRange(idx, idx + query.length))
                    }
                }) { Text("Próximo ($count)", maxLines = 1) }
            }
            if (query.isNotBlank() && count > 0) {
                val line = editor.text.substring(0, editor.selection.start.coerceAtMost(editor.text.length)).count { it == '\n' } + 1
                Muted("  Seleção na linha $line")
            }
        }

        // ---------- Editor ----------
        Box(Modifier.weight(if (panel == Panel.NONE) 1f else 0.5f).fillMaxWidth()) {
            if (current.isBlank()) EmptyArea("Crie um arquivo para começar.")
            else CodeEditor(editor, { editor = it; dirty = true }, lang, Modifier.fillMaxSize())
        }

        // ---------- Painel inferior ----------
        if (panel != Panel.NONE) {
            Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.05f)), verticalAlignment = Alignment.CenterVertically) {
                PanelTab("Construtor", panel == Panel.BUILDER) { panel = Panel.BUILDER }
                PanelTab("Saída", panel == Panel.OUTPUT) { panel = Panel.OUTPUT }
                PanelTab("Prévia", panel == Panel.PREVIEW) { previewKey++; panel = Panel.PREVIEW }
                PanelTab("IA", panel == Panel.AI) { panel = Panel.AI }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { panel = Panel.NONE }) { Text("✕", color = NexoColors.muted) }
            }
            Box(Modifier.weight(0.5f).fillMaxWidth().background(Color(0xFF050812))) {
                when (panel) {
                    Panel.OUTPUT -> SelectionContainer {
                        Text(
                            output.ifBlank { "Toque em ▶ Rodar para ver a saída aqui." },
                            color = if (outputError) Color(0xFFFFB4B4) else NexoColors.text,
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp),
                        )
                    }
                    Panel.PREVIEW -> Preview(store, project, current, previewKey) { line -> output += line + "\n" }
                    Panel.AI -> AiPanel(
                        answer = answer,
                        onReplace = { code -> editor = TextFieldValue(code); dirty = true; panel = Panel.NONE },
                        onNewFile = { code ->
                            val base = current.substringBeforeLast('.')
                            val ext = current.substringAfterLast('.', "txt")
                            var name = "test_${base.substringAfterLast('/')}.$ext"
                            var i = 2
                            while (files.contains(name)) name = "test_${base.substringAfterLast('/')}_${i++}.$ext"
                            store.write(project, name, code, keepHistory = false)
                            refresh++
                            openFile(name)
                            panel = Panel.NONE
                        },
                    )
                    Panel.BUILDER -> BuilderPanel(
                        convo = convo, plan = plan, busy = busy,
                        onApply = { p -> applyPlan(p); if (Language.of(current).runnable) runAndFix() },
                        onDiscard = { plan = null },
                    )
                    Panel.NONE -> Unit
                }
            }
        }
    }

    // ---------- Diálogos ----------
    if (showAiMenu) {
        var custom by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAiMenu = false },
            title = { Text("O que a IA deve fazer?") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    CodeAssistant.Action.entries.filter { it != CodeAssistant.Action.CUSTOM }.forEach { a ->
                        OutlinedButton(onClick = { showAiMenu = false; askAi(a) }, modifier = Modifier.fillMaxWidth()) { Text(a.label) }
                    }
                    OutlinedTextField(
                        value = custom, onValueChange = { custom = it }, minLines = 2,
                        placeholder = { Text("Ou peça qualquer coisa: “adicione um botão de limpar”") },
                    )
                    Button(
                        onClick = { showAiMenu = false; askAi(CodeAssistant.Action.CUSTOM, custom) },
                        enabled = custom.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Pedir") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showAiMenu = false }) { Text("Fechar") } },
        )
    }

    if (showPush) {
        var repo by remember { mutableStateOf(project) }
        var msg by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPush = false },
            title = { Text("Enviar para o GitHub") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (Container.connectors.githubToken().isBlank()) Muted("Primeiro cole o token do GitHub em MODELS → CONNECTORS.")
                    OutlinedTextField(value = repo, onValueChange = { repo = it }, singleLine = true, label = { Text("Repositório (criado privado se não existir)") })
                    OutlinedTextField(value = msg, onValueChange = { msg = it }, singleLine = true, label = { Text("Mensagem do envio") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showPush = false
                    busy = "Enviando para o GitHub…"
                    scope.launch {
                        output = try {
                            com.jeconias.nexo.connectors.GitHubConnector.pushProject(ctx, project, repo, msg)
                        } catch (e: Exception) { "❌ ${e.message}" }
                        outputError = output.startsWith("❌")
                        panel = Panel.OUTPUT
                        busy = ""
                    }
                }, enabled = repo.isNotBlank() && Container.connectors.githubToken().isNotBlank()) { Text("Enviar") }
            },
            dismissButton = { TextButton(onClick = { showPush = false }) { Text("Cancelar") } },
        )
    }

    if (showNewFile) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFile = false },
            title = { Text("Novo arquivo") },
            text = {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    placeholder = { Text("ex.: utils.py ou src/app.js") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isNotBlank() && store.newFile(project, n)) {
                        refresh++
                        openFile(n)
                    }
                    showNewFile = false
                }) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { showNewFile = false }) { Text("Cancelar") } },
        )
    }

    if (showFileMenu) {
        var newName by remember { mutableStateOf(current) }
        var confirmDelete by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showFileMenu = false },
            title = { Text(current) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true, label = { Text("Renomear para") })
                    OutlinedButton(onClick = {
                        save()
                        if (newName.isNotBlank() && newName != current && store.rename(project, current, newName)) {
                            current = newName
                            refresh++
                        }
                        showFileMenu = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("Renomear") }
                    if (!confirmDelete) {
                        TextButton(onClick = { confirmDelete = true }) { Text("Apagar arquivo", color = NexoColors.red) }
                    } else {
                        Button(onClick = {
                            store.deleteFile(project, current)
                            dirty = false
                            refresh++
                            current = store.files(project).firstOrNull() ?: ""
                            editor = TextFieldValue(if (current.isBlank()) "" else store.read(project, current))
                            showFileMenu = false
                        }, modifier = Modifier.fillMaxWidth()) { Text("Confirmar: apagar") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showFileMenu = false }) { Text("Fechar") } },
        )
    }

    if (showHistory) {
        val versions = remember(current) { store.history(project, current) }
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Histórico de $current") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (versions.isEmpty()) Muted("Nenhuma versão anterior ainda. Elas aparecem aqui a cada vez que você salva uma mudança.")
                    versions.forEach { v ->
                        OutlinedButton(onClick = {
                            editor = TextFieldValue(v.file.readText())
                            dirty = true
                            showHistory = false
                        }, modifier = Modifier.fillMaxWidth()) { Text("Voltar para ${v.label}") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showHistory = false }) { Text("Fechar") } },
        )
    }
}

@Composable
private fun BuilderPanel(
    convo: List<Pair<String, String>>,
    plan: CodeAssistant.BuildPlan?,
    busy: String,
    onApply: (CodeAssistant.BuildPlan) -> Unit,
    onDiscard: () -> Unit,
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (convo.isEmpty() && plan == null && busy.isBlank()) {
            Muted("Escreva no campo de cima o que você quer, do seu jeito. Ex.: “quero uma calculadora de horas extras com adicional de 50%”. A IA planeja, escreve todos os arquivos, roda e corrige.")
        }
        convo.forEach { (who, text) ->
            Text(who.uppercase(), color = if (who == "Você") NexoColors.cyan else NexoColors.amber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            SelectionContainer { Text(text, color = NexoColors.text, fontSize = 13.sp) }
        }
        if (busy.isNotBlank()) Text(busy, color = NexoColors.amber, fontSize = 12.sp)
        if (plan != null) {
            GlassCard {
                Text("PLANO DA IA", color = NexoColors.cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(plan.plan.ifBlank { "(sem explicação)" }, color = NexoColors.text, fontSize = 13.sp)
                plan.changes.forEach { c ->
                    Text("• ${c.action} ${c.path}" + if (!c.action.startsWith("apag")) " (${c.content.lines().size} linhas)" else "", color = NexoColors.muted, fontSize = 12.sp)
                }
                if (plan.changes.isEmpty()) Muted("A IA não propôs mudanças. Tente detalhar mais.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onApply(plan) }, enabled = plan.changes.isNotEmpty()) { Text("Aplicar e rodar") }
                    OutlinedButton(onClick = onDiscard) { Text("Descartar") }
                }
                Muted("As versões anteriores dos arquivos ficam no 🕘 Histórico.")
            }
        }
    }
}

@Composable
private fun ToolButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled) { Text(label, fontSize = 12.sp, maxLines = 1) }
}

@Composable
private fun PanelTab(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        color = if (selected) NexoColors.cyan else NexoColors.muted,
        modifier = Modifier.clickable { onClick() }.padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

@Composable
private fun AiPanel(answer: CodeAssistant.Answer?, onReplace: (String) -> Unit, onNewFile: (String) -> Unit) {
    if (answer == null) {
        EmptyArea("Toque em 🤖 IA para explicar, corrigir, melhorar, testar ou documentar o arquivo.")
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (answer.provider.isNotBlank()) Muted("via ${answer.provider}")
        SelectionContainer { Text(answer.text, color = NexoColors.text, fontSize = 13.sp) }
        val code = answer.code
        if (code != null) {
            Text("Código proposto (${code.lines().size} linhas):", color = NexoColors.cyan, fontSize = 12.sp)
            SelectionContainer {
                Text(
                    code.take(6000), color = NexoColors.text, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().background(Color(0xFF0B1124)).padding(8.dp),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onReplace(code) }) { Text("Aplicar no arquivo", maxLines = 1) }
                OutlinedButton(onClick = { onNewFile(code) }) { Text("Novo arquivo", maxLines = 1) }
            }
            Muted("Ao aplicar, a versão atual fica guardada no 🕘 Histórico quando você salvar.")
        }
    }
}

/** Prévia do site (index.html), com o console do JavaScript enviado para a Saída. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun Preview(store: ProjectStore, project: String, current: String, reloadKey: Int, onConsole: (String) -> Unit) {
    val page = when {
        current.endsWith(".html") || current.endsWith(".htm") -> current
        store.files(project).contains("index.html") -> "index.html"
        else -> null
    }
    if (page == null) {
        EmptyArea("Não há página HTML para mostrar. Crie um index.html.")
        return
    }
    val file = File(store.dir(project), page)
    key(reloadKey) {
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.allowFileAccess = true
                    settings.domStorageEnabled = true
                    webViewClient = WebViewClient()
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                            val level = if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) "ERRO" else "log"
                            onConsole("[$level] ${m.message()} (linha ${m.lineNumber()})")
                            return true
                        }
                    }
                    loadUrl("file://" + file.absolutePath)
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
    }
}
