package com.jeconias.nexo.voice

import android.content.Context
import com.jeconias.nexo.core.Settings
import okhttp3.OkHttpClient

/**
 * Gerente de voz com fila de reserva:
 * 1º a voz escolhida em "Usar esta voz", depois as outras configuradas,
 * e por último a voz do celular. Assim nunca fica mudo.
 * Edge-TTS: próxima fase (ver docs/STATUS.md).
 */
class VoiceManager(ctx: Context, private val settings: Settings, http: OkHttpClient) {
    private val system = SystemTts(ctx)
    val engines: List<VoiceEngine> = listOf(
        GeminiTts(settings, http, PcmPlayer()),
        ElevenLabsTts(ctx, settings, http),
        system,
    )

    @Volatile var lastUsed: String = ""
        private set

    val geminiVoices = listOf("Charon", "Kore", "Puck", "Fenrir", "Aoede", "Orus", "Zephyr", "Iapetus")

    /** Fala usando a fila de reserva. Retorna o nome da voz que funcionou. */
    suspend fun speak(text: String): String {
        val clean = text
            .replace(Regex("[*#`_>|]"), "")
            .replace(Regex("https?://\\S+"), "link")
            .trim()
        if (clean.isBlank()) return ""
        val activeId = settings.activeVoice()
        val ordered = engines.filter { it.id == activeId } +
            engines.filter { it.id != activeId && it.id != "system" } +
            listOf(system).filter { activeId != "system" }
        for (e in ordered) {
            if (!e.available()) continue
            if (e.speak(clean)) {
                lastUsed = e.label
                return e.label
            }
        }
        return ""
    }

    /** Testa uma voz específica, sem reserva, para saber se ela funciona sozinha. */
    suspend fun test(id: String): Boolean {
        val e = engines.firstOrNull { it.id == id } ?: return false
        if (!e.available()) return false
        return e.speak("Olá, ${settings.userName()}. Esta é a minha voz. Às suas ordens.")
    }

    fun stop() = engines.forEach { it.stop() }
}
