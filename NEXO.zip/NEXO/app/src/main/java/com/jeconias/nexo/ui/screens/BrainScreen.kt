package com.jeconias.nexo.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Switch
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle

private enum class BrainTab(val label: String) { MOTOR("Motor"), AGENTS("AGENTS.md"), MEMORY("MEMORY.md"), SKILLS("Skills") }

@Composable
fun BrainScreen() {
    var tab by remember { mutableStateOf(BrainTab.MOTOR) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BrainTab.entries.forEach { t ->
                if (t == tab) Button(onClick = {}) { Text(t.label, fontSize = 12.sp) }
                else OutlinedButton(onClick = { tab = t }) { Text(t.label, fontSize = 12.sp) }
            }
        }
        when (tab) {
            BrainTab.MOTOR -> MotorPanel()
            BrainTab.AGENTS -> AgentsEditor()
            BrainTab.MEMORY -> MemoryEditor()
            BrainTab.SKILLS -> SkillsList()
        }
    }
}

@Composable
private fun AgentsEditor() {
    val store = Container.context
    var text by remember { mutableStateOf(store.readAgents()) }
    var msg by remember { mutableStateOf("") }
    val lines = text.lines().size
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            SectionTitle("REGRAS DO AGENTE")
            Muted("Conduta, tom de voz e limites. Lido em toda mensagem. $lines/200 linhas.")
        }
        item {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = NexoColors.text),
                isError = lines > 200,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { msg = store.saveAgents(text) ?: "✅ Salvo. Vale a partir da próxima mensagem." }) { Text("Salvar") }
                TextButton(onClick = { store.resetAgents(); text = store.readAgents(); msg = "Restaurado o original." }) { Text("Restaurar original") }
            }
            if (msg.isNotBlank()) Muted(msg)
        }
    }
}

@Composable
private fun MemoryEditor() {
    val store = Container.context
    var text by remember { mutableStateOf(store.readMemory()) }
    var msg by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            SectionTitle("MEMÓRIA EVOLUTIVA")
            Muted("O que o agente aprendeu. Ele mesmo escreve aqui quando você corrige algo ou diz uma preferência. Você pode editar ou apagar linhas.")
        }
        item {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = NexoColors.text),
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { store.saveMemory(text); msg = "✅ Memória salva." }) { Text("Salvar") }
                TextButton(onClick = { text = store.readMemory(); msg = "Recarregado." }) { Text("Recarregar") }
            }
            if (msg.isNotBlank()) Muted(msg)
        }
    }
}

@Composable
private fun SkillsList() {
    val skills = Container.skills
    var refresh by remember { mutableIntStateOf(0) }
    val names = remember(refresh) { skills.names() }
    var editing by remember { mutableStateOf<String?>(null) }
    var editName by remember { mutableStateOf("") }
    var editText by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            SectionTitle("SKILLS")
            Muted("Procedimentos salvos. Peça “use a skill X” ou deixe o agente escolher. Ele também pode criar skills novas quando você pedir.")
            OutlinedButton(onClick = { editing = ""; editName = ""; editText = "# Nome — para que serve\n\n1. Primeiro passo\n2. Segundo passo" }) {
                Text("+ Nova skill")
            }
        }
        if (editing != null) {
            item {
                GlassCard {
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = editText, onValueChange = { editText = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 200.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = NexoColors.text),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            if (editName.isNotBlank()) { skills.save(editName, editText); editing = null; refresh++ }
                        }) { Text("Salvar") }
                        TextButton(onClick = { editing = null }) { Text("Cancelar") }
                        if (!editing.isNullOrBlank()) TextButton(onClick = {
                            skills.delete(editing!!); editing = null; refresh++
                        }) { Text("Apagar", color = NexoColors.red) }
                    }
                }
            }
        }
        items(names) { n ->
            val content = remember(n, refresh) { skills.read(n) ?: "" }
            GlassCard {
                Text(n, color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted(content.lineSequence().firstOrNull()?.removePrefix("#")?.trim() ?: "")
                TextButton(onClick = { editing = n; editName = n; editText = content }) { Text("Ver / editar") }
            }
        }
    }
}

@Composable
fun MotorPanel() {
    val settings = Container.settings
    var localOn by remember { mutableStateOf(settings.localEngine()) }
    var mode by remember { mutableStateOf(settings.councilMode()) }
    var refresh by remember { mutableIntStateOf(0) }
    val shortcuts = remember(refresh) { Container.shortcuts.all() }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            GlassCard {
                SectionTitle("MOTOR LOCAL")
                Muted("Resolve na hora, sem IA e sem internet, os comandos diretos. E aprende atalhos com o que a IA resolve.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Motor Local ligado", color = NexoColors.text, modifier = Modifier.weight(1f))
                    Switch(checked = localOn, onCheckedChange = { localOn = it; settings.setLocalEngine(it) })
                }
                Muted("Se ele errar, diga “errado” ou “não era isso”: ele esquece o atalho e pede para a IA resolver.")
            }
        }
        item {
            GlassCard {
                SectionTitle("CONSELHO DE IAS")
                Muted("Estrategista propõe, Crítico aponta falhas, Juiz decide. Usa 3 chamadas de IA por pedido.")
                listOf(
                    "auto" to "Pedidos complexos + quando eu pedir",
                    "pedido" to "Só quando eu pedir (“consulta o conselho”)",
                    "off" to "Desligado",
                ).forEach { (id, label) ->
                    val sel = mode == id
                    if (sel) Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text(label, maxLines = 2) }
                    else OutlinedButton(onClick = { mode = id; settings.setCouncilMode(id) }, modifier = Modifier.fillMaxWidth()) { Text(label, maxLines = 2) }
                }
                Muted("Usado hoje: ${settings.councilUsedToday()} de ${settings.councilMaxPerDay()} vezes.")
            }
        }
        item { SectionTitle("ATALHOS APRENDIDOS (${shortcuts.size})") }
        if (shortcuts.isEmpty()) item { Muted("Nenhum ainda. Quando a IA resolver um pedido simples, ele vira atalho aqui.") }
        items(shortcuts, key = { it.phrase }) { sc ->
            GlassCard {
                Text("“${sc.phrase}”", color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted("→ ${sc.tool} · usado ${sc.uses}x · " + if (sc.uses < 2) "ainda pede confirmação" else "age sozinho")
                TextButton(onClick = { Container.shortcuts.forget(sc.phrase); refresh++ }) { Text("Esquecer", color = NexoColors.red) }
            }
        }
    }
}
