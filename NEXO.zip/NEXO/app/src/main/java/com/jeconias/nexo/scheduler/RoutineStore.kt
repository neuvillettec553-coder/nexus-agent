package com.jeconias.nexo.scheduler

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Rotinas = instruções que o agente executa sozinho, em horário marcado,
 * e entrega o resultado numa notificação. Usa o WorkManager do Android,
 * que continua valendo depois de reiniciar o celular.
 */
data class Routine(
    val id: String,
    val nome: String,
    val instrucao: String,
    val tipo: String,   // "diaria" ou "intervalo"
    val hora: String,   // "HH:mm" (rotina diária)
    val horas: Int,     // a cada X horas (rotina por intervalo)
)

class RoutineStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nexo_rotinas", Context.MODE_PRIVATE)

    @Synchronized
    fun all(): List<Routine> {
        val arr = JSONArray(prefs.getString("lista", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Routine(o.getString("id"), o.getString("nome"), o.getString("instrucao"),
                o.getString("tipo"), o.optString("hora", "08:00"), o.optInt("horas", 24))
        }
    }

    fun get(id: String): Routine? = all().firstOrNull { it.id == id }

    @Synchronized
    private fun saveAll(list: List<Routine>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("nome", it.nome).put("instrucao", it.instrucao)
                .put("tipo", it.tipo).put("hora", it.hora).put("horas", it.horas))
        }
        prefs.edit().putString("lista", arr.toString()).apply()
    }

    fun add(nome: String, instrucao: String, tipo: String, hora: String, horas: Int): Routine {
        val r = Routine(UUID.randomUUID().toString().take(8), nome, instrucao, tipo, hora, horas)
        saveAll(all() + r)
        schedule(r)
        return r
    }

    fun remove(id: String): Boolean {
        val before = all()
        val r = before.firstOrNull { it.id == id || it.nome.equals(id, ignoreCase = true) } ?: return false
        saveAll(before - r)
        WorkManager.getInstance(ctx).cancelUniqueWork("rotina_${r.id}")
        return true
    }

    /** Depois de restaurar um backup: agenda de novo todas as rotinas. */
    fun rescheduleAll() = all().forEach { schedule(it) }

    private fun schedule(r: Routine) {
        val wm = WorkManager.getInstance(ctx)
        val data = workDataOf("id" to r.id)
        val request = if (r.tipo == "diaria") {
            PeriodicWorkRequestBuilder<RoutineWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delayUntil(r.hora), TimeUnit.MILLISECONDS)
                .setInputData(data).build()
        } else {
            val h = r.horas.coerceAtLeast(1).toLong()
            PeriodicWorkRequestBuilder<RoutineWorker>(h, TimeUnit.HOURS)
                .setInitialDelay(h, TimeUnit.HOURS)
                .setInputData(data).build()
        }
        wm.enqueueUniquePeriodicWork("rotina_${r.id}", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    /** Lembrete único: notificação depois de um tempo. */
    fun scheduleReminder(message: String, delayMs: Long) {
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("msg" to message))
            .addTag("lembrete")
            .build()
        WorkManager.getInstance(ctx).enqueue(req)
        saveReminder(message, System.currentTimeMillis() + delayMs)
    }

    @Synchronized
    private fun saveReminder(msg: String, at: Long) {
        val keep = JSONArray()
        upcomingReminders().forEach { (time, text) -> keep.put(JSONObject().put("at", time).put("msg", text)) }
        keep.put(JSONObject().put("at", at).put("msg", msg))
        prefs.edit().putString("lembretes", keep.toString()).apply()
    }

    /** Lembretes que ainda vão tocar, do mais próximo para o mais distante. */
    fun upcomingReminders(): List<Pair<Long, String>> {
        val arr = JSONArray(prefs.getString("lembretes", "[]"))
        val now = System.currentTimeMillis()
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .map { it.getLong("at") to it.getString("msg") }
            .filter { it.first > now }
            .sortedBy { it.first }
    }

    companion object {
        fun delayUntil(hhmm: String): Long {
            val parts = hhmm.split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: 8
            val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (!after(now)) add(Calendar.DAY_OF_MONTH, 1)
            }
            return target.timeInMillis - now.timeInMillis
        }
    }
}
