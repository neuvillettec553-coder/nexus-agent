package com.jeconias.nexo.ui.holo

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.ui.Phase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Núcleo "AI": anéis concêntricos azuis brilhantes alternando com filamentos pontilhados laranja-neon,
 * nós radiais ligados ao centro e mira em cruz. Acelera e muda de tom conforme o estado do Alfredo.
 */
@Composable
fun CognitiveCore(phase: Phase, modifier: Modifier = Modifier) {
    val main by animateColorAsState(
        when (phase) {
            Phase.IDLE -> HoloBlue
            Phase.LISTENING -> Color(0xFFB18CFF)
            Phase.THINKING -> HoloCyan
            Phase.ACTING -> HoloOrange
            Phase.SPEAKING -> Color(0xFF5CFFB0)
        }, tween(500), label = "corPrincipal",
    )
    val speed = when (phase) {
        Phase.IDLE -> 1f; Phase.LISTENING -> 1.8f; Phase.THINKING -> 3.4f; Phase.ACTING -> 4.2f; Phase.SPEAKING -> 2.2f
    }
    val speedState = rememberUpdatedState(speed)
    var angle by remember { mutableFloatStateOf(0f) }
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = (now - last) / 1_000_000_000f
                    angle = (angle + dt * 24f * speedState.value) % 360f
                    time += dt
                }
                last = now
            }
        }
    }

    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f * 0.78f
            val orange = HoloOrange
            val px = 1.dp.toPx()
            fun ring(radius: Float) = Pair(Offset(c.x - radius, c.y - radius), Size(radius * 2, radius * 2))

            // bloom de fundo
            drawCircle(Brush.radialGradient(listOf(main.copy(alpha = 0.35f), Color.Transparent), c, r * 1.35f), r * 1.35f, c)

            // mira em cruz laranja (fora dos anéis)
            for (k in 0 until 4) {
                val a = k * PI.toFloat() / 2f
                val d = Offset(cos(a), sin(a))
                drawLine(orange.copy(alpha = 0.85f), c + d * (r * 1.06f), c + d * (r * 1.32f), 2 * px)
                drawLine(orange.copy(alpha = 0.25f), c + d * (r * 1.06f), c + d * (r * 1.32f), 7 * px)
            }

            // anel externo azul com segmentos girando
            drawCircle(main.copy(alpha = 0.35f), r * 1.02f, c, style = Stroke(px))
            rotate(angle, c) {
                val (tl, sz) = ring(r)
                for (i in 0 until 16) drawArc(main, i * 22.5f, 13f, false, tl, sz, style = Stroke(3 * px, cap = StrokeCap.Round))
            }
            // filamento laranja pontilhado (gira ao contrário)
            rotate(-angle * 1.4f, c) {
                drawCircle(orange.copy(alpha = 0.9f), r * 0.88f, c, style = Stroke(2 * px, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2 * px, 6 * px))))
            }
            // anel azul com nós radiais ligados ao centro
            val rn = r * 0.74f
            drawCircle(main.copy(alpha = 0.55f), rn, c, style = Stroke(1.5f * px))
            rotate(angle * 0.6f, c) {
                for (i in 0 until 8) {
                    val a = i * PI.toFloat() / 4f
                    val p = c + Offset(cos(a), sin(a)) * rn
                    val inner = c + Offset(cos(a), sin(a)) * (r * 0.44f)
                    drawLine(main.copy(alpha = 0.35f), inner, p, px)
                    drawCircle(Color.White, 3.2f * px, p)
                    drawCircle(main.copy(alpha = 0.5f), 7 * px, p)
                }
            }
            // segundo filamento laranja tracejado
            rotate(angle * 2f, c) {
                drawCircle(orange.copy(alpha = 0.75f), r * 0.60f, c, style = Stroke(1.5f * px, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10 * px, 8 * px))))
            }
            // mostrador interno
            val ra = r * 0.47f
            val rb = r * 0.52f
            rotate(-angle * 0.4f, c) {
                for (i in 0 until 72) {
                    val a = i * 5f * PI.toFloat() / 180f
                    val major = i % 6 == 0
                    drawLine(
                        main.copy(alpha = if (major) 0.95f else 0.35f),
                        c + Offset(cos(a), sin(a)) * ra, c + Offset(cos(a), sin(a)) * (if (major) rb + 3 * px else rb),
                        if (major) 2 * px else px,
                    )
                }
            }
            // onda de voz (ouvindo / falando)
            if (phase == Phase.SPEAKING || phase == Phase.LISTENING) {
                val path = Path()
                for (k in 0..140) {
                    val th = k / 140f * 2f * PI.toFloat()
                    val rr = r * 0.38f + r * 0.06f * sin(th * 9f + time * 11f) * sin(time * 3f + th * 2f)
                    val p = c + Offset(cos(th), sin(th)) * rr
                    if (k == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
                }
                path.close()
                drawPath(path, main, style = Stroke(2 * px))
            }
            // satélites (pensando / executando)
            if (phase == Phase.THINKING || phase == Phase.ACTING) {
                for (i in 0 until 3) {
                    val a = (angle * 3f + i * 120f) * PI.toFloat() / 180f
                    drawCircle(orange, 4 * px, c + Offset(cos(a), sin(a)) * (r * 0.88f))
                }
            }
            // esfera central
            val pulse = 1f + 0.06f * sin(time * (if (phase == Phase.SPEAKING) 9f else 2f))
            drawCircle(Brush.radialGradient(listOf(main.copy(alpha = 0.55f), Color(0xFF071430), Color.Transparent), c, r * 0.36f * pulse), r * 0.36f * pulse, c)
            drawCircle(main, r * 0.30f, c, style = Stroke(2 * px))
        }
        Text(
            "AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace, letterSpacing = 2.sp,
        )
    }
}
