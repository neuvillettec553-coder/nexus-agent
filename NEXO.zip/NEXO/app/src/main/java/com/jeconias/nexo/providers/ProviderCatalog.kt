package com.jeconias.nexo.providers

enum class ApiStyle { OPENAI, ANTHROPIC }

data class ProviderInfo(
    val id: String,
    val name: String,
    val baseUrl: String,
    val defaultModel: String,
    val style: ApiStyle,
    val free: Boolean,
    val keyUrl: String,
)

/**
 * Lista de provedores. Quase todos falam o "dialeto OpenAI", então uma única
 * implementação cobre a maioria. O modelo de cada um pode ser trocado na aba IAs,
 * porque os nomes de modelo mudam com o tempo.
 */
object ProviderCatalog {
    val all: List<ProviderInfo> = listOf(
        ProviderInfo("groq", "Groq", "https://api.groq.com/openai/v1",
            "openai/gpt-oss-120b", ApiStyle.OPENAI, true, "https://console.groq.com/keys"),
        ProviderInfo("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai",
            "gemini-3.8-flash", ApiStyle.OPENAI, true, "https://aistudio.google.com/apikey"),
        ProviderInfo("cerebras", "Cerebras", "https://api.cerebras.ai/v1",
            "gpt-oss-120b", ApiStyle.OPENAI, true, "https://cloud.cerebras.ai"),
        ProviderInfo("mistral", "Mistral", "https://api.mistral.ai/v1",
            "mistral-small-latest", ApiStyle.OPENAI, true, "https://console.mistral.ai/api-keys"),
        ProviderInfo("openrouter", "OpenRouter (vários grátis)", "https://openrouter.ai/api/v1",
            "openrouter/free", ApiStyle.OPENAI, true, "https://openrouter.ai/keys"),
        ProviderInfo("nvidia", "NVIDIA (Nemotron)", "https://integrate.api.nvidia.com/v1",
            "nvidia/nemotron-3-super-120b-a12b", ApiStyle.OPENAI, true, "https://build.nvidia.com/settings/api-keys"),
        ProviderInfo("glm", "GLM (Zhipu)", "https://open.bigmodel.cn/api/paas/v4",
            "glm-4-flash", ApiStyle.OPENAI, true, "https://open.bigmodel.cn"),
        ProviderInfo("deepseek", "DeepSeek", "https://api.deepseek.com/v1",
            "deepseek-chat", ApiStyle.OPENAI, false, "https://platform.deepseek.com/api_keys"),
        ProviderInfo("qwen", "Qwen (Alibaba)", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
            "qwen-plus", ApiStyle.OPENAI, false, "https://bailian.console.aliyun.com"),
        ProviderInfo("kimi", "Kimi (Moonshot)", "https://api.moonshot.ai/v1",
            "moonshot-v1-8k", ApiStyle.OPENAI, false, "https://platform.moonshot.ai"),
        ProviderInfo("openai", "OpenAI", "https://api.openai.com/v1",
            "gpt-4o-mini", ApiStyle.OPENAI, false, "https://platform.openai.com/api-keys"),
        ProviderInfo("anthropic", "Claude (Anthropic)", "https://api.anthropic.com/v1",
            "claude-sonnet-5-5", ApiStyle.ANTHROPIC, false, "https://console.anthropic.com"),
    )

    fun byId(id: String): ProviderInfo? = all.firstOrNull { it.id == id }
}
