package com.jeconias.nexo.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors

fun stageColor(stage: String): Color = when (stage) {
    "MOTOR LOCAL" -> NexoColors.green
    "TRIAGEM" -> NexoColors.muted
    "ESTRATEGISTA" -> NexoColors.cyan
    "CRÍTICO" -> NexoColors.red
    "JUIZ" -> NexoColors.violet
    "AGENTE" -> NexoColors.cyan
    "AÇÃO" -> NexoColors.amber
    "CONFIRMAÇÃO" -> NexoColors.amber
    else -> NexoColors.text
}

private fun seconds(ms: Long): String = if (ms <= 0) "" else "%.1fs".format(ms / 1000f)

/** Linha compacta de um evento (usada no painel do Núcleo). */
@Composable
fun FlowEventLine(e: FlowLog.Event) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("● ", color = if (e.ok) stageColor(e.stage) else NexoColors.red, fontSize = 11.sp)
        Text(
            "${e.stage} · ${e.who} ${seconds(e.ms)}", color = NexoColors.text, fontSize = 11.sp,
            fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Tela completa do FLUXO: cada pedido e, dentro dele, quem fez o quê, na ordem. */
@Composable
fun FlowScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Núcleo", color = NexoColors.cyan, maxLines = 1) }
            Text("FLUXO", color = NexoColors.text, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, fontSize = 15.sp)
        }
        if (FlowLog.requests.isEmpty()) {
            Muted("  Nenhum pedido ainda. Fale com o Alfredo e acompanhe aqui, ao vivo, cada etapa.")
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(FlowLog.requests, key = { it.id }) { r ->
                GlassCard {
                    Text("PEDIDO · ${r.time}", color = NexoColors.cyan, fontSize = 10.sp, letterSpacing = 2.sp, fontFamily = FontFamily.Monospace)
                    Text(r.question, color = NexoColors.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    FlowLog.eventsOf(r.id).forEach { e -> FlowEventCard(e) }
                }
            }
        }
    }
}

@Composable
private fun FlowEventCard(e: FlowLog.Event) {
    var open by remember { mutableStateOf(false) }
    val color = if (e.ok) stageColor(e.stage) else NexoColors.red
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.08f))
            .clickable { open = !open }
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                e.stage, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace, letterSpacing = 1.sp,
            )
            Spacer(Modifier.width(6.dp))
            Text(
                "${e.who} ${seconds(e.ms)}", color = NexoColors.muted, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            Text(e.time, color = NexoColors.muted, fontSize = 10.sp)
        }
        Text(
            e.text, color = NexoColors.text, fontSize = 12.sp,
            maxLines = if (open) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
        )
    }
}
