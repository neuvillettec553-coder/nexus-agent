package com.jeconias.nexo.live

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.math.roundToInt

data class WeatherNow(val city: String, val temp: Int, val min: Int, val max: Int, val desc: String, val icon: String)

/**
 * Dados ao vivo do painel holográfico.
 * Clima: Open-Meteo (grátis, sem chave). Notícias: Google Notícias (RSS, sem chave).
 */
object LiveData {

    fun battery(ctx: Context): Pair<Int, Boolean> {
        val bm = ctx.getSystemService(BatteryManager::class.java) ?: return -1 to false
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) to bm.isCharging
    }

    fun network(ctx: Context): String {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return "?"
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dados móveis"
            else -> "Conectado"
        }
    }

    private fun getJson(http: OkHttpClient, url: String): JSONObject? {
        val req = Request.Builder().url(url).header("User-Agent", "NEXO/1.0").build()
        return http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) null else JSONObject(r.body?.string().orEmpty())
        }
    }

    suspend fun weather(http: OkHttpClient, city: String): WeatherNow? = withContext(Dispatchers.IO) {
        if (city.isBlank()) return@withContext null
        try {
            val geo = getJson(
                http,
                "https://geocoding-api.open-meteo.com/v1/search?count=1&language=pt&name=" +
                    URLEncoder.encode(city.trim(), "UTF-8")
            ) ?: return@withContext null
            val place = geo.optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val f = getJson(
                http,
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min" +
                    "&timezone=auto&forecast_days=1"
            ) ?: return@withContext null
            val cur = f.getJSONObject("current")
            val daily = f.getJSONObject("daily")
            val (desc, icon) = describe(cur.optInt("weather_code", 0))
            WeatherNow(
                place.optString("name", city),
                cur.getDouble("temperature_2m").roundToInt(),
                daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                desc, icon,
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun news(http: OkHttpClient): List<String> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://news.google.com/rss?hl=pt-BR&gl=BR&ceid=BR:pt-419")
                .header("User-Agent", "Mozilla/5.0")
                .build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return@use emptyList<String>()
                val xml = r.body?.string().orEmpty()
                Regex("(?s)<item>.*?<title>(.*?)</title>").findAll(xml)
                    .map { clean(it.groupValues[1]) }
                    .filter { it.isNotBlank() }
                    .take(8)
                    .toList()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun clean(s: String) = s
        .replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        .replace("&lt;", "<").replace("&gt;", ">")
        .trim()

    private fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "Céu limpo" to "☀️"
        1, 2 -> "Poucas nuvens" to "⛅"
        3 -> "Nublado" to "☁️"
        45, 48 -> "Neblina" to "🌫️"
        in 51..57 -> "Garoa" to "🌦️"
        in 61..67 -> "Chuva" to "🌧️"
        in 71..77 -> "Neve" to "❄️"
        in 80..82 -> "Pancadas de chuva" to "🌧️"
        in 95..99 -> "Tempestade" to "⛈️"
        else -> "—" to "🌡️"
    }
}
