package com.jeconias.nexo.life

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.Notifications
import com.jeconias.nexo.scheduler.RoutineStore
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Todo dia às 8h: avisa as contas que vencem amanhã e os limites de gasto estourando. */
class BillWatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Container.init(applicationContext)
        val store = Container.life
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 1) }.get(Calendar.DAY_OF_MONTH)
        val due = store.unpaidBills().filter { it.optInt("dia") == tomorrow }
        if (due.isNotEmpty()) {
            Notifications.show(
                applicationContext, "💰 Contas vencem amanhã",
                due.joinToString("\n") { "${it.optString("nome")}: ${FinanceMath.money(it.optDouble("valor", 0.0))}" },
            )
        }
        val sum = store.monthSummary()
        val over = store.list(LifeStore.BUDGETS).mapNotNull { b ->
            val spent = sum.byCategory.firstOrNull { it.first.equals(b.optString("categoria"), true) }?.second ?: 0.0
            val use = FinanceMath.budgetUse(spent, b.optDouble("limite", 0.0))
            if (use >= 80) "${b.optString("categoria")}: $use% do limite" else null
        }
        if (over.isNotEmpty()) Notifications.show(applicationContext, "⚠️ Limites de gasto", over.joinToString("\n"))
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<BillWatchWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(RoutineStore.delayUntil("08:00"), TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("vigia_contas", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
