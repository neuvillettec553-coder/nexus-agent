package com.jeconias.nexo.ui.deck

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.Metrics
import com.jeconias.nexo.live.LiveData
import com.jeconias.nexo.live.WeatherNow
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.holo.LocalProjector
import com.jeconias.nexo.ui.holo.Projection
import com.jeconias.nexo.ui.hud.rememberTilt
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.delay

private const val BRIEF_NAME = "Resumo da manhã"
private const val BRIEF_INSTRUCTION =
    "Monte o meu resumo da manhã. Use clima_agora, agenda_listar (1 dia), tarefa_listar, fin_resumo e vida_resumo. " +
        "Responda em até 6 frases curtas: clima, compromissos, as 3 tarefas mais importantes, contas que vencem e saldo, " +
        "hábitos do dia, e termine com UM foco para o dia."

/** PREDICT: finanças, vida, agenda, resumo da manhã, clima, agenda de lembretes e notícias. */
@Composable
fun PredictDeck() {
    val projector = LocalProjector.current
    val tilt = rememberTilt()
    val settings = Container.settings
    var tick by remember { mutableIntStateOf(0) }
    var city by remember { mutableStateOf(settings.city()) }
    var weather by remember { mutableStateOf<WeatherNow?>(null) }
    var weatherMsg by remember { mutableStateOf("") }
    var news by remember { mutableStateOf<List<String>>(emptyList()) }
    var headline by remember { mutableIntStateOf(0) }
    var askCity by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { while (true) { delay(15_000); tick++ } }
    LaunchedEffect(city) {
        while (true) {
            if (city.isBlank()) { weather = null; weatherMsg = "Toque para definir sua cidade" }
            else {
                weatherMsg = "Buscando…"
                weather = LiveData.weather(Container.http, city)
                if (weather == null) weatherMsg = "Sem dados agora. Toque para trocar a cidade."
            }
            delay(30 * 60_000L)
        }
    }
    LaunchedEffect(Unit) {
        while (true) { val n = LiveData.news(Container.http); if (n.isNotEmpty()) news = n; delay(30 * 60_000L) }
    }
    LaunchedEffect(news) { while (news.isNotEmpty()) { delay(7000); headline = (headline + 1) % news.size } }

    val upcoming = remember(tick, Metrics.version) { upcomingItems() }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val lifeVersion = Container.life.version
    val forecast = remember(lifeVersion, tick) { Container.life.forecast() }
    val openTasks = remember(lifeVersion, tick) { Container.life.openTasks().size }
    var hasCalendar by remember { mutableStateOf(com.jeconias.nexo.life.Agenda.hasPermission(ctx)) }
    var events by remember { mutableStateOf<List<com.jeconias.nexo.life.Agenda.Event>>(emptyList()) }
    val calendarPermission = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { hasCalendar = com.jeconias.nexo.life.Agenda.hasPermission(ctx) }
    LaunchedEffect(hasCalendar, tick) { if (hasCalendar) events = com.jeconias.nexo.life.Agenda.upcoming(ctx, 2) }
    var askBrief by remember { mutableStateOf(false) }
    val briefRoutine = remember(tick, askBrief) { Container.routines.all().firstOrNull { it.nome == BRIEF_NAME } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        DeckHeader(
            "PREDICTIVE ENGINE", "SCHEDULE · CONTEXT · LIFE MODULES",
            "Scheduled" to "${upcoming.size}", "Requests today" to "${Metrics.requestsToday()}",
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HoloTile("WEATHER", tilt, Modifier.weight(1f), accent = HoloCyan, onClick = { askCity = true }) {
                val w = weather
                if (w != null) {
                    Text("${w.icon} ${w.temp}°", color = NexoColors.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(w.desc, color = NexoColors.text, fontSize = 12.sp, maxLines = 1)
                    Muted("${w.min}° / ${w.max}° · ${w.city}")
                } else Muted(weatherMsg)
            }
            HoloTile("SCHEDULE", tilt, Modifier.weight(1f), accent = HoloOrange, onClick = {
                projector.project(Projection("Agenda e rotinas", HoloOrange) { SchedulePanel() })
            }) {
                if (upcoming.isEmpty()) Muted("Nada agendado.")
                upcoming.take(3).forEach { Text(it, color = NexoColors.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }
        }
        Spacer(Modifier.height(8.dp))
        HoloTile("NEWS FEED", tilt, Modifier.fillMaxWidth().padding(horizontal = 10.dp), accent = HoloBlue, onClick = {
            projector.project(Projection("Notícias", HoloBlue) { NewsPanel(news) })
        }) {
            Crossfade(targetState = news.getOrNull(headline), label = "manchete") { h ->
                Text(h ?: "Carregando manchetes…", color = NexoColors.text, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HoloTile("FINANCE CORE", tilt, Modifier.weight(1f), accent = HoloOrange, depth = 1.3f, onClick = {
                projector.project(Projection("Central Financeira", HoloOrange) { com.jeconias.nexo.ui.life.FinanceScreen() })
            }) {
                Text("💰", fontSize = 20.sp)
                Text(com.jeconias.nexo.life.FinanceMath.money(forecast), color = if (forecast < 0) NexoColors.red else NexoColors.green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Muted("previsão do mês")
            }
            HoloTile("LIFE", tilt, Modifier.weight(1f), accent = HoloCyan, depth = 1.1f, onClick = {
                projector.project(Projection("Vida", HoloCyan) { com.jeconias.nexo.ui.life.LifeScreen() })
            }) {
                Text("🎯", fontSize = 20.sp)
                Text("${openTasks} tarefa(s)", color = NexoColors.text, fontSize = 13.sp)
                Muted("hábitos e metas")
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HoloTile("AGENDA", tilt, Modifier.weight(1f), accent = HoloBlue, onClick = {
                if (!hasCalendar) calendarPermission.launch(arrayOf(android.Manifest.permission.READ_CALENDAR, android.Manifest.permission.WRITE_CALENDAR))
            }) {
                if (!hasCalendar) Muted("Toque para permitir o acesso à agenda.")
                else if (events.isEmpty()) Muted("Nada nos próximos 2 dias.")
                events.take(3).forEach { Text(com.jeconias.nexo.life.Agenda.format(it), color = NexoColors.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }
            HoloTile("MORNING BRIEF", tilt, Modifier.weight(1f), accent = HoloOrange, onClick = { askBrief = true }) {
                Text("☀️", fontSize = 20.sp)
                Muted(briefRoutine?.let { "todo dia ${it.hora}" } ?: "toque para ativar")
            }
        }
        Spacer(Modifier.height(10.dp))
    }

    if (askBrief) {
        var hour by remember { mutableStateOf(briefRoutine?.hora ?: "06:00") }
        AlertDialog(
            onDismissRequest = { askBrief = false },
            title = { Text("Resumo da manhã") },
            text = {
                Column {
                    Muted("Todo dia, no horário escolhido, o Alfredo junta clima, agenda, tarefas, contas e hábitos num aviso só. Escolha um horário antes do seu turno.")
                    OutlinedTextField(value = hour, onValueChange = { hour = it }, singleLine = true, label = { Text("Horário (HH:MM)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    briefRoutine?.let { Container.routines.remove(it.id) }
                    if (Regex("^\\d{1,2}:\\d{2}$").matches(hour.trim())) {
                        Container.routines.add(BRIEF_NAME, BRIEF_INSTRUCTION, "diaria", hour.trim().padStart(5, '0'), 24)
                    }
                    askBrief = false; tick++
                }) { Text("Ativar") }
            },
            dismissButton = {
                TextButton(onClick = { briefRoutine?.let { Container.routines.remove(it.id) }; askBrief = false; tick++ }) {
                    Text(if (briefRoutine != null) "Desativar" else "Cancelar")
                }
            },
        )
    }

    if (askCity) {
        var typed by remember { mutableStateOf(city) }
        AlertDialog(
            onDismissRequest = { askCity = false },
            title = { Text("Sua cidade") },
            text = { OutlinedTextField(value = typed, onValueChange = { typed = it }, singleLine = true, placeholder = { Text("Ex.: Joinville") }) },
            confirmButton = { TextButton(onClick = { settings.setCity(typed); city = typed.trim(); askCity = false }) { Text("Salvar") } },
            dismissButton = { TextButton(onClick = { askCity = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun SchedulePanel() {
    var refresh by remember { mutableIntStateOf(0) }
    val reminders = remember(refresh) { Container.routines.upcomingReminders() }
    val routines = remember(refresh) { Container.routines.all() }
    val fmt = remember { java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale("pt", "BR")) }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("LEMBRETES", color = HoloOrange, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        if (reminders.isEmpty()) item { Muted("Nenhum. Diga: “me lembra daqui 10 minutos de…”") }
        items(reminders) { (at, msg) -> GlassCard { Text("⏰ ${fmt.format(java.util.Date(at))}", color = NexoColors.text); Muted(msg) } }
        item { Text("ROTINAS AUTOMÁTICAS", color = HoloCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        if (routines.isEmpty()) item { Muted("Nenhuma. Diga: “todo dia às 7h me dá a previsão do tempo”.") }
        items(routines, key = { it.id }) { r ->
            GlassCard {
                Text(r.nome, color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted((if (r.tipo == "diaria") "Todo dia às ${r.hora}" else "A cada ${r.horas}h") + " · ${r.instrucao}")
                TextButton(onClick = { Container.routines.remove(r.id); refresh++ }) { Text("Cancelar rotina", color = NexoColors.red) }
            }
        }
    }
}

@Composable
private fun NewsPanel(news: List<String>) {
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (news.isEmpty()) item { Muted("Sem manchetes agora (confira a internet).") }
        items(news) { GlassCard { Text(it, color = NexoColors.text, fontSize = 14.sp) } }
        item { Muted("Fonte: Google Notícias. Peça ao Alfredo para resumir qualquer uma.") }
    }
}

