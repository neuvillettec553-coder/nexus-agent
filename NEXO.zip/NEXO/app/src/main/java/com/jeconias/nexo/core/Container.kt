package com.jeconias.nexo.core

import android.content.Context
import com.jeconias.nexo.agent.AgentLoop
import com.jeconias.nexo.agent.Orchestrator
import com.jeconias.nexo.agent.ShortcutStore
import com.jeconias.nexo.context.ContextStore
import com.jeconias.nexo.context.SkillStore
import com.jeconias.nexo.mcp.McpManager
import com.jeconias.nexo.providers.ProviderRouter
import com.jeconias.nexo.scheduler.RoutineStore
import com.jeconias.nexo.tools.ToolRegistry
import com.jeconias.nexo.tools.builtin.BuiltinTools
import com.jeconias.nexo.voice.VoiceManager
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Caixa central de dependências. Cada módulo recebe o que precisa daqui,
 * sem um módulo criar o outro por conta própria.
 */
object Container {
    lateinit var app: Context
        private set
    lateinit var settings: Settings
        private set
    lateinit var context: ContextStore
        private set
    lateinit var skills: SkillStore
        private set
    lateinit var router: ProviderRouter
        private set
    lateinit var tools: ToolRegistry
        private set
    lateinit var routines: RoutineStore
        private set
    lateinit var mcp: McpManager
        private set
    lateinit var voice: VoiceManager
        private set
    lateinit var shortcuts: ShortcutStore
        private set
    lateinit var life: com.jeconias.nexo.life.LifeStore
        private set
    lateinit var connectors: com.jeconias.nexo.connectors.ConnectorStore
        private set

    val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var ready = false

    @Synchronized
    fun init(appContext: Context) {
        if (ready) return
        app = appContext.applicationContext
        settings = Settings(app)
        context = ContextStore(app)
        skills = SkillStore(app)
        router = ProviderRouter(settings, http)
        routines = RoutineStore(app)
        tools = ToolRegistry()
        BuiltinTools.registerAll(tools, app, context, skills, routines, http)
        connectors = com.jeconias.nexo.connectors.ConnectorStore(app)
        tools.register(com.jeconias.nexo.connectors.GmailBuscar(app))
        tools.register(com.jeconias.nexo.connectors.GmailLer(app))
        tools.register(com.jeconias.nexo.connectors.GmailEnviar(app))
        tools.register(com.jeconias.nexo.connectors.GitHubRepos())
        com.jeconias.nexo.connectors.GoogleTools.registerAll(tools, app)
        tools.register(com.jeconias.nexo.connectors.GitHubEnviarProjeto(app))
        mcp = McpManager(settings, http, tools)
        voice = VoiceManager(app, settings, http)
        shortcuts = ShortcutStore(app)
        life = com.jeconias.nexo.life.LifeStore(app)
        com.jeconias.nexo.life.LifeTools.registerAll(tools, life, app)
        com.jeconias.nexo.life.BillWatchWorker.schedule(app)
        com.jeconias.nexo.context.MemoryCurator.schedule(app)
        ActionLog.init(app)
        Metrics.init(app)
        ready = true
    }

    fun newAgent(): AgentLoop = AgentLoop(router, tools, context, skills, settings)

    fun newCodeAssistant(): com.jeconias.nexo.studio.CodeAssistant = com.jeconias.nexo.studio.CodeAssistant(router)

    fun newOrchestrator(): Orchestrator = Orchestrator(router, tools, context, skills, settings, shortcuts)
}
