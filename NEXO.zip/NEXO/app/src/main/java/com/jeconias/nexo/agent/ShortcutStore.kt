package com.jeconias.nexo.agent

import android.content.Context
import org.json.JSONObject

/**
 * Atalhos aprendidos pelo Motor Local.
 * Quando a IA resolve um pedido simples com UMA ação que deu certo, a frase vira um atalho.
 * Atalho novo pede confirmação; depois de 2 usos confirmados, passa a agir sozinho.
 */
class ShortcutStore(ctx: Context) {
    data class Shortcut(val phrase: String, val tool: String, val args: String, val uses: Int)

    private val prefs = ctx.getSharedPreferences("nexo_atalhos", Context.MODE_PRIVATE)

    /** Só ações simples, previsíveis e que não enviam nada a ninguém. */
    val learnable = setOf("abrir_app", "criar_alarme", "abrir_link", "listar_notas", "listar_rotinas", "data_hora", "ler_skill")

    @Synchronized
    fun all(): List<Shortcut> {
        val o = JSONObject(prefs.getString("mapa", "{}") ?: "{}")
        return o.keys().asSequence().map { k ->
            val v = o.getJSONObject(k)
            Shortcut(k, v.getString("tool"), v.optString("args", "{}"), v.optInt("uses", 0))
        }.sortedByDescending { it.uses }.toList()
    }

    fun get(phrase: String): Shortcut? = all().firstOrNull { it.phrase == phrase }

    @Synchronized
    private fun save(list: List<Shortcut>) {
        val o = JSONObject()
        list.forEach { o.put(it.phrase, JSONObject().put("tool", it.tool).put("args", it.args).put("uses", it.uses)) }
        prefs.edit().putString("mapa", o.toString()).apply()
    }

    fun learn(phrase: String, tool: String, args: String) {
        if (tool !in learnable || phrase.length !in 3..60) return
        val list = all().filter { it.phrase != phrase }
        save((list + Shortcut(phrase, tool, args, 0)).take(300))
    }

    fun used(phrase: String) {
        save(all().map { if (it.phrase == phrase) it.copy(uses = it.uses + 1) else it })
    }

    fun forget(phrase: String) = save(all().filter { it.phrase != phrase })
}
