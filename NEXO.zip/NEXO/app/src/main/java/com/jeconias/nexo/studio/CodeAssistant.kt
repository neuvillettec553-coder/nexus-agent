package com.jeconias.nexo.studio

import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.providers.ChatMessage
import com.jeconias.nexo.providers.ProviderRouter
import org.json.JSONObject

/**
 * IA do Estúdio: engenheiro de software sênior que lê o projeto e devolve código completo.
 * Toda resposta passa pelo FLUXO (etapa "ESTÚDIO").
 */
class CodeAssistant(private val router: ProviderRouter) {

    enum class Action(val label: String, val instruction: String) {
        EXPLAIN("Explicar", "Explique de forma simples e didática o que este arquivo faz, parte por parte. Não reescreva o código."),
        FIX("Corrigir", "Encontre e corrija os erros deste arquivo. Use a saída de execução, se houver. Devolva o arquivo COMPLETO corrigido."),
        REFACTOR("Melhorar", "Refatore para ficar mais claro, organizado e profissional, sem mudar o comportamento. Devolva o arquivo COMPLETO."),
        TESTS("Criar testes", "Escreva testes automáticos para este código (assert em Python, console.assert/throw em JavaScript, asserções equivalentes em outras linguagens). Devolva o arquivo de teste COMPLETO."),
        DOCS("Documentar", "Adicione documentação e comentários úteis, em português, sem mudar o comportamento. Devolva o arquivo COMPLETO."),
        REVIEW("Revisar", "Faça uma revisão de código profissional: bugs, segurança, desempenho, legibilidade. Liste os pontos por prioridade. Não reescreva o código."),
        CUSTOM("Pedir", ""),
    }

    data class Answer(val text: String, val code: String?, val provider: String)

    private val system = """
        Você é um engenheiro de software sênior, didático e rigoroso, trabalhando no Estúdio do NEXO,
        num celular Android. Responda sempre em português do Brasil.
        Regras:
        - Código profissional: nomes claros, funções pequenas, tratamento de erros, sem gambiarras.
        - Quando devolver código, devolva o ARQUIVO COMPLETO dentro de UM único bloco ```linguagem ... ```.
        - Antes do bloco, explique em poucas linhas o que mudou e por quê.
        - Se faltar informação, diga o que assumiu.
        - Execução disponível no celular: Python 3.11 (só biblioteca padrão), JavaScript (motor do navegador,
          sem Node.js), Lua, SQL (SQLite) e Shell. HTML/CSS aparecem na prévia.
    """.trimIndent()

    private fun projectSummary(files: Map<String, String>, current: String): String = buildString {
        append("ARQUIVOS DO PROJETO: ").append(files.keys.joinToString()).append("\n")
        files.filterKeys { it != current }.entries.take(6).forEach { (p, c) ->
            append("\n--- $p (trecho) ---\n").append(c.take(1500)).append("\n")
        }
    }

    suspend fun ask(
        action: Action,
        file: String,
        content: String,
        projectFiles: Map<String, String>,
        lastOutput: String?,
        request: String = "",
    ): Answer {
        val lang = Language.of(file)
        val task = if (action == Action.CUSTOM) request else action.instruction + (if (request.isNotBlank()) "\nObservação do usuário: $request" else "")
        val user = buildString {
            append("TAREFA: ").append(task).append("\n\n")
            append(projectSummary(projectFiles, file))
            append("\nARQUIVO ATUAL: $file (${lang.label})\n```\n").append(content.take(40_000)).append("\n```\n")
            if (!lastOutput.isNullOrBlank()) append("\nÚLTIMA SAÍDA AO RODAR:\n").append(lastOutput.take(4000)).append("\n")
        }
        val t0 = System.currentTimeMillis()
        val r = router.chat(listOf(ChatMessage("system", system), ChatMessage("user", user)), emptyList())
        val text = r.text.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        FlowLog.add("ESTÚDIO", r.providerName, "${action.label} · $file", System.currentTimeMillis() - t0)
        val code = extractCode(text)
        val explanation = if (code != null) text.substringBefore("```").trim() else text
        return Answer(explanation.ifBlank { "Pronto." }, code, r.providerName)
    }

    /** Pede à IA um projeto inteiro a partir de uma descrição. */
    suspend fun scaffold(description: String): Pair<String, Map<String, String>> {
        val prompt = """
            Crie um projeto completo e profissional para: $description

            Responda SOMENTE com um JSON válido, sem texto antes ou depois, neste formato:
            {"nome": "nome-curto-do-projeto", "arquivos": [{"caminho": "pasta/arquivo.ext", "conteudo": "..."}]}

            Regras: estrutura de pastas organizada, README.md explicando como usar, código comentado em português,
            testes quando fizer sentido. Prefira Python, JavaScript/HTML/CSS, Lua ou SQL (rodam no celular).
            No máximo 12 arquivos.
        """.trimIndent()
        val t0 = System.currentTimeMillis()
        val r = router.chat(listOf(ChatMessage("system", system), ChatMessage("user", prompt)), emptyList())
        FlowLog.add("ESTÚDIO", r.providerName, "Novo projeto pela IA: $description", System.currentTimeMillis() - t0)
        return parseScaffold(r.text)
    }

    data class Change(val path: String, val action: String, val content: String)
    data class BuildPlan(val plan: String, val changes: List<Change>, val main: String?)

    /**
     * CONSTRUTOR POR CONVERSA: o usuário descreve o que quer; a IA planeja e devolve
     * as mudanças em TODOS os arquivos necessários (criar, alterar ou apagar).
     */
    suspend fun build(request: String, files: Map<String, String>, history: List<Pair<String, String>>): BuildPlan {
        val ctx = buildString {
            append("PROJETO ATUAL (${files.size} arquivos):\n")
            files.forEach { (p, c) -> append("\n=== $p ===\n").append(c.take(12_000)).append("\n") }
            if (history.isNotEmpty()) {
                append("\nCONVERSA ANTERIOR:\n")
                history.takeLast(8).forEach { (who, t) -> append("$who: ${t.take(500)}\n") }
            }
        }
        val prompt = """
            PEDIDO DO USUÁRIO (ele não programa; explique em linguagem simples):
            $request

            $ctx

            Responda SOMENTE com um JSON válido:
            {"plano": "explicação curta e simples do que você vai fazer",
             "principal": "arquivo para rodar ou abrir (ex.: main.py ou index.html)",
             "mudancas": [{"caminho": "pasta/arquivo.ext", "acao": "criar|alterar|apagar", "conteudo": "ARQUIVO COMPLETO"}]}
            Regras: código profissional e completo (nada de "..." ou "resto igual"); só inclua arquivos que mudam;
            prefira Python, HTML/CSS/JS, Lua ou SQL (rodam no celular); inclua testes quando fizer sentido.
        """.trimIndent()
        val t0 = System.currentTimeMillis()
        val r = router.chat(listOf(ChatMessage("system", system), ChatMessage("user", prompt)), emptyList())
        FlowLog.add("ESTÚDIO", r.providerName, "Construtor: ${request.take(80)}", System.currentTimeMillis() - t0)
        return parseBuild(r.text)
    }

    companion object {
        fun parseBuild(text: String): BuildPlan {
            val clean = text.replace(Regex("(?s)<think>.*?</think>"), "")
            val start = clean.indexOf('{')
            val end = clean.lastIndexOf('}')
            require(start >= 0 && end > start) { "A IA não devolveu um plano válido. Tente descrever de outro jeito." }
            val json = JSONObject(clean.substring(start, end + 1))
            val arr = json.optJSONArray("mudancas") ?: org.json.JSONArray()
            val changes = (0 until arr.length()).map { arr.getJSONObject(it) }.mapNotNull { o ->
                val path = o.optString("caminho").trim().trimStart('/').replace("..", "")
                if (path.isBlank()) null
                else Change(path, o.optString("acao", "alterar").lowercase(), o.optString("conteudo"))
            }
            return BuildPlan(json.optString("plano"), changes, json.optString("principal").ifBlank { null })
        }

        /** Pega o último bloco de código ```...``` da resposta. */
        fun extractCode(text: String): String? {
            val blocks = Regex("```[^\\n`]*\\n([\\s\\S]*?)```").findAll(text).map { it.groupValues[1] }.toList()
            return blocks.lastOrNull()?.trimEnd('\n')
        }

        /** Lê o JSON do projeto, mesmo que a IA tenha colocado ```json em volta ou texto antes. */
        fun parseScaffold(text: String): Pair<String, Map<String, String>> {
            val clean = text.replace(Regex("(?s)<think>.*?</think>"), "")
            val start = clean.indexOf('{')
            val end = clean.lastIndexOf('}')
            require(start >= 0 && end > start) { "A IA não devolveu um projeto válido. Tente descrever de outro jeito." }
            val json = JSONObject(clean.substring(start, end + 1))
            val name = json.optString("nome", "projeto")
            val arr = json.getJSONArray("arquivos")
            val files = LinkedHashMap<String, String>()
            for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                val path = f.optString("caminho").trim().trimStart('/').replace("..", "")
                if (path.isNotBlank()) files[path] = f.optString("conteudo")
            }
            require(files.isNotEmpty()) { "A IA devolveu um projeto sem arquivos." }
            return name to files
        }
    }
}
