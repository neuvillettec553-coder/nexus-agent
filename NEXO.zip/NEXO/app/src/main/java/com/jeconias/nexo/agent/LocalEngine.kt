package com.jeconias.nexo.agent

import org.json.JSONObject
import java.text.Normalizer

/**
 * MOTOR LOCAL: resolve na hora, sem IA e sem internet, os comandos diretos.
 * 1º tenta as regras fixas; 2º os atalhos aprendidos.
 * Nunca executa nada que envie mensagem ou mexa com dinheiro.
 */
class LocalEngine(private val shortcuts: ShortcutStore?) {

    data class Match(
        val tool: String,
        val args: JSONObject,
        val fromShortcut: Boolean,
        val phrase: String,
        val label: String,
    )

    companion object {
        fun normalize(text: String): String {
            var s = Normalizer.normalize(text.lowercase().trim(), Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")
            s = s.replace(Regex("[!?.,;]+"), " ").replace(Regex("\\s+"), " ").trim()
            s = s.removePrefix("alfredo").trim().removePrefix("por favor").trim().removeSuffix("por favor").trim()
            return s
        }

        private val STOP = setOf("para", "pare", "parar", "cala a boca", "silencio", "chega", "fica quieto", "cancela", "cancelar")
        private val CORRECTION = listOf("errado", "ta errado", "esta errado", "nao era isso", "nao era esse", "nao foi isso", "voce errou")

        fun isStop(text: String) = normalize(text) in STOP
        fun isCorrection(text: String): Boolean {
            val n = normalize(text)
            return CORRECTION.any { n == it || n.startsWith("$it ") }
        }
    }

    fun match(text: String): Match? {
        val n = normalize(text)
        if (n.isBlank()) return null
        rules(n)?.let { return it }
        shortcuts?.get(n)?.let { sc ->
            val args = try { JSONObject(sc.args) } catch (_: Exception) { JSONObject() }
            return Match(sc.tool, args, true, n, "atalho aprendido")
        }
        return null
    }

    private fun rules(n: String): Match? {
        fun m(tool: String, args: JSONObject = JSONObject()) = Match(tool, args, false, n, "regra")

        // Hora e data
        if (Regex("^(que horas sao|que hora e|me diz as horas|horas|que dia e hoje|qual a data de hoje|que dia e)$").matches(n)) {
            return m("data_hora")
        }
        // Abrir app
        Regex("^(?:abre|abrir|abra|abri|abre ai)(?: o| a| os| as)? (.{2,40})$").find(n)?.let {
            val nome = it.groupValues[1].trim()
            if (!nome.startsWith("http") && !nome.contains(" e ")) return m("abrir_app", JSONObject().put("nome", nome))
        }
        // Alarme / despertador (só quando o pedido COMEÇA mandando criar)
        val pedeAlarme = Regex("^(?:coloca|coloque|bota|cria|crie|define|defina|programa|programe|poe|ponha|liga|ativa|marca|marque)?\\s*(?:um |o |meu )?(?:alarme|despertador)\\b").containsMatchIn(n)
        if (pedeAlarme) Regex("(?:alarme|despertador)\\D*?(\\d{1,2})(?:\\s*(?:h|:|horas?)\\s*(?:e\\s*)?(\\d{1,2}|meia)?)?").find(n)?.let {
            val h = it.groupValues[1].toIntOrNull() ?: return@let
            val minText = it.groupValues[2]
            val min = when {
                minText == "meia" -> 30
                minText.isNotBlank() -> minText.toIntOrNull() ?: 0
                n.contains(" e meia") -> 30
                else -> 0
            }
            if (h in 0..23 && min in 0..59) {
                return m("criar_alarme", JSONObject().put("hora", h).put("minuto", min).put("rotulo", "Alfredo"))
            }
        }
        // Lembrete "daqui X minutos/horas"
        Regex("^(?:me )?(?:lembra|lembre|lembrar|avisa|avise)(?: me)? (?:daqui|daqui a|em|dentro de) (\\d+) (minutos?|min|horas?|h)\\b ?(?:de |para |pra |que |do |da )?(.*)$").find(n)?.let {
            val qtd = it.groupValues[1].toIntOrNull() ?: return@let
            val minutos = if (it.groupValues[2].startsWith("h")) qtd * 60 else qtd
            val msg = it.groupValues[3].trim().ifBlank { "Lembrete do Alfredo" }
            if (minutos in 1..10080) {
                return m("criar_lembrete", JSONObject().put("mensagem", msg).put("minutos", minutos))
            }
        }
        // Anotar
        Regex("^(?:anota|anote|anotar|toma nota|salva uma nota)(?: ai| isso| que)?[: ]+(.{2,300})$").find(n)?.let {
            return m("anotar", JSONObject().put("texto", it.groupValues[1].trim()))
        }
        // Ler notas
        if (Regex("^(o que eu anotei|minhas notas|minhas anotacoes|le minhas notas|ler notas|quais sao minhas notas)$").matches(n)) {
            return m("listar_notas")
        }
        // Rotinas
        if (Regex("^(quais sao minhas rotinas|minhas rotinas|lista minhas rotinas|quais rotinas eu tenho)$").matches(n)) {
            return m("listar_rotinas")
        }
        return null
    }
}
