package com.jeconias.nexo.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.identity.Identity
import com.jeconias.nexo.connectors.GitHubConnector
import com.jeconias.nexo.connectors.GoogleConnector
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.ui.life.Chips
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private const val SHA1 = "1A:7C:F0:2D:6D:13:97:DA:51:1E:F3:6A:21:0A:84:91:C4:23:C1:C5"

/** CONECTORES: Google (Gmail), GitHub e catálogo MCP com permissão por ferramenta. */
@Composable
fun ConnectorsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = Container.connectors
    var refresh by remember { mutableIntStateOf(0) }
    var googleMsg by remember { mutableStateOf("") }
    var showGuide by remember { mutableStateOf(false) }
    var ghToken by remember { mutableStateOf(store.githubToken()) }
    var ghMsg by remember { mutableStateOf("") }
    var mcpMsg by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf<com.jeconias.nexo.mcp.McpManager.Preset?>(null) }
    val servers = remember(refresh) { Container.mcp.servers() }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        googleMsg = try {
            val r = Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(res.data)
            GoogleConnector.accept(r)
            "✅ Google conectado."
        } catch (e: Exception) {
            "❌ Autorização não concluída: ${e.message}"
        }
        refresh++
    }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // ---------------- GOOGLE ----------------
        item {
            GlassCard {
                SectionTitle("GOOGLE")
                Muted("Gmail · Drive · Planilhas · Docs · YouTube. Enviar e-mail sempre pede sua confirmação. Pesquisa Google usa a chave do Gemini (aba IAs). A Agenda do Google funciona pelo painel AGENDA.")
                Text(if (store.googleConnected()) "● Conectado" else "○ Desconectado", color = if (store.googleConnected()) NexoColors.green else NexoColors.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        googleMsg = "Abrindo autorização do Google…"
                        scope.launch {
                            googleMsg = try {
                                val r = Identity.getAuthorizationClient(ctx).authorize(GoogleConnector.request()).await()
                                if (r.hasResolution()) {
                                    consent.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                                    "Confirme no Google…"
                                } else { GoogleConnector.accept(r); refresh++; "✅ Google conectado." }
                            } catch (e: Exception) {
                                "❌ ${e.message}\nSe o erro falar em DEVELOPER_ERROR ou código 10, falta a configuração do guia abaixo."
                            }
                        }
                    }) { Text("Conectar Google") }
                    if (store.googleConnected()) OutlinedButton(onClick = { GoogleConnector.disconnect(); refresh++ }) { Text("Desconectar") }
                }
                if (store.googleConnected()) TextButton(onClick = {
                    scope.launch {
                        googleMsg = try {
                            val r = GoogleConnector.search(ctx, "in:inbox", 3)
                            "✅ Funcionando. Últimos: " + r.joinToString(" | ") { it.second.take(60) }
                        } catch (e: Exception) { "❌ ${e.message}" }
                    }
                }) { Text("Testar Gmail") }
                if (store.googleConnected()) TextButton(onClick = {
                    scope.launch {
                        val parts = mutableListOf<String>()
                        parts += runCatching { "Drive ✅ (${com.jeconias.nexo.connectors.GoogleServices.driveSearch(ctx, "", 3).size} arquivos)" }.getOrElse { "Drive ❌ ${it.message?.take(80)}" }
                        parts += runCatching { "YouTube ✅ (${com.jeconias.nexo.connectors.GoogleServices.youtubeSearch(ctx, "NEXO", 1).size})" }.getOrElse { "YouTube ❌ ${it.message?.take(80)}" }
                        parts += runCatching {
                            com.jeconias.nexo.tools.builtin.GoogleSearch.search(Container.http, "previsão do tempo hoje")?.let { "Pesquisa Google ✅" } ?: "Pesquisa Google indisponível (vai usar DuckDuckGo)"
                        }.getOrElse { "Pesquisa Google ❌" }
                        googleMsg = parts.joinToString("\n") + "\nPlanilhas e Docs são testados ao usar (exportar finanças / salvar no Docs)."
                    }
                }) { Text("Testar Drive, YouTube e Pesquisa") }
                if (googleMsg.isNotBlank()) Muted(googleMsg)
                TextButton(onClick = { showGuide = !showGuide }) { Text(if (showGuide) "Esconder guia de configuração" else "Guia de configuração (uma vez só)") }
                if (showGuide) {
                    Text(
                        "1. Entre em console.cloud.google.com com a sua conta Google.\n" +
                            "2. Crie um projeto chamado NEXO.\n" +
                            "3. Em “APIs e serviços → Biblioteca”, ative a Gmail API.\n" +
                            "4. Em “Tela de permissão OAuth”: tipo Externo, modo de teste, e adicione o SEU e-mail em “Usuários de teste”.\n" +
                            "5. Em “Credenciais → Criar credenciais → ID do cliente OAuth”: tipo Android,\n" +
                            "   pacote com.jeconias.nexo\n   SHA-1 $SHA1\n" +
                            "6. Volte aqui e toque em Conectar Google.",
                        color = NexoColors.text, fontSize = 12.sp,
                    )
                    TextButton(onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.cloud.google.com"))) } }) { Text("Abrir Google Cloud") }
                    Text(
                        "NOVOS SERVIÇOS (Drive, Planilhas, Docs, YouTube):\n" +
                            "1. No Google Cloud (projeto NEXO), use a busca do topo e ATIVE (Enable) cada uma:\n" +
                            "   • Google Drive API\n   • Google Sheets API\n   • Google Docs API\n   • YouTube Data API v3\n" +
                            "2. Volte aqui e toque em Conectar Google de novo e autorize as novas permissões.",
                        color = NexoColors.text, fontSize = 12.sp,
                    )
                }
            }
        }
        // ---------------- GITHUB ----------------
        item {
            GlassCard {
                SectionTitle("GITHUB")
                Muted("Listar seus repositórios e enviar projetos do Estúdio direto para o GitHub (sempre com confirmação).")
                OutlinedTextField(
                    value = ghToken, onValueChange = { ghToken = it; store.setGithubToken(it) },
                    label = { Text("Token pessoal (github_pat_… ou ghp_…)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        ghMsg = "Testando…"
                        scope.launch { ghMsg = try { "✅ Conectado como ${GitHubConnector.login()} · " + GitHubConnector.repos().take(3).joinToString() } catch (e: Exception) { "❌ ${e.message}" } }
                    }, enabled = ghToken.isNotBlank()) { Text("Testar") }
                    TextButton(onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/settings/tokens"))) } }) { Text("Criar token") }
                }
                Muted("Ao criar o token, marque acesso a repositórios (permissão “repo” ou “Contents: Read and write”).")
                if (ghMsg.isNotBlank()) Muted(ghMsg)
            }
        }
        // ---------------- MCP ----------------
        item { SectionTitle("CATÁLOGO MCP") }
        items(Container.mcp.catalog) { p ->
            GlassCard {
                Text(p.name, color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted(p.what)
                OutlinedButton(onClick = { adding = p }) { Text("Adicionar") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    mcpMsg = "Conectando…"
                    scope.launch { runCatching { Container.mcp.connectAll() }; mcpMsg = ""; refresh++ }
                }, enabled = servers.isNotEmpty()) { Text("Conectar todos") }
                OutlinedButton(onClick = { adding = com.jeconias.nexo.mcp.McpManager.Preset("Personalizado", "", false, "", "") }) { Text("+ Personalizado") }
            }
            if (mcpMsg.isNotBlank()) Muted(mcpMsg)
        }
        items(servers, key = { it.id }) { s ->
            GlassCard {
                Text(s.nome, color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted(s.url)
                Muted(Container.mcp.status[s.id] ?: "Ainda não conectado. Toque em “Conectar todos”.")
                Container.mcp.toolsByServer[s.id]?.forEach { t ->
                    Text(t.name, color = NexoColors.cyan, fontSize = 12.sp)
                    if (t.description.isNotBlank()) Muted(t.description.take(120))
                    var perm by remember(s.id, t.name, refresh) { mutableStateOf(Container.connectors.mcpPermission(s.id, t.name)) }
                    Chips(listOf("sempre", "perguntar", "bloqueado"), perm) { v ->
                        perm = v
                        Container.connectors.setMcpPermission(s.id, t.name, v)
                    }
                }
                if (Container.mcp.toolsByServer[s.id] != null) Muted("Mudanças de permissão valem depois de “Conectar todos”.")
                TextButton(onClick = { Container.mcp.remove(s.id); refresh++ }) { Text("Remover", color = NexoColors.red) }
            }
        }
    }

    val preset = adding
    if (preset != null) {
        var url by remember(preset) { mutableStateOf(preset.url) }
        var token by remember(preset) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = null },
            title = { Text(preset.name) },
            text = {
                androidx.compose.foundation.layout.Column {
                    OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Endereço (https…)") }, singleLine = true)
                    if (preset.needsToken || preset.name == "Personalizado") OutlinedTextField(
                        value = token, onValueChange = { token = it }, label = { Text("Token") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                    if (preset.tokenHelp.isNotBlank()) TextButton(onClick = {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(preset.tokenHelp))) }
                    }) { Text("Onde consigo isso?") }
                    Muted("Os endereços podem mudar com o tempo; o botão Conectar mostra se está funcionando.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    Container.mcp.add(preset.name, url, token)
                    adding = null
                    mcpMsg = "Conectando…"
                    scope.launch { runCatching { Container.mcp.connectAll() }; mcpMsg = ""; refresh++ }
                }, enabled = url.startsWith("http")) { Text("Adicionar e conectar") }
            },
            dismissButton = { TextButton(onClick = { adding = null }) { Text("Cancelar") } },
        )
    }
}

