package com.jeconias.nexo.tools.builtin

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.Normalizer

private fun normalize(s: String) =
    Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")

private data class AppEntry(val label: String, val pkg: String)

private fun installedApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

/** Abre uma Activity a partir do app. Retorna null se deu certo, ou o motivo da falha. */
private suspend fun launch(ctx: Context, intent: Intent): String? = withContext(Dispatchers.Main) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        null
    } catch (e: ActivityNotFoundException) {
        "Nenhum app do celular sabe fazer isso."
    } catch (e: Exception) {
        e.message ?: "Erro ao abrir"
    }
}

class AbrirAppTool(private val ctx: Context) : Tool {
    override val name = "abrir_app"
    override val description =
        "Abre um app instalado pelo nome (ex.: YouTube, WhatsApp, Câmera). Se não souber o nome exato, use listar_apps antes. Nunca abra um app diferente do pedido por adivinhação."
    override val parameters = schema(Param("nome", "string", "Nome do app"))
    override suspend fun run(args: JSONObject): ToolResult {
        val query = normalize(args.optString("nome"))
        if (query.isBlank()) return ToolResult(false, "Nome do app vazio.")
        val apps = installedApps(ctx)
        val match = apps.firstOrNull { normalize(it.label) == query }
            ?: apps.firstOrNull { normalize(it.label).startsWith(query) }
            ?: apps.firstOrNull { normalize(it.label).contains(query) }
            ?: return ToolResult(
                false,
                "Nenhum app com o nome '${args.optString("nome")}'. Não abri nada. Apps instalados: " +
                    apps.joinToString(", ") { it.label }.take(2500)
            )
        val intent = ctx.packageManager.getLaunchIntentForPackage(match.pkg)
            ?: return ToolResult(false, "O app ${match.label} não pode ser aberto diretamente.")
        val err = launch(ctx, intent)
        return if (err == null) ToolResult(true, "Comando de abertura enviado para ${match.label}.")
        else ToolResult(false, "Não consegui abrir ${match.label}: $err")
    }
}

class ListarAppsTool(private val ctx: Context) : Tool {
    override val level = Level.READ
    override val name = "listar_apps"
    override val description = "Lista os nomes de todos os apps instalados. Útil para achar um app pela descrição."
    override val parameters = schema()
    override suspend fun run(args: JSONObject) =
        ToolResult(true, installedApps(ctx).joinToString(", ") { it.label })
}

class CriarAlarmeTool(private val ctx: Context) : Tool {
    override val name = "criar_alarme"
    override val description = "Cria um alarme no app Relógio do celular."
    override val parameters = schema(
        Param("hora", "integer", "Hora de 0 a 23"),
        Param("minuto", "integer", "Minuto de 0 a 59"),
        Param("rotulo", "string", "Nome do alarme", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val h = args.optInt("hora", -1)
        val m = args.optInt("minuto", 0)
        if (h !in 0..23 || m !in 0..59) return ToolResult(false, "Horário inválido.")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("rotulo", "NEXO"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val err = launch(ctx, intent)
        val hhmm = "%02d:%02d".format(h, m)
        return if (err == null) ToolResult(true, "Pedido de alarme para $hhmm enviado ao Relógio. Peça ao usuário para conferir no app Relógio.")
        else ToolResult(false, "Falhou: $err")
    }
}

class AbrirLinkTool(private val ctx: Context) : Tool {
    override val name = "abrir_link"
    override val description = "Abre um endereço da internet ou um link (mapas, YouTube, site) no app adequado."
    override val parameters = schema(Param("url", "string", "Endereço completo começando com https://"))
    override suspend fun run(args: JSONObject): ToolResult {
        val url = args.optString("url").trim()
        if (!url.startsWith("http")) return ToolResult(false, "Link inválido.")
        val err = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return if (err == null) ToolResult(true, "Link aberto: $url") else ToolResult(false, "Falhou: $err")
    }
}

class CompartilharTextoTool(private val ctx: Context) : Tool {
    override val level = Level.SENSITIVE
    override val name = "compartilhar_texto"
    override val description = "Abre a tela de compartilhar do Android com um texto pronto, para o usuário escolher para onde enviar."
    override val parameters = schema(Param("texto", "string", "Texto a compartilhar"))
    override suspend fun run(args: JSONObject): ToolResult {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, args.optString("texto"))
        val err = launch(ctx, Intent.createChooser(send, "Compartilhar"))
        return if (err == null) ToolResult(true, "Tela de compartilhar aberta. O usuário escolhe o destino.")
        else ToolResult(false, "Falhou: $err")
    }
}

class WhatsappTool(private val ctx: Context) : Tool {
    override val level = Level.SENSITIVE
    override val name = "whatsapp_mensagem"
    override val description =
        "Abre o WhatsApp com uma mensagem já escrita para um número. O usuário confirma o envio tocando em enviar."
    override val parameters = schema(
        Param("numero", "string", "Número com DDI e DDD, só dígitos (ex.: 5511999998888)"),
        Param("mensagem", "string", "Texto da mensagem"),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val num = args.optString("numero").filter { it.isDigit() }
        if (num.length < 10) return ToolResult(false, "Número inválido. Peça o número com DDD ao usuário.")
        val url = "https://wa.me/$num?text=" + Uri.encode(args.optString("mensagem"))
        val err = launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return if (err == null) ToolResult(true, "WhatsApp aberto com a mensagem pronta. Falta o usuário tocar em enviar.")
        else ToolResult(false, "Falhou: $err")
    }
}
