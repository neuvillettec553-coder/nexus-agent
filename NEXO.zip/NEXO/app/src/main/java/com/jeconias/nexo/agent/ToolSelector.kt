package com.jeconias.nexo.agent

/**
 * Escolhe só as ferramentas que fazem sentido para o pedido.
 * Mandar 50 ferramentas em todo passo deixa a IA lenta e confusa; com 10 a 20, ela responde mais rápido.
 * Pura (sem Android): testada automaticamente.
 */
object ToolSelector {
    private val CORE = setOf(
        "data_hora", "lembrar", "criar_lembrete", "criar_alarme", "abrir_app", "listar_apps",
        "buscar_web", "ler_pagina", "anotar", "listar_notas", "salvar_nota", "abrir_link", "clima_agora",
        "ler_skill",
    )

    /** Grupo de ferramentas → palavras que o ativam (já sem acento, minúsculas). */
    private val GROUPS: List<Pair<List<String>, List<String>>> = listOf(
        listOf("fin_") to listOf("gast", "dinheir", "conta", "divid", "saldo", "pag", "receb", "salario", "renda", "orcament", "limite", "economi", "real", "reais", "r$", "financ", "compra", "credor", "juros"),
        listOf("tarefa_", "habito_", "meta_vida", "diario_", "vida_resumo") to listOf("tarefa", "afazer", "fazer hoje", "habito", "meta", "diario", "objetivo", "rotina do dia", "produtiv", "desenvolv"),
        listOf("agenda_") to listOf("agenda", "compromisso", "reuniao", "consulta", "evento", "marcar", "amanha", "semana"),
        listOf("gmail_") to listOf("email", "e-mail", "gmail", "caixa de entrada", "mensagem de"),
        listOf("drive_") to listOf("drive", "arquivo", "pasta", "backup"),
        listOf("planilha_") to listOf("planilha", "sheets", "tabela"),
        listOf("doc_") to listOf("documento", "docs", "proposta", "contrato", "relatorio"),
        listOf("youtube_") to listOf("youtube", "video", "tutorial", "aula"),
        listOf("mapa_") to listOf("mapa", "rota", "caminho", "cheg", "navega", "ir ate", "ir pra", "ir para", "endereco", "perto", "lugar", "onde fica", "maps"),
        listOf("github_") to listOf("github", "repositorio", "repo"),
        listOf("executar_codigo") to listOf("codigo", "program", "python", "javascript", "calcul", "conta exata", "script", "sql"),
        listOf("agendar_rotina", "listar_rotinas", "cancelar_rotina") to listOf("rotina", "todo dia", "toda semana", "a cada", "automatic", "diariamente"),
        listOf("salvar_skill") to listOf("skill", "procedimento", "salva isso como"),
        listOf("whatsapp_mensagem", "compartilhar_texto") to listOf("whatsapp", "zap", "mensagem pra", "mensagem para", "manda", "envia", "compartilh"),
        listOf("mcp_") to listOf("documentacao", "biblioteca", "context7", "deepwiki", "repositorio", "framework", "api de", "mcp", "zapier", "hugging"),
    )

    fun normalize(t: String): String =
        java.text.Normalizer.normalize(t.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")

    /**
     * @param text      o pedido (e as últimas falas, para dar contexto)
     * @param available nomes de todas as ferramentas registradas
     * @param used      ferramentas já usadas nesta conversa (continuam disponíveis)
     */
    fun select(text: String, available: Collection<String>, used: Collection<String> = emptyList()): Set<String> {
        val n = normalize(text)
        val chosen = mutableSetOf<String>()
        chosen += available.filter { it in CORE }
        for ((prefixes, words) in GROUPS) {
            if (words.any { it in n }) chosen += available.filter { name -> prefixes.any { p -> name.startsWith(p) || name == p } }
        }
        // Um servidor MCP citado pelo nome traz as ferramentas dele.
        chosen += available.filter { it.startsWith("mcp_") && n.contains(it.removePrefix("mcp_").substringBefore('_')) }
        chosen += used.filter { it in available }
        return chosen
    }
}
