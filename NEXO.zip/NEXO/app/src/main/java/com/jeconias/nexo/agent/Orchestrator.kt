package com.jeconias.nexo.agent

import com.jeconias.nexo.context.ContextStore
import com.jeconias.nexo.context.SkillStore
import com.jeconias.nexo.core.ActionLog
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.core.Metrics
import com.jeconias.nexo.core.Settings
import com.jeconias.nexo.providers.ChatMessage
import com.jeconias.nexo.providers.ProviderRouter
import com.jeconias.nexo.providers.ToolCall
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.ToolRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull

/**
 * TRIAGEM de cada pedido:
 *  1. Motor Local (instantâneo, grátis, sem internet)
 *  2. Conselho de IAs (só pedidos complexos ou quando você pede)
 *  3. Uma IA só (o resto)
 * Depois, o Motor Local aprende com o que a IA fez.
 */
class Orchestrator(
    private val router: ProviderRouter,
    private val tools: ToolRegistry,
    private val context: ContextStore,
    private val skills: SkillStore,
    private val settings: Settings,
    private val shortcuts: ShortcutStore,
) {
    data class Outcome(val reply: String, val source: String, val localPhrase: String? = null)

    private val agent = AgentLoop(router, tools, context, skills, settings)
    private val local = LocalEngine(shortcuts)

    suspend fun handle(
        history: MutableList<ChatMessage>,
        text: String,
        onEvent: (AgentEvent) -> Unit = {},
        confirm: Confirmer? = null,
        allowLocal: Boolean = true,
    ): Outcome {
        FlowLog.newRequest(text)

        // 1) MOTOR LOCAL
        if (allowLocal && settings.localEngine()) {
            val m = local.match(text)
            if (m != null) {
                val out = runLocal(m, history, text, onEvent, confirm)
                if (out != null) { Metrics.record(Metrics.Kind.LOCAL); return out }
            }
        }

        // 2) CONSELHO?
        val providers = router.availableProviders().size
        val mode = settings.councilMode()
        val askedFor = asksCouncil(text)
        val complex = isComplex(text)
        val wantCouncil = mode != "off" && (askedFor || (mode == "auto" && complex))
        when {
            !wantCouncil -> FlowLog.add("TRIAGEM", "Alfredo", "Pedido direto: uma IA resolve.")
            providers < 2 -> FlowLog.add("TRIAGEM", "Alfredo", "Seria caso de Conselho, mas só há $providers IA ativa. Seguindo com uma.")
            settings.councilUsedToday() >= settings.councilMaxPerDay() ->
                FlowLog.add("TRIAGEM", "Alfredo", "Limite diário do Conselho atingido. Seguindo com uma IA.")
            else -> {
                FlowLog.add("TRIAGEM", "Alfredo", if (askedFor) "Você pediu o Conselho." else "Pedido complexo: convocando o Conselho.")
                val out = council(history, text, onEvent, confirm)
                if (out != null) { Metrics.record(Metrics.Kind.COUNCIL); return out }
            }
        }

        // 3) UMA IA
        val reply = agent.run(history, text, onEvent, confirm)
        learnFrom(text)
        Metrics.record(Metrics.Kind.AI)
        return Outcome(reply, agent.lastProvider)
    }

    /** O usuário disse "errado" logo depois de uma resposta do Motor Local. */
    suspend fun correct(
        history: MutableList<ChatMessage>,
        phrase: String,
        onEvent: (AgentEvent) -> Unit,
        confirm: Confirmer?,
    ): Outcome {
        shortcuts.forget(phrase)
        FlowLog.newRequest("Correção: $phrase")
        FlowLog.add("MOTOR LOCAL", "aprendizado", "Atalho “$phrase” esquecido. Passando o pedido para a IA.", ok = false)
        val reply = agent.run(history, "$phrase\n(Observação: a resposta automática anterior estava errada; resolva com atenção.)", onEvent, confirm)
        return Outcome(reply, agent.lastProvider)
    }

    private suspend fun runLocal(
        m: LocalEngine.Match,
        history: MutableList<ChatMessage>,
        text: String,
        onEvent: (AgentEvent) -> Unit,
        confirm: Confirmer?,
    ): Outcome? {
        val tool = tools.get(m.tool) ?: return null
        if (tool.level == Level.SENSITIVE) return null
        // Atalho novo (menos de 2 usos) pede confirmação; sem ninguém para confirmar, deixa para a IA.
        if (m.fromShortcut && shortcuts.get(m.phrase)?.let { it.uses < 2 } == true) {
            if (confirm == null) return null
            val ok = confirm("Usar o atalho que eu aprendi?\n“${m.phrase}” → ${m.tool} ${m.args}")
            if (!ok) {
                FlowLog.add("MOTOR LOCAL", m.label, "Você recusou o atalho. Vou perguntar à IA.", ok = false)
                return null
            }
        }
        onEvent(AgentEvent.Local)
        val call = ToolCall("local", m.tool, m.args.toString())
        val t0 = System.currentTimeMillis()
        val result = agent.execute(call, confirm)
        val ms = System.currentTimeMillis() - t0
        ActionLog.add(m.tool, m.args.toString(), result.ok, result.output)
        FlowLog.add("MOTOR LOCAL", m.label, "${m.tool}: ${result.output.take(300)}", ms, result.ok)
        if (!result.ok) return null // deixa a IA tentar outro caminho
        if (m.fromShortcut) shortcuts.used(m.phrase)
        val reply = result.output
        history.add(ChatMessage("user", text))
        history.add(ChatMessage("assistant", reply))
        return Outcome(reply, "Motor Local · ${m.label}", m.phrase)
    }

    /** Pedido simples resolvido com UMA ação que deu certo vira atalho. */
    private fun learnFrom(text: String) {
        val acts = agent.lastRunActions
        if (acts.size != 1) return
        val (call, result) = acts.first()
        if (!result.ok) return
        val phrase = LocalEngine.normalize(text)
        if (local.match(text) != null) return
        if (call.name in shortcuts.learnable && shortcuts.get(phrase) == null) {
            shortcuts.learn(phrase, call.name, call.argumentsJson)
            FlowLog.add("MOTOR LOCAL", "aprendizado", "Aprendi um atalho novo: “$phrase” → ${call.name}")
        }
    }

    // ------------------------- CONSELHO -------------------------

    private suspend fun council(
        history: MutableList<ChatMessage>,
        text: String,
        onEvent: (AgentEvent) -> Unit,
        confirm: Confirmer?,
    ): Outcome? {
        settings.addCouncilUse()
        val sys = context.systemPrompt(skills.index(), settings.userName(), settings.city())
        val recent = history.takeLast(6).filter { it.role == "user" || it.role == "assistant" }
            .joinToString("\n") { (if (it.role == "user") "Usuário: " else "Alfredo: ") + it.content.take(400) }
        val pedido = (if (recent.isNotBlank()) "Conversa recente:\n$recent\n\n" else "") + "PEDIDO ATUAL: $text"

        val result = try {
            withTimeoutOrNull(COUNCIL_TIMEOUT_MS) {
                onEvent(AgentEvent.Council("Estrategista propondo"))
                var t0 = System.currentTimeMillis()
                val proposal = router.chatRole(
                    0,
                    listOf(
                        ChatMessage("system", "$sys\n\n---\n$STRATEGIST"),
                        ChatMessage("user", pedido),
                    )
                )
                FlowLog.add("ESTRATEGISTA", proposal.providerName, proposal.text, System.currentTimeMillis() - t0)

                onEvent(AgentEvent.Council("Crítico analisando"))
                t0 = System.currentTimeMillis()
                val critique = router.chatRole(
                    1,
                    listOf(
                        ChatMessage("system", CRITIC),
                        ChatMessage("user", "$pedido\n\nPROPOSTA DO ESTRATEGISTA:\n${proposal.text}"),
                    )
                )
                FlowLog.add("CRÍTICO", critique.providerName, critique.text, System.currentTimeMillis() - t0)

                onEvent(AgentEvent.Council("Juiz decidindo"))
                t0 = System.currentTimeMillis()
                val verdict = router.chatRole(
                    2,
                    listOf(
                        ChatMessage("system", "$sys\n\n---\n$JUDGE"),
                        ChatMessage(
                            "user",
                            "$pedido\n\nPROPOSTA:\n${proposal.text}\n\nCRÍTICA:\n${critique.text}"
                        ),
                    )
                )
                FlowLog.add("JUIZ", verdict.providerName, verdict.text, System.currentTimeMillis() - t0)
                verdict.text
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            FlowLog.add("TRIAGEM", "Alfredo", "Conselho falhou (${e.message?.take(120)}). Seguindo com uma IA.", ok = false)
            return null
        }
        if (result == null) {
            FlowLog.add("TRIAGEM", "Alfredo", "O Conselho demorou demais. Seguindo com uma IA.", ok = false)
            return null
        }

        val needsAction = Regex("(?i)A[ÇC][ÃA]O:\\s*SIM").containsMatchIn(result)
        val decision = result.lines()
            .filterNot { Regex("(?i)^\\s*A[ÇC][ÃA]O:\\s*(SIM|N[ÃA]O)\\s*$").matches(it) }
            .joinToString("\n")
            .replace(Regex("(?s)<think>.*?</think>"), "")
            .trim()

        if (needsAction) {
            FlowLog.add("TRIAGEM", "Alfredo", "O Juiz decidiu que é preciso agir. O agente vai executar a decisão.")
            val reply = agent.run(
                history, text, onEvent, confirm,
                extraSystem = "DECISÃO DO CONSELHO (siga esta decisão ao agir):\n$decision"
            )
            return Outcome(reply, "Conselho de IAs + ${agent.lastProvider}")
        }
        history.add(ChatMessage("user", text))
        history.add(ChatMessage("assistant", decision))
        return Outcome(decision.ifBlank { "O Conselho não chegou a uma resposta." }, "Conselho de IAs")
    }

    companion object {
        const val COUNCIL_TIMEOUT_MS = 100_000L

        private const val STRATEGIST =
            "Você é o ESTRATEGISTA do Conselho do Alfredo. Proponha a melhor resposta ou plano para o PEDIDO ATUAL, " +
                "usando o que sabe do usuário. Seja concreto e prático, em até 12 linhas. Não chame ferramentas."
        private const val CRITIC =
            "Você é o CRÍTICO do Conselho do Alfredo. Leia o pedido e a proposta. Aponte falhas, riscos, " +
                "informações que faltam e como melhorar, em até 8 itens curtos. Se a proposta estiver boa, diga isso. " +
                "Responda em português."
        private const val JUDGE =
            "Você é o JUIZ do Conselho do Alfredo. Com base na proposta e na crítica, dê a DECISÃO FINAL para o " +
                "usuário: em português, curta (até 8 frases), clara e pronta para ser falada em voz alta. " +
                "Na ÚLTIMA linha escreva exatamente 'AÇÃO: SIM' se for preciso usar funções do celular para cumprir o " +
                "pedido (lembrete, alarme, abrir app, salvar nota, rotina, mensagem), ou 'AÇÃO: NÃO'."

        fun asksCouncil(text: String): Boolean {
            val n = LocalEngine.normalize(text)
            return listOf("conselho", "pense bem", "pensa bem", "analise com calma", "consulte as ias").any { it in n }
        }

        fun isComplex(text: String): Boolean {
            val n = LocalEngine.normalize(text)
            if (n.length > 160) return true
            val keys = listOf(
                "planej", "compar", "decid", "estrateg", "devo ", "vale a pena", "melhor opcao", "melhor forma",
                "analis", "me ajuda a pensar", "pros e contras", "orcamento", "invest", "organiza minha", "qual escolher",
            )
            return keys.any { it in n }
        }
    }
}
