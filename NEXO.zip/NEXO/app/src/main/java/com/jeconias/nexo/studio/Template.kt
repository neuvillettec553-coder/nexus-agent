package com.jeconias.nexo.studio

/** Modelos iniciais de projeto, já organizados e prontos para rodar. */
data class Template(val id: String, val label: String, val files: Map<String, String>) {
    companion object {
        val all = listOf(
            Template(
                "web", "Site (HTML, CSS e JS)",
                mapOf(
                    "index.html" to """
                        <!DOCTYPE html>
                        <html lang="pt-BR">
                        <head>
                          <meta charset="UTF-8">
                          <meta name="viewport" content="width=device-width, initial-scale=1">
                          <title>Meu projeto</title>
                          <link rel="stylesheet" href="style.css">
                        </head>
                        <body>
                          <main class="card">
                            <h1>Olá, mundo!</h1>
                            <p id="mensagem">Edite os arquivos e toque em Rodar.</p>
                            <button id="botao">Clique aqui</button>
                          </main>
                          <script src="script.js"></script>
                        </body>
                        </html>
                    """.trimIndent(),
                    "style.css" to """
                        :root { --fundo: #0b1020; --texto: #e6edff; --destaque: #38e1ff; }
                        * { box-sizing: border-box; }
                        body { margin: 0; min-height: 100vh; display: grid; place-items: center;
                               background: var(--fundo); color: var(--texto); font-family: system-ui, sans-serif; }
                        .card { padding: 24px; border: 1px solid var(--destaque); border-radius: 16px; text-align: center; }
                        button { background: var(--destaque); border: 0; border-radius: 10px; padding: 10px 18px; font-weight: bold; }
                    """.trimIndent(),
                    "script.js" to """
                        // Ponto de entrada do site.
                        const botao = document.getElementById('botao');
                        const mensagem = document.getElementById('mensagem');
                        let cliques = 0;

                        botao.addEventListener('click', () => {
                          cliques += 1;
                          mensagem.textContent = `Você clicou ${'$'}{cliques} vez(es).`;
                          console.log('clique', cliques);
                        });
                    """.trimIndent(),
                    "README.md" to "# Meu projeto\n\nSite simples: `index.html`, `style.css` e `script.js`.\n",
                ),
            ),
            Template(
                "python", "Python",
                mapOf(
                    "main.py" to """
                        ${'"'}""Ponto de entrada do programa.""${'"'}
                        from util import saudacao


                        def main() -> None:
                            print(saudacao("mundo"))


                        if __name__ == "__main__":
                            main()
                    """.trimIndent(),
                    "util.py" to """
                        ${'"'}""Funções auxiliares.""${'"'}


                        def saudacao(nome: str) -> str:
                            return f"Olá, {nome}!"
                    """.trimIndent(),
                    "test_util.py" to """
                        ${'"'}""Testes: rode este arquivo para conferir.""${'"'}
                        from util import saudacao

                        assert saudacao("Ana") == "Olá, Ana!"
                        print("Todos os testes passaram.")
                    """.trimIndent(),
                    "README.md" to "# Projeto Python\n\nRode `main.py`. Testes em `test_util.py`.\n",
                ),
            ),
            Template(
                "javascript", "JavaScript",
                mapOf(
                    "main.js" to """
                        // Programa em JavaScript puro (roda no motor do Android).
                        function soma(a, b) {
                          return a + b;
                        }

                        console.log('2 + 3 =', soma(2, 3));
                        console.assert(soma(2, 2) === 4, 'soma errada');
                    """.trimIndent(),
                ),
            ),
            Template(
                "lua", "Lua",
                mapOf("main.lua" to "-- Programa em Lua\nlocal function dobro(x) return x * 2 end\nprint(\"Dobro de 21:\", dobro(21))\n"),
            ),
            Template(
                "sql", "SQL (SQLite)",
                mapOf(
                    "consulta.sql" to """
                        -- Banco temporário: é criado do zero a cada execução.
                        CREATE TABLE produtos (id INTEGER PRIMARY KEY, nome TEXT, preco REAL);
                        INSERT INTO produtos (nome, preco) VALUES ('Café', 18.9), ('Pão', 7.5), ('Leite', 5.2);
                        SELECT nome, preco FROM produtos ORDER BY preco DESC;
                    """.trimIndent(),
                ),
            ),
            Template("empty", "Vazio", mapOf("README.md" to "# Novo projeto\n")),
        )
    }
}
