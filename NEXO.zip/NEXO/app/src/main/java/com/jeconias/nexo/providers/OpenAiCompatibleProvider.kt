package com.jeconias.nexo.providers

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Serve para Groq, Gemini, Cerebras, Mistral, OpenRouter, NVIDIA, GLM, DeepSeek, Qwen, Kimi, OpenAI. */
class OpenAiCompatibleProvider(
    override val info: ProviderInfo,
    private val apiKey: String,
    private val model: String,
    private val http: OkHttpClient,
) : LlmProvider {

    override suspend fun chat(messages: List<ChatMessage>, tools: List<ToolSpec>): LlmResponse =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
            body.put("model", model)
            val arr = JSONArray()
            messages.forEach { arr.put(toJson(it)) }
            body.put("messages", arr)
            if (tools.isNotEmpty()) {
                val t = JSONArray()
                tools.forEach { spec ->
                    t.put(
                        JSONObject().put("type", "function").put(
                            "function",
                            JSONObject()
                                .put("name", spec.name)
                                .put("description", spec.description)
                                .put("parameters", spec.parameters)
                        )
                    )
                }
                body.put("tools", t)
            }
            body.put("temperature", 0.4)

            val request = Request.Builder()
                .url(info.baseUrl.trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody(JSON))
                .build()

            http.newCall(request).execute().use { resp ->
                val txt = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw ProviderException("HTTP ${resp.code}: ${txt.take(240)}")
                }
                val json = JSONObject(txt)
                val msg = json.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                val content = if (msg.isNull("content")) "" else msg.optString("content", "")
                val calls = mutableListOf<ToolCall>()
                val tc = msg.optJSONArray("tool_calls")
                if (tc != null) {
                    for (i in 0 until tc.length()) {
                        val c = tc.getJSONObject(i)
                        val f = c.getJSONObject("function")
                        val id = c.optString("id", "").ifBlank { "call_$i" }
                        val args = f.opt("arguments")
                        val argsStr = when (args) {
                            is JSONObject -> args.toString()
                            is String -> args
                            else -> "{}"
                        }
                        calls.add(ToolCall(id, f.getString("name"), argsStr))
                    }
                }
                LlmResponse(content, calls, info.name, model)
            }
        }

    private fun toJson(m: ChatMessage): JSONObject {
        val o = JSONObject().put("role", m.role)
        when (m.role) {
            "tool" -> {
                o.put("content", m.content)
                o.put("tool_call_id", m.toolCallId ?: "")
                if (m.toolName != null) o.put("name", m.toolName)
            }
            "assistant" -> {
                o.put("content", m.content)
                if (m.toolCalls.isNotEmpty()) {
                    val arr = JSONArray()
                    m.toolCalls.forEach {
                        arr.put(
                            JSONObject().put("id", it.id).put("type", "function").put(
                                "function",
                                JSONObject().put("name", it.name).put("arguments", it.argumentsJson)
                            )
                        )
                    }
                    o.put("tool_calls", arr)
                }
            }
            else -> o.put("content", m.content)
        }
        return o
    }

    companion object {
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
