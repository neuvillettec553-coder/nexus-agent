package com.jeconias.nexo.providers

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Claude usa um formato próprio; aqui ele é traduzido para o formato interno. */
class AnthropicProvider(
    override val info: ProviderInfo,
    private val apiKey: String,
    private val model: String,
    private val http: OkHttpClient,
) : LlmProvider {

    override suspend fun chat(messages: List<ChatMessage>, tools: List<ToolSpec>): LlmResponse =
        withContext(Dispatchers.IO) {
            val system = messages.filter { it.role == "system" }.joinToString("\n\n") { it.content }

            // Mensagens seguidas do mesmo papel são unidas (exigência da API).
            val turns = mutableListOf<Pair<String, JSONArray>>()
            fun add(role: String, block: JSONObject) {
                if (turns.isNotEmpty() && turns.last().first == role) turns.last().second.put(block)
                else turns.add(role to JSONArray().put(block))
            }
            for (m in messages) {
                when (m.role) {
                    "system" -> Unit
                    "user" -> add("user", JSONObject().put("type", "text").put("text", m.content.ifBlank { "." }))
                    "assistant" -> {
                        if (m.content.isNotBlank()) add("assistant", JSONObject().put("type", "text").put("text", m.content))
                        m.toolCalls.forEach { c ->
                            val input = try { JSONObject(c.argumentsJson.ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
                            add("assistant", JSONObject().put("type", "tool_use").put("id", c.id).put("name", c.name).put("input", input))
                        }
                    }
                    "tool" -> add(
                        "user",
                        JSONObject().put("type", "tool_result").put("tool_use_id", m.toolCallId ?: "").put("content", m.content)
                    )
                }
            }

            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", 2048)
                .put("system", system)
            val msgArr = JSONArray()
            turns.forEach { (role, blocks) -> msgArr.put(JSONObject().put("role", role).put("content", blocks)) }
            body.put("messages", msgArr)
            if (tools.isNotEmpty()) {
                val t = JSONArray()
                tools.forEach {
                    t.put(JSONObject().put("name", it.name).put("description", it.description).put("input_schema", it.parameters))
                }
                body.put("tools", t)
            }

            val request = Request.Builder()
                .url(info.baseUrl.trimEnd('/') + "/messages")
                .header("x-api-key", apiKey)
                .header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody(OpenAiCompatibleProvider.JSON))
                .build()

            http.newCall(request).execute().use { resp ->
                val txt = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ProviderException("HTTP ${resp.code}: ${txt.take(240)}")
                val json = JSONObject(txt)
                val content = json.getJSONArray("content")
                val text = StringBuilder()
                val calls = mutableListOf<ToolCall>()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    when (b.optString("type")) {
                        "text" -> text.append(b.optString("text"))
                        "tool_use" -> calls.add(
                            ToolCall(b.getString("id"), b.getString("name"), (b.optJSONObject("input") ?: JSONObject()).toString())
                        )
                    }
                }
                LlmResponse(text.toString(), calls, info.name, model)
            }
        }
}
