package com.jeconias.nexo.ui.hud

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.ui.theme.NexoColors

/** Inclinação do celular (-1 a 1), usada para os painéis "flutuarem" em 3D. */
@Composable
fun rememberTilt(): Offset {
    val ctx = LocalContext.current
    var raw by remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = (e.values[0] / 9.81f).coerceIn(-1f, 1f)
                val y = ((e.values[1] - 7f) / 9.81f).coerceIn(-1f, 1f)
                raw = Offset(x, y)
            }
            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        if (sm != null && sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm?.unregisterListener(listener) }
    }
    val x by animateFloatAsState(raw.x, spring(stiffness = Spring.StiffnessLow), label = "tiltX")
    val y by animateFloatAsState(raw.y, spring(stiffness = Spring.StiffnessLow), label = "tiltY")
    return Offset(x, y)
}

/** Fundo: horizonte com grade em perspectiva se movendo e estrelas. */
@Composable
fun HoloBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "grade")
    val offset by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "avanco")
    Canvas(modifier) {
        drawRect(NexoColors.background)
        val w = size.width
        val h = size.height
        val horizon = h * 0.62f
        val vp = Offset(w / 2f, horizon)
        for (i in 0 until 14) {
            val z = (i + offset) / 14f
            val y = horizon + (h - horizon) * z * z
            drawLine(NexoColors.cyan.copy(alpha = 0.03f + 0.16f * z), Offset(0f, y), Offset(w, y), 1.dp.toPx())
        }
        for (i in -8..8) {
            drawLine(NexoColors.cyan.copy(alpha = 0.08f), vp, Offset(w / 2f + i * w / 5f, h), 1.dp.toPx())
        }
        val glowTop = horizon - 90.dp.toPx()
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, NexoColors.violet.copy(alpha = 0.18f), Color.Transparent),
                startY = glowTop, endY = horizon + 40.dp.toPx(),
            ),
            topLeft = Offset(0f, glowTop), size = Size(w, 130.dp.toPx()),
        )
        for (i in 0 until 45) {
            val sx = ((i * 73) % 100) / 100f * w
            val sy = ((i * 37 + 11) % 100) / 100f * horizon
            drawCircle(Color.White.copy(alpha = 0.12f + 0.04f * ((i * 17) % 10)), 1.dp.toPx(), Offset(sx, sy))
        }
    }
}

/**
 * Painel holográfico: vidro inclinado em perspectiva, cantoneiras de mira,
 * brilho na borda e leve movimento conforme o celular inclina.
 */
@Composable
fun HoloPanel(
    title: String,
    tilt: Offset,
    modifier: Modifier = Modifier,
    accent: Color = NexoColors.cyan,
    depth: Float = 1f,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(14.dp)
    val base = modifier
        .graphicsLayer {
            rotationX = 6f + tilt.y * 9f * depth
            rotationY = -tilt.x * 11f * depth
            translationX = -tilt.x * 5f * depth * density
            cameraDistance = 14f * density
        }
        .clip(shape)
        .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.16f), Color(0xFF0A1530).copy(alpha = 0.60f))))
        .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.85f), accent.copy(alpha = 0.10f))), shape)
        .drawWithContent {
            drawContent()
            val l = 14.dp.toPx()
            val s = 2.dp.toPx()
            val col = accent
            // cantoneiras
            drawLine(col, Offset(0f, s), Offset(l, s), s); drawLine(col, Offset(s, 0f), Offset(s, l), s)
            drawLine(col, Offset(size.width - l, s), Offset(size.width, s), s); drawLine(col, Offset(size.width - s, 0f), Offset(size.width - s, l), s)
            drawLine(col, Offset(0f, size.height - s), Offset(l, size.height - s), s); drawLine(col, Offset(s, size.height - l), Offset(s, size.height), s)
            drawLine(col, Offset(size.width - l, size.height - s), Offset(size.width, size.height - s), s)
            drawLine(col, Offset(size.width - s, size.height - l), Offset(size.width - s, size.height), s)
        }
    val clickable = if (onClick != null) base.clickable { onClick() } else base
    Column(clickable.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).background(accent))
            Spacer(Modifier.size(6.dp))
            Text(
                title, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        content()
    }
}

/** Linha "rótulo .... valor" dentro dos painéis. */
@Composable
fun HoloLine(label: String, value: String, valueColor: Color = NexoColors.text) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = NexoColors.muted, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(end = 6.dp))
        Text(value, color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
