package com.jeconias.nexo.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Visual "vidro futurista": fundo profundo, painéis translúcidos, brilho ciano/violeta. */
object NexoColors {
    val deep = Color(0xFF060914)
    val navy = Color(0xFF0D1430)
    val cyan = Color(0xFF38E1FF)
    val violet = Color(0xFFA78BFA)
    val green = Color(0xFF4ADE80)
    val red = Color(0xFFF87171)
    val amber = Color(0xFFFBBF24)
    val text = Color(0xFFE6EDFF)
    val muted = Color(0xFF8A96B8)

    val background = Brush.verticalGradient(listOf(deep, navy, Color(0xFF120A2A)))
}

@Composable
fun NexoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NexoColors.cyan,
            secondary = NexoColors.violet,
            background = NexoColors.deep,
            surface = NexoColors.navy,
            onPrimary = NexoColors.deep,
            onBackground = NexoColors.text,
            onSurface = NexoColors.text,
        ),
        content = content,
    )
}

private val glassShape = RoundedCornerShape(18.dp)

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(glassShape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
            .border(
                1.dp,
                Brush.linearGradient(listOf(NexoColors.cyan.copy(alpha = 0.55f), NexoColors.violet.copy(alpha = 0.25f))),
                glassShape
            )
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = NexoColors.cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
}

@Composable
fun Muted(text: String) {
    Text(text, color = NexoColors.muted, fontSize = 13.sp)
}
