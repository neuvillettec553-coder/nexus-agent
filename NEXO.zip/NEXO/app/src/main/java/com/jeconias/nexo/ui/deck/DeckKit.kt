package com.jeconias.nexo.ui.deck

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.ui.ChatViewModel
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.hud.HoloPanel
import com.jeconias.nexo.ui.theme.NexoColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Cabeçalho no estilo da imagem: título futurista, subtítulo e caixas de métricas nas laterais. */
@Composable
fun DeckHeader(title: String, subtitle: String, left: Pair<String, String>?, right: Pair<String, String>?) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp, start = 10.dp, end = 10.dp)) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                .border(1.dp, Brush.horizontalGradient(listOf(HoloBlue.copy(alpha = 0.2f), HoloCyan, HoloBlue.copy(alpha = 0.2f))), RoundedCornerShape(10.dp))
                .background(Color(0x55061428))
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    title, color = HoloCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, letterSpacing = 2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                )
                Text(subtitle, color = Color.White.copy(alpha = 0.7f), fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 2.sp, maxLines = 1)
            }
        }
        if (left != null || right != null) {
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                if (left != null) MetricBox(left.first, left.second, HoloBlue)
                Spacer(Modifier.weight(1f))
                if (right != null) MetricBox(right.first, right.second, HoloOrange)
            }
        }
    }
}

@Composable
fun MetricBox(label: String, value: String, accent: Color) {
    Column(
        Modifier.clip(RoundedCornerShape(6.dp)).border(1.dp, accent.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
            .background(accent.copy(alpha = 0.08f)).padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(label.uppercase(), color = accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1)
    }
}

/** Placa holográfica que, ao ser tocada, projeta o painel completo. */
@Composable
fun HoloTile(
    title: String,
    tilt: Offset,
    modifier: Modifier = Modifier,
    accent: Color = HoloCyan,
    depth: Float = 1f,
    onClick: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) = HoloPanel(title, tilt, modifier, accent, depth, onClick, content)

@Composable
fun StatusLine(text: String, ok: Boolean = true) {
    Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("STATUS: ", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(text, color = if (ok) Color(0xFF5CFF8A) else NexoColors.red, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

/** Itens agendados (lembretes e rotinas) prontos para mostrar. */
fun upcomingItems(): List<String> {
    val fmt = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR"))
    val reminders = Container.routines.upcomingReminders().map { (at, msg) -> "⏰ ${fmt.format(Date(at))} · $msg" }
    val routines = Container.routines.all().map {
        "🔁 " + (if (it.tipo == "diaria") "Todo dia ${it.hora}" else "A cada ${it.horas}h") + " · ${it.nome}"
    }
    return reminders + routines
}

/** Barra de conversa: última fala + campo + microfone. */
@Composable
fun Dock(vm: ChatViewModel, listen: () -> Unit, onOpenChat: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
        com.jeconias.nexo.ui.BusyIndicator(vm)
        val last = vm.messages.lastOrNull()
        if (last != null) {
            Column(
                Modifier.fillMaxWidth().clip(shape).background(Color(0x66061428))
                    .border(1.dp, HoloCyan.copy(alpha = 0.35f), shape).clickable { onOpenChat() }.padding(8.dp),
            ) {
                Text(if (last.fromUser) "VOCÊ" else "ALFREDO", color = HoloCyan, fontSize = 9.sp, letterSpacing = 2.sp, fontFamily = FontFamily.Monospace)
                Text(last.text, color = if (last.error) NexoColors.red else Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (vm.lastSource.isNotBlank()) "via ${vm.lastSource} · " else "") + "abrir conversa ›",
                    color = NexoColors.muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(4.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Fale ou escreva…", maxLines = 1) }, maxLines = 3,
            )
            Button(
                onClick = listen, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HoloOrange),
            ) { Text("🎙", fontSize = 18.sp) }
            Button(
                onClick = { vm.send(input); input = "" }, enabled = !vm.busy && input.isNotBlank(),
                shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HoloBlue),
            ) { Text("➤", fontSize = 18.sp) }
        }
    }
}
