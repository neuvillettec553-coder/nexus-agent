package com.jeconias.nexo.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.backup.BackupManager
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.Diagnostics
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DiagnosticsCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val results = remember { mutableStateListOf<Diagnostics.Check>() }
    var running by remember { mutableStateOf(false) }

    GlassCard {
        SectionTitle("DIAGNÓSTICO")
        Muted("Testa de verdade cada função e mostra o que passou e o que falhou.")
        Button(
            onClick = {
                results.clear()
                running = true
                scope.launch {
                    Diagnostics.runAll(ctx) { results.add(it) }
                    com.jeconias.nexo.core.Metrics.setDiagnostic(
                        results.count { it.state == Diagnostics.State.OK }, results.size
                    )
                    running = false
                }
            },
            enabled = !running,
        ) { Text(if (running) "Testando…" else "Rodar diagnóstico") }
        if (results.isNotEmpty()) {
            val ok = results.count { it.state == Diagnostics.State.OK }
            val fail = results.count { it.state == Diagnostics.State.FAIL }
            Text(
                "✅ $ok  ·  ⚠️ ${results.size - ok - fail}  ·  ❌ $fail",
                color = NexoColors.text, fontWeight = FontWeight.Bold,
            )
        }
        results.forEach { c ->
            val icon = when (c.state) {
                Diagnostics.State.OK -> "✅"
                Diagnostics.State.WARN -> "⚠️"
                Diagnostics.State.FAIL -> "❌"
            }
            Text("$icon ${c.name}", color = NexoColors.text, fontSize = 14.sp)
            Muted(c.detail)
        }
    }
}

@Composable
fun BackupCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = Container.settings
    var password by remember { mutableStateOf(settings.backupPassword()) }
    var msg by remember { mutableStateOf("") }
    var auto by remember { mutableStateOf(settings.backupFolder().isNotBlank()) }
    var restoreUri by remember { mutableStateOf<Uri?>(null) }
    var restorePass by remember { mutableStateOf("") }
    var last by remember { mutableStateOf(settings.lastBackup()) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            msg = "Salvando…"
            msg = try { BackupManager.exportTo(ctx, uri, password) } catch (e: Exception) { "❌ ${e.message}" }
            last = settings.lastBackup()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { restoreUri = uri; restorePass = "" }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                settings.setBackupFolder(uri.toString())
                BackupManager.scheduleAuto(ctx, true)
                auto = true
                msg = "✅ Backup automático ligado: uma vez por dia nessa pasta."
            } catch (e: Exception) {
                auto = false
                msg = "❌ Essa pasta não aceita gravação automática. Escolha uma pasta do celular."
            }
        } else {
            auto = settings.backupFolder().isNotBlank()
        }
    }

    GlassCard {
        SectionTitle("BACKUP DOS SEUS DADOS")
        Muted("Guarda memória, regras, skills, notas, configurações, rotinas e atalhos num arquivo protegido por senha.")
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; settings.setBackupPassword(it) },
            label = { Text("Senha do backup (anote num lugar seguro)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Muted(
            if (last == 0L) "Nenhum backup feito ainda."
            else "Último backup: " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(last))
        )
        Button(onClick = { exportLauncher.launch(BackupManager.fileName()) }, enabled = password.length >= 4, modifier = Modifier.fillMaxWidth()) {
            Text("Salvar backup agora")
        }
        OutlinedButton(onClick = {
            msg = "Enviando para o Google Drive…"
            scope.launch {
                msg = try {
                    val bytes = BackupManager.encryptedBytes(ctx, password)
                    val link = com.jeconias.nexo.connectors.GoogleServices.driveUpload(ctx, BackupManager.fileName(), bytes, "application/octet-stream")
                    settings.setLastBackup(System.currentTimeMillis()); last = settings.lastBackup()
                    "✅ Backup salvo no Drive (pasta NEXO): $link"
                } catch (e: Exception) { "❌ ${e.message}" }
            }
        }, enabled = password.length >= 4 && Container.connectors.googleConnected(), modifier = Modifier.fillMaxWidth()) {
            Text("☁ Salvar backup no Google Drive")
        }
        OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Restaurar um backup")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Backup automático diário", color = NexoColors.text, modifier = Modifier.weight(1f))
            Switch(checked = auto, enabled = password.length >= 4, onCheckedChange = { on ->
                if (on) {
                    folderLauncher.launch(null)
                } else {
                    auto = false
                    settings.setBackupFolder("")
                    BackupManager.scheduleAuto(ctx, false)
                    msg = "Backup automático desligado."
                }
            })
        }
        Muted("Dica: no “Salvar backup agora” você pode escolher o Google Drive. O automático grava numa pasta do celular.")
        if (msg.isNotBlank()) Muted(msg)
    }

    val uri = restoreUri
    if (uri != null) {
        AlertDialog(
            onDismissRequest = { restoreUri = null },
            title = { Text("Restaurar backup") },
            text = {
                OutlinedTextField(
                    value = restorePass, onValueChange = { restorePass = it },
                    label = { Text("Senha deste backup") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    restoreUri = null
                    scope.launch {
                        msg = "Restaurando…"
                        msg = try { BackupManager.importFrom(ctx, uri, restorePass) } catch (e: Exception) { "❌ ${e.message}" }
                    }
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { restoreUri = null }) { Text("Cancelar") } },
        )
    }
}

