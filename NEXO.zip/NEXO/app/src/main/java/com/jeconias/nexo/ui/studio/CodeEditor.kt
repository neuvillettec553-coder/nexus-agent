package com.jeconias.nexo.ui.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.studio.Language
import com.jeconias.nexo.studio.Tokenizer
import com.jeconias.nexo.ui.theme.NexoColors

private val COLOR_KEYWORD = Color(0xFFC792EA)
private val COLOR_STRING = Color(0xFFC3E88D)
private val COLOR_NUMBER = Color(0xFFF78C6C)
private val COLOR_COMMENT = Color(0xFF6A7AA0)

/** Pinta o código com as cores de cada tipo de pedaço (sem mudar o texto). */
class SyntaxHighlight(private val lang: Language) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val builder = AnnotatedString.Builder(raw)
        for (t in Tokenizer.tokenize(raw, lang)) {
            val style = when (t.type) {
                Tokenizer.Type.KEYWORD -> SpanStyle(color = COLOR_KEYWORD)
                Tokenizer.Type.STRING -> SpanStyle(color = COLOR_STRING)
                Tokenizer.Type.NUMBER -> SpanStyle(color = COLOR_NUMBER)
                Tokenizer.Type.COMMENT -> SpanStyle(color = COLOR_COMMENT, fontStyle = FontStyle.Italic)
            }
            builder.addStyle(style, t.start, t.end.coerceAtMost(raw.length))
        }
        return TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
    }

    override fun equals(other: Any?): Boolean = other is SyntaxHighlight && other.lang == lang
    override fun hashCode(): Int = lang.hashCode()
}

/** Editor com numeração de linhas, cores e rolagem nos dois sentidos (linhas longas não quebram). */
@Composable
fun CodeEditor(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    language: Language,
    modifier: Modifier = Modifier,
) {
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val lines = remember(value.text) { value.text.count { it == '\n' } + 1 }
    val style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp, color = NexoColors.text)
    val highlight = remember(language) { SyntaxHighlight(language) }

    Box(modifier.background(Color(0xFF070B18)).verticalScroll(vScroll)) {
        Row {
            Text(
                (1..lines).joinToString("\n"),
                style = style.copy(color = NexoColors.muted, textAlign = TextAlign.End),
                modifier = Modifier.background(Color(0xFF0B1124)).padding(horizontal = 6.dp, vertical = 8.dp),
            )
            Box(Modifier.horizontalScroll(hScroll)) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    textStyle = style,
                    cursorBrush = SolidColor(NexoColors.cyan),
                    visualTransformation = highlight,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrect = false,
                        keyboardType = KeyboardType.Text,
                    ),
                    modifier = Modifier.widthIn(min = 600.dp).padding(8.dp),
                )
            }
        }
    }
}

/** Fundo que ocupa tudo (usado na prévia vazia). */
@Composable
fun EmptyArea(text: String) {
    Box(Modifier.fillMaxSize().padding(16.dp)) { Text(text, color = NexoColors.muted, fontSize = 13.sp) }
}
