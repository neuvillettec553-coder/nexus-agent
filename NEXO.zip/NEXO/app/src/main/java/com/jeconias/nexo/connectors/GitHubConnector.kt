package com.jeconias.nexo.connectors

import android.content.Context
import android.util.Base64
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.studio.ProjectStore
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** GITHUB com token pessoal: listar repositórios e enviar projetos do Estúdio. */
object GitHubConnector {
    private const val API = "https://api.github.com"

    private data class Resp(val code: Int, val body: String)

    private suspend fun call(method: String, path: String, body: JSONObject? = null): Resp = withContext(Dispatchers.IO) {
        val token = Container.connectors.githubToken()
        require(token.isNotBlank()) { "GitHub não conectado. Cole o token em MODELS → CONNECTORS." }
        val b = Request.Builder().url(API + path)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
        val rb = body?.toString()?.toRequestBody("application/json".toMediaType())
        when (method) {
            "POST" -> b.post(rb!!)
            "PUT" -> b.put(rb!!)
            else -> b.get()
        }
        Container.http.newCall(b.build()).execute().use { r -> Resp(r.code, r.body?.string().orEmpty()) }
    }

    suspend fun login(): String {
        val r = call("GET", "/user")
        require(r.code == 200) { "Token recusado pelo GitHub (${r.code})." }
        return JSONObject(r.body).getString("login")
    }

    suspend fun repos(): List<String> {
        val r = call("GET", "/user/repos?per_page=30&sort=updated")
        require(r.code == 200) { "GitHub respondeu ${r.code}." }
        val arr = JSONArray(r.body)
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map { (if (it.optBoolean("private")) "🔒 " else "🌐 ") + it.optString("full_name") }
    }

    /** Envia todos os arquivos de um projeto do Estúdio para um repositório (cria o repositório privado se não existir). */
    suspend fun pushProject(ctx: Context, project: String, repo: String, message: String): String {
        val owner = login()
        val name = repo.trim().replace(Regex("[^A-Za-z0-9._-]"), "-")
        if (call("GET", "/repos/$owner/$name").code == 404) {
            val created = call("POST", "/user/repos", JSONObject().put("name", name).put("private", true).put("auto_init", true))
            require(created.code in 200..299) { "Não consegui criar o repositório (${created.code})." }
        }
        val store = ProjectStore(ctx.applicationContext)
        var sent = 0
        for (path in store.files(project)) {
            val existing = call("GET", "/repos/$owner/$name/contents/$path")
            val sha = if (existing.code == 200) JSONObject(existing.body).optString("sha") else null
            val content = Base64.encodeToString(store.read(project, path).toByteArray(), Base64.NO_WRAP)
            val body = JSONObject().put("message", message.ifBlank { "Atualizado pelo NEXO" }).put("content", content)
            if (!sha.isNullOrBlank()) body.put("sha", sha)
            val r = call("PUT", "/repos/$owner/$name/contents/$path", body)
            require(r.code in 200..299) { "Falhou em $path (${r.code}): ${r.body.take(120)}" }
            sent++
        }
        return "✅ $sent arquivo(s) enviados para github.com/$owner/$name"
    }
}

class GitHubRepos : Tool {
    override val name = "github_repos"
    override val level = Level.READ
    override val description = "Lista os repositórios do GitHub do usuário."
    override val parameters = schema()
    override suspend fun run(args: JSONObject) = ToolResult(true, GitHubConnector.repos().joinToString("\n"))
}

class GitHubEnviarProjeto(private val ctx: Context) : Tool {
    override val name = "github_enviar_projeto"
    override val level = Level.SENSITIVE
    override val description = "Envia um projeto do Estúdio para um repositório do GitHub do usuário (cria privado se não existir)."
    override val parameters = schema(
        Param("projeto", "string", "Nome do projeto no Estúdio"),
        Param("repositorio", "string", "Nome do repositório"),
        Param("mensagem", "string", "Mensagem do envio (commit)", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val project = args.optString("projeto")
        if (!ProjectStore(ctx.applicationContext).projects().contains(project)) return ToolResult(false, "Projeto não encontrado no Estúdio.")
        return ToolResult(true, GitHubConnector.pushProject(ctx, project, args.optString("repositorio").ifBlank { project }, args.optString("mensagem")))
    }
}
