package com.jeconias.nexo.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.ActionLog
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.service.AgentService
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle
import kotlinx.coroutines.launch

/** Situação real de cada função. Atualize aqui quando algo mudar. */
private data class Feature(val name: String, val state: String, val test: String)

private val FEATURES = listOf(
    Feature("Pesquisa Google (com fontes) e volta automática ao DuckDuckGo", "IMPLEMENTADO", "Pergunte algo atual: a resposta indica “via Google”."),
    Feature("Google Drive, Planilhas, Docs e YouTube", "IMPLEMENTADO", "Ative as 4 APIs no Google Cloud e reconecte o Google em CONNECTORS."),
    Feature("Rotas e lugares no Google Maps", "IMPLEMENTADO", "“Como chego na rodoviária?” → o Maps abre com a rota."),
    Feature("Respostas mais rápidas + botão Parar", "IMPLEMENTADO", "Enquanto pensa, aparece o tempo correndo, a IA atual e ■ Parar."),
    Feature("Central Financeira (raio-x, contas, dívidas, renda extra, metas)", "IMPLEMENTADO", "PREDICT → FINANCE CORE. Ou fale: “gastei 45 no mercado”."),
    Feature("Vida: tarefas, hábitos, metas com passos, diário e revisão semanal", "IMPLEMENTADO", "PREDICT → LIFE."),
    Feature("Agenda do celular e Resumo da manhã", "IMPLEMENTADO", "PREDICT → AGENDA (permitir) e MORNING BRIEF."),
    Feature("Memória organizada por assuntos + revisão semanal", "IMPLEMENTADO", "Cérebro → MEMORY.md mostra as seções."),
    Feature("Estúdio por conversa (descreva o que quer)", "IMPLEMENTADO", "Estúdio → campo do topo → Criar → Aplicar e rodar."),
    Feature("Conectores: Gmail, GitHub, catálogo MCP com permissões", "IMPLEMENTADO", "MODELS → CONNECTORS. Gmail exige o guia do Google Cloud (uma vez)."),
    Feature("Interface “Advanced AI Cognitive Core”", "IMPLEMENTADO", "Barra COGNITIVE · MODELS · PREDICT · LOG. Toque em qualquer placa: o painel se projeta como holograma."),
    Feature("Métricas reais (Autonomia, Adaptação, Integração, Evolução)", "IMPLEMENTADO", "Use o Alfredo alguns dias: o gráfico AI Behavioral Evolution ganha forma."),
    Feature("Estúdio de programação", "IMPLEMENTADO", "Aba Estúdio → Novo projeto → Python → ▶ Rodar. Depois peça “🤖 IA → Criar testes”."),
    Feature("Rodar código: Python, JavaScript, Lua, SQL, Shell e prévia HTML/CSS", "IMPLEMENTADO", "No Estúdio, crie o modelo de Site e toque em ▶ Rodar: a prévia aparece embaixo."),
    Feature("Rodar e corrigir sozinho (até 3 tentativas)", "IMPLEMENTADO", "Coloque um erro de propósito e toque em 🔁 Rodar e corrigir."),
    Feature("Testes automáticos antes de gerar o APK", "IMPLEMENTADO", "Feito no GitHub: se algum teste falhar, o APK não é gerado."),
    Feature("Rodar Java, C, C++, Kotlin, Go, Rust, PHP", "PRÓXIMA FASE", "Hoje a IA escreve e revisa; executar depende de um serviço pela internet."),
    Feature("Motor Local (sem internet) que aprende", "IMPLEMENTADO", "“Que horas são”, “abre o YouTube”, “anota comprar pão”: resposta instantânea, marcada “via Motor Local”."),
    Feature("Conselho de IAs + painel FLUXO", "IMPLEMENTADO", "Diga “consulta o conselho: …” com 2 ou mais IAs ativas e acompanhe no painel FLUXO."),
    Feature("Confirmação de ações sensíveis", "IMPLEMENTADO", "Peça para mandar um WhatsApp: deve aparecer “Posso fazer isso?” antes."),
    Feature("Backup criptografado", "IMPLEMENTADO", "Defina a senha, salve um backup e confira o arquivo .nexo."),
    Feature("Diagnóstico automático", "IMPLEMENTADO", "Toque em “Rodar diagnóstico” no topo desta aba."),
    Feature("Conversa com várias IAs e troca automática", "IMPLEMENTADO", "Desligue a 1ª IA da lista e mande uma mensagem: deve responder pela 2ª (aparece embaixo da resposta)."),
    Feature("AGENTS.md + MEMORY.md lidos a cada mensagem", "IMPLEMENTADO", "Escreva em MEMORY.md “o usuário torce para o time X” e pergunte “pra que time eu torço?”."),
    Feature("Aprender sozinho (memória evolutiva)", "IMPLEMENTADO", "Diga “lembra que eu tomo café sem açúcar” e confira em Cérebro → MEMORY.md."),
    Feature("Lembretes", "IMPLEMENTADO", "“Me lembra daqui 2 minutos de beber água” → notificação em ~2 min."),
    Feature("Alarme no Relógio", "IMPLEMENTADO", "“Coloca um alarme às 6:30” → conferir no app Relógio."),
    Feature("Abrir apps pelo nome ou descrição", "IMPLEMENTADO", "“Abre o YouTube”. Nome errado: ele deve dizer que não achou, e não abrir outro."),
    Feature("Pesquisa na internet", "IMPLEMENTADO", "“Pesquise o resultado do último jogo do Flamengo”."),
    Feature("Rotinas automáticas", "IMPLEMENTADO", "“A cada 1 hora me manda uma frase motivacional” → notificação em ~1h."),
    Feature("Skills (procedimentos salvos)", "IMPLEMENTADO", "“Use a skill lista-de-compras e adicione arroz”."),
    Feature("Notas", "IMPLEMENTADO", "“Anota: comprar parafuso 8mm” e depois “o que eu anotei?”."),
    Feature("WhatsApp com mensagem pronta", "IMPLEMENTADO", "“Manda no WhatsApp pro 55… dizendo que chego às 18h” → você só toca em enviar."),
    Feature("Voz: escolher, testar e usar", "IMPLEMENTADO", "Aba Voz → Testar → Usar esta voz → mande uma mensagem."),
    Feature("Parar depois de 2 falhas seguidas", "IMPLEMENTADO", "Peça para abrir um app que não existe duas vezes: ele deve parar e perguntar."),
    Feature("Registro de ações reais", "IMPLEMENTADO", "Toda ação aparece abaixo com OK ou FALHA."),
    Feature("Conectores MCP", "EXPERIMENTAL", "Adicione a URL de um servidor MCP remoto e toque em Conectar."),
    Feature("Modo 24/7", "EXPERIMENTAL", "Ligue abaixo e libere a bateria. A Realme pode fechar mesmo assim."),
    Feature("Edge-TTS", "PRÓXIMA FASE", "—"),
    Feature("Controlar a tela (tocar, digitar, fechar apps)", "PRÓXIMA FASE", "—"),
    Feature("Chamar pelo nome sem tocar", "PRÓXIMA FASE", "—"),
    Feature("Gmail nativo", "PRÓXIMA FASE", "Hoje só via servidor MCP."),
)

@SuppressLint("BatteryLife")
@Composable
fun SystemScreen() {
    val ctx = LocalContext.current
    val settings = Container.settings
    val scope = rememberCoroutineScope()
    var persistent by remember { mutableStateOf(settings.persistentMode()) }
    var refresh by remember { mutableIntStateOf(0) }
    val routines = remember(refresh) { Container.routines.all() }
    val servers = remember(refresh) { Container.mcp.servers() }
    var mcpName by remember { mutableStateOf("") }
    var mcpUrl by remember { mutableStateOf("") }
    var mcpToken by remember { mutableStateOf("") }
    var connecting by remember { mutableStateOf(false) }
    val pm = ctx.getSystemService(PowerManager::class.java)
    val batteryFree = pm?.isIgnoringBatteryOptimizations(ctx.packageName) == true

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { DiagnosticsCard() }
        item { BackupCard() }

        // ---------- Modo 24/7 ----------
        item {
            GlassCard {
                SectionTitle("MODO 24/7")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Agente sempre ativo", color = NexoColors.text, modifier = Modifier.weight(1f))
                    Switch(checked = persistent, onCheckedChange = {
                        persistent = it
                        settings.setPersistentMode(it)
                        if (it) AgentService.start(ctx) else AgentService.stop(ctx)
                    })
                }
                Muted(if (batteryFree) "✅ Bateria liberada para o NEXO." else "⚠️ A economia de bateria pode fechar o NEXO.")
                if (!batteryFree) OutlinedButton(onClick = {
                    runCatching {
                        ctx.startActivity(
                            Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                        )
                    }
                }) { Text("Liberar bateria") }
            }
        }

        // ---------- Rotinas ----------
        item { SectionTitle("ROTINAS AUTOMÁTICAS") }
        if (routines.isEmpty()) item { Muted("Nenhuma. Peça na conversa, ex.: “todo dia às 7h me dá a previsão do tempo”.") }
        items(routines, key = { it.id }) { r ->
            GlassCard {
                Text(r.nome, color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted((if (r.tipo == "diaria") "Todo dia às ${r.hora}" else "A cada ${r.horas}h") + " · ${r.instrucao}")
                TextButton(onClick = { Container.routines.remove(r.id); refresh++ }) { Text("Cancelar rotina", color = NexoColors.red) }
            }
        }

        // ---------- MCP ----------
        item {
            GlassCard {
                SectionTitle("CONECTORES MCP (EXPERIMENTAL)")
                Muted("Só servidores remotos (endereço https). Cada ferramenta do servidor vira uma ferramenta do agente.")
                OutlinedTextField(value = mcpName, onValueChange = { mcpName = it }, label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = mcpUrl, onValueChange = { mcpUrl = it }, label = { Text("URL do servidor") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = mcpToken, onValueChange = { mcpToken = it }, label = { Text("Token (opcional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            Container.mcp.add(mcpName.ifBlank { "Servidor" }, mcpUrl, mcpToken)
                            mcpName = ""; mcpUrl = ""; mcpToken = ""; refresh++
                        },
                        enabled = mcpUrl.startsWith("http"),
                    ) { Text("Adicionar") }
                    OutlinedButton(onClick = {
                        connecting = true
                        scope.launch {
                            runCatching { Container.mcp.connectAll() }
                            connecting = false; refresh++
                        }
                    }, enabled = !connecting && servers.isNotEmpty()) { Text(if (connecting) "Conectando…" else "Conectar") }
                }
            }
        }
        items(servers, key = { it.id }) { s ->
            GlassCard {
                Text(s.nome, color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted(s.url)
                Muted(Container.mcp.status[s.id] ?: "Ainda não conectado")
                TextButton(onClick = { Container.mcp.remove(s.id); refresh++ }) { Text("Remover", color = NexoColors.red) }
            }
        }

        // ---------- Registro de ações ----------
        item { SectionTitle("REGISTRO DE AÇÕES") }
        if (ActionLog.entries.isEmpty()) item { Muted("Nenhuma ação ainda.") }
        items(ActionLog.entries.take(30)) { e ->
            GlassCard {
                Row {
                    Text(if (e.ok) "OK " else "FALHA ", color = if (e.ok) NexoColors.green else NexoColors.red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${e.tool} · ${e.time}", color = NexoColors.text, fontSize = 12.sp)
                }
                Muted(e.output)
            }
        }

        // ---------- Status real ----------
        item {
            SectionTitle("STATUS REAL DAS FUNÇÕES")
            Muted("IMPLEMENTADO = o código existe; confirme com o teste. EXPERIMENTAL = funciona com limites. PRÓXIMA FASE = ainda não existe.")
        }
        items(FEATURES) { f ->
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name, color = NexoColors.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text(
                        f.state, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        color = when (f.state) {
                            "IMPLEMENTADO" -> NexoColors.green
                            "EXPERIMENTAL" -> NexoColors.amber
                            else -> NexoColors.muted
                        },
                    )
                }
                if (f.test != "—") Muted("Teste: ${f.test}")
            }
        }
        item {
            Muted("NEXO versão ${runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"}")
        }
    }
}
