package com.jeconias.nexo.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle
import kotlinx.coroutines.launch

@Composable
fun VoiceScreen() {
    val settings = Container.settings
    val voice = Container.voice
    val scope = rememberCoroutineScope()
    var active by remember { mutableStateOf(settings.activeVoice()) }
    var speak by remember { mutableStateOf(settings.speakReplies()) }
    var testMsg by remember { mutableStateOf("") }
    var geminiVoice by remember { mutableStateOf(settings.geminiVoiceName()) }
    var ttsModel by remember { mutableStateOf(settings.geminiTtsModel()) }
    var elevenKey by remember { mutableStateOf(settings.elevenKey()) }
    var elevenVoice by remember { mutableStateOf(settings.elevenVoiceId()) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            SectionTitle("VOZ")
            Muted("Toque em “Usar esta voz” para escolher. Se ela falhar, o NEXO usa a próxima disponível e, por último, a voz do celular.")
        }
        item {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Falar as respostas", color = NexoColors.text, modifier = Modifier.weight(1f))
                    Switch(checked = speak, onCheckedChange = { speak = it; settings.setSpeakReplies(it) })
                }
                if (testMsg.isNotBlank()) Muted(testMsg)
            }
        }
        items(voice.engines, key = { it.id }) { engine ->
            val isActive = engine.id == active
            val available = engine.available()
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(engine.label, color = NexoColors.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        when {
                            isActive -> "● EM USO"
                            available -> "disponível"
                            else -> "falta configurar"
                        },
                        color = when {
                            isActive -> NexoColors.green
                            available -> NexoColors.cyan
                            else -> NexoColors.amber
                        },
                        fontSize = 12.sp,
                    )
                }
                Muted("Precisa: ${engine.needs}")

                if (engine.id == "gemini") {
                    Muted("Voz do Gemini:")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(voice.geminiVoices) { name ->
                            val sel = name == geminiVoice
                            OutlinedButton(
                                onClick = { geminiVoice = name; settings.setGeminiVoiceName(name) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (sel) NexoColors.cyan.copy(alpha = 0.2f) else NexoColors.deep.copy(alpha = 0f)
                                ),
                            ) { Text(name, fontSize = 12.sp) }
                        }
                    }
                    OutlinedTextField(
                        value = ttsModel,
                        onValueChange = { ttsModel = it; settings.setGeminiTtsModel(it) },
                        label = { Text("Modelo de voz do Gemini") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (engine.id == "elevenlabs") {
                    OutlinedTextField(
                        value = elevenKey,
                        onValueChange = { elevenKey = it; settings.setElevenKey(it) },
                        label = { Text("Chave da ElevenLabs") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = elevenVoice,
                        onValueChange = { elevenVoice = it; settings.setElevenVoiceId(it) },
                        label = { Text("ID da voz") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        testMsg = "Testando ${engine.label}…"
                        scope.launch {
                            val ok = voice.test(engine.id)
                            testMsg = if (ok) "✅ ${engine.label} funcionou." else "❌ ${engine.label} não funcionou (confira a chave ou a internet)."
                        }
                    }) { Text("Testar") }
                    Button(
                        onClick = { active = engine.id; settings.setActiveVoice(engine.id); testMsg = "Voz ativa: ${engine.label}" },
                        enabled = !isActive,
                    ) { Text(if (isActive) "Em uso" else "Usar esta voz") }
                }
            }
        }
        item {
            GlassCard {
                Text("Edge-TTS", color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted("Próxima fase. Ainda não está no app, por isso não aparece como opção.")
            }
        }
    }
}
