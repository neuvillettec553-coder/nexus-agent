package com.jeconias.nexo.studio

import android.annotation.SuppressLint
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintStream
import java.util.concurrent.TimeUnit

/** Resultado de uma execução: a saída e se houve erro. */
data class RunResult(val output: String, val error: Boolean, val ms: Long)

/**
 * Interpretadores EMBUTIDOS (funcionam sem internet):
 * Python 3.11 (Chaquopy), JavaScript (motor do Android), Lua (LuaJ), SQL (SQLite) e Shell.
 * Base reaproveitada do Alfredo, onde já funcionava no seu celular.
 */
object Runners {
    private const val NO_OUTPUT = "(executou sem imprimir nada)"

    fun looksLikeError(output: String): Boolean =
        Regex("Traceback|\\bERRO\\b|\\bError\\b|Exception|SyntaxError|ReferenceError|TypeError|undefined is not", RegexOption.IGNORE_CASE)
            .containsMatchIn(output)

    private suspend fun limited(ms: Long, block: () -> String): RunResult = coroutineScope {
        val t0 = System.currentTimeMillis()
        val job = async(Dispatchers.Default) {
            try { block() } catch (e: Throwable) { "ERRO: ${e.message ?: e.javaClass.simpleName}" }
        }
        val out = withTimeoutOrNull(ms) { job.await() }
            ?: "ERRO: passou de ${ms / 1000} s e eu parei de esperar (talvez um laço sem fim)."
        RunResult(out.take(20_000), looksLikeError(out), System.currentTimeMillis() - t0)
    }

    // ---------- Python ----------
    private fun python(ctx: Context): com.chaquo.python.Python {
        if (!com.chaquo.python.Python.isStarted()) {
            com.chaquo.python.Python.start(com.chaquo.python.android.AndroidPlatform(ctx.applicationContext))
        }
        return com.chaquo.python.Python.getInstance()
    }

    suspend fun pythonProject(ctx: Context, files: Map<String, String>, main: String): RunResult = limited(45_000) {
        val py = python(ctx)
        val dict = py.builtins.callAttr("dict")
        files.forEach { (name, content) -> dict.callAttr("__setitem__", name, content) }
        py.getModule("nexo_exec").callAttr("executar_projeto", dict, main).toString().ifBlank { NO_OUTPUT }
    }

    suspend fun pythonCode(ctx: Context, code: String): RunResult = limited(30_000) {
        python(ctx).getModule("nexo_exec").callAttr("executar", code).toString().ifBlank { NO_OUTPUT }
    }

    // ---------- Lua ----------
    suspend fun lua(code: String): RunResult = limited(20_000) {
        val out = ByteArrayOutputStream()
        val globals = org.luaj.vm2.lib.jse.JsePlatform.standardGlobals()
        globals.STDOUT = PrintStream(out, true)
        try {
            val r = globals.load(code).call()
            (out.toString() + if (!r.isnil()) "=> ${r.tojstring()}" else "").ifBlank { NO_OUTPUT }
        } catch (e: org.luaj.vm2.LuaError) {
            out.toString() + "ERRO: ${e.message}"
        }
    }

    // ---------- SQL (banco temporário) ----------
    suspend fun sql(code: String): RunResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val db = SQLiteDatabase.create(null)
        val sb = StringBuilder()
        var error = false
        try {
            code.split(";").map { it.trim() }.filter { it.isNotBlank() }.forEach { cmd ->
                if (Regex("^(select|pragma|with)\\b", RegexOption.IGNORE_CASE).containsMatchIn(cmd)) {
                    db.rawQuery(cmd, null).use { c ->
                        sb.append(c.columnNames.joinToString(" | ")).append('\n')
                        var n = 0
                        while (c.moveToNext() && n < 500) {
                            sb.append((0 until c.columnCount).joinToString(" | ") { i -> c.getString(i) ?: "NULL" }).append('\n')
                            n++
                        }
                        sb.append("($n linha(s))\n")
                    }
                } else db.execSQL(cmd)
            }
        } catch (e: Exception) {
            sb.append("ERRO: ${e.message}")
            error = true
        } finally {
            db.close()
        }
        RunResult(sb.toString().ifBlank { "(comandos executados)" }, error, System.currentTimeMillis() - t0)
    }

    // ---------- Shell (pasta isolada do projeto) ----------
    suspend fun shell(workDir: File, command: String): RunResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        try {
            val proc = ProcessBuilder("sh", "-c", command).directory(workDir).redirectErrorStream(true).start()
            val finished = proc.waitFor(20, TimeUnit.SECONDS)
            val out = proc.inputStream.bufferedReader().readText()
            if (!finished) {
                proc.destroy()
                return@withContext RunResult("$out\nERRO: passou de 20 s e eu parei o comando.", true, System.currentTimeMillis() - t0)
            }
            val code = proc.exitValue()
            RunResult(
                (out + if (code != 0) "\nERRO: o comando terminou com código $code" else "").ifBlank { "(sem saída)" }.take(20_000),
                code != 0, System.currentTimeMillis() - t0,
            )
        } catch (e: Exception) {
            RunResult("ERRO: ${e.message}", true, System.currentTimeMillis() - t0)
        }
    }

    // ---------- JavaScript (motor do Android, numa WebView invisível) ----------
    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    suspend fun javascript(ctx: Context, code: String): RunResult {
        val t0 = System.currentTimeMillis()
        val done = CompletableDeferred<String>()
        val logs = StringBuilder()
        var webView: WebView? = null
        withContext(Dispatchers.Main) {
            val wv = WebView(ctx.applicationContext)
            webView = wv
            wv.settings.javaScriptEnabled = true
            wv.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                    synchronized(logs) {
                        val prefix = if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) "ERRO: " else ""
                        logs.append(prefix).append(m.message()).append('\n')
                    }
                    return true
                }
            }
            wv.addJavascriptInterface(object {
                @JavascriptInterface
                fun finish(result: String) { done.complete(result) }
            }, "NEXO")
            val quoted = JSONObject.quote(code)
            val html = """
                <html><body><script>
                (async function(){
                  try {
                    const r = await (0, eval)($quoted);
                    if (r !== undefined) console.log('=> ' + (typeof r === 'object' ? JSON.stringify(r) : String(r)));
                  } catch (e) {
                    console.error((e && e.name ? e.name + ': ' : '') + (e && e.message ? e.message : e) + (e && e.stack ? '\n' + e.stack : ''));
                  }
                  setTimeout(function(){ NEXO.finish('ok'); }, 50);
                })();
                </script></body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL("https://nexo.local/", html, "text/html", "utf-8", null)
        }
        val finished = withTimeoutOrNull(20_000) { done.await() } != null
        withContext(Dispatchers.Main) { webView?.destroy() }
        val out = synchronized(logs) { logs.toString() }.ifBlank { NO_OUTPUT } +
            if (!finished) "\nERRO: passou de 20 s e eu parei de esperar." else ""
        return RunResult(out.take(20_000), !finished || looksLikeError(out), System.currentTimeMillis() - t0)
    }
}
