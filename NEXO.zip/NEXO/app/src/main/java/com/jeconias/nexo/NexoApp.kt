package com.jeconias.nexo

import android.app.Application
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.Notifications

/** Ponto de partida do app: monta todas as peças uma única vez. */
class NexoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
        Container.init(this)
    }
}
