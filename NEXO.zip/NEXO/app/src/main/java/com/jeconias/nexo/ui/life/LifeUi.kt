package com.jeconias.nexo.ui.life

import android.content.Intent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors

/** Abas internas de um painel projetado. */
@Composable
fun SubTabs(tabs: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        tabs.forEachIndexed { i, t ->
            val sel = i == selected
            Text(
                t, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                color = if (sel) Color.Black else HoloCyan, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(if (sel) HoloCyan else HoloCyan.copy(alpha = 0.10f))
                    .clickable { onSelect(i) }.padding(horizontal = 12.dp, vertical = 7.dp),
            )
        }
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, number: Boolean = false, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = !label.startsWith("…"),
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Decimal else KeyboardType.Text),
        modifier = modifier,
    )
}

@Composable
fun Chips(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o ->
            val sel = o == selected
            Text(
                o, fontSize = 12.sp, color = if (sel) Color.Black else NexoColors.text, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (sel) HoloCyan else Color.White.copy(alpha = 0.08f))
                    .clickable { onSelect(o) }.padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

/** Barra de progresso simples (0 a 1). */
@Composable
fun Bar(fraction: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.08f))) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().background(color))
    }
}

/** Resposta da IA com botões de copiar e compartilhar. */
@Composable
fun AiResult(text: String, docTitle: String? = null) {
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var docMsg by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    GlassCard {
        SelectionContainer { Text(text, color = NexoColors.text, fontSize = 13.sp) }
        Row {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copiar") }
            TextButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                runCatching { ctx.startActivity(Intent.createChooser(send, "Compartilhar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }) { Text("Compartilhar") }
            if (docTitle != null && com.jeconias.nexo.core.Container.connectors.googleConnected()) TextButton(onClick = {
                docMsg = "Criando no Google Docs…"
                scope.launch {
                    docMsg = try {
                        val link = com.jeconias.nexo.connectors.GoogleServices.docCreate(ctx, docTitle, text)
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        "✅ Salvo no Google Docs."
                    } catch (e: Exception) { "❌ ${e.message}" }
                }
            }) { Text("Docs") }
        }
        if (docMsg.isNotBlank()) Muted(docMsg)
    }
}

@Composable
fun Busy(text: String) { if (text.isNotBlank()) Text(text, color = NexoColors.amber, fontSize = 12.sp) }

@Composable
fun Empty(text: String) = Muted(text)

/** Trava por digital/senha do celular. Sem bloqueio de tela configurado, libera direto. */
object Lock {
    private var unlockedUntil = 0L

    fun isUnlocked() = System.currentTimeMillis() < unlockedUntil

    fun request(activity: FragmentActivity?, onResult: (Boolean, String) -> Unit) {
        if (isUnlocked()) { onResult(true, ""); return }
        if (activity == null) { onResult(true, ""); return }
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(activity).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            onResult(true, "Sem digital ou senha de tela configurada: Finanças ficam sem trava.")
            return
        }
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlockedUntil = System.currentTimeMillis() + 5 * 60_000L
                onResult(true, "")
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                onResult(false, errString.toString())
            }
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Central Financeira")
                .setSubtitle("Confirme que é você")
                .setAllowedAuthenticators(auth)
                .build()
        )
    }
}

@Composable
fun SmallButton(label: String, onClick: () -> Unit) = OutlinedButton(onClick = onClick) { Text(label, fontSize = 12.sp, maxLines = 1) }

fun Modifier.full() = this.fillMaxWidth()

@Composable
fun SectionLabel(text: String) = Text(text, color = HoloCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))

@Composable
fun Stack(content: @Composable () -> Unit) = Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
