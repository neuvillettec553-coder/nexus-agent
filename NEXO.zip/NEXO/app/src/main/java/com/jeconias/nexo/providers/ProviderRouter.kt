package com.jeconias.nexo.providers

import com.jeconias.nexo.core.Settings
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Roteador com fallback automático e "pausa inteligente":
 *  - IA sem saldo ou com chave recusada fica 6 h fora da fila;
 *  - IA com limite estourado (429) fica 2 min fora;
 *  - modelo inexistente (404) fica 30 min fora.
 * Assim o Alfredo não perde tempo tentando, em toda mensagem, uma IA que vai falhar.
 */
class ProviderRouter(private val settings: Settings, private val http: OkHttpClient) {

    data class Attempt(val provider: String, val ok: Boolean, val detail: String)
    private data class Pause(val until: Long, val reason: String)

    @Volatile
    var lastAttempts: List<Attempt> = emptyList()
        private set

    private val paused = ConcurrentHashMap<String, Pause>()

    /** Desiste de uma IA que não responde em 40 s e passa logo para a próxima. */
    private val chatHttp: OkHttpClient = http.newBuilder().callTimeout(40, java.util.concurrent.TimeUnit.SECONDS).build()

    /** Qual IA está sendo consultada agora (a tela mostra). */
    @Volatile
    var currentProvider: String = ""
        private set

    fun build(info: ProviderInfo, key: String, model: String): LlmProvider = when (info.style) {
        ApiStyle.OPENAI -> OpenAiCompatibleProvider(info, key, model, chatHttp)
        ApiStyle.ANTHROPIC -> AnthropicProvider(info, key, model, chatHttp)
    }

    /** Todas as IAs ligadas e com chave, na ordem escolhida. */
    fun activeProviders(): List<LlmProvider> = settings.providerOrder().mapNotNull { id ->
        val info = ProviderCatalog.byId(id) ?: return@mapNotNull null
        val key = settings.apiKey(id)
        if (!settings.isEnabled(id) || key.isBlank()) null else build(info, key, settings.model(id))
    }

    /** As ativas que não estão em pausa. Se todas estiverem em pausa, devolve todas (melhor tentar do que ficar mudo). */
    fun availableProviders(): List<LlmProvider> {
        val now = System.currentTimeMillis()
        val all = activeProviders()
        val ok = all.filter { (paused[it.info.id]?.until ?: 0L) < now }
        return ok.ifEmpty { all }
    }

    fun pauseInfo(id: String): String? {
        val p = paused[id] ?: return null
        if (p.until < System.currentTimeMillis()) { paused.remove(id); return null }
        val hora = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date(p.until))
        return "⏸ Em pausa até $hora (${p.reason})"
    }

    fun clearPause(id: String) { paused.remove(id) }

    private fun registerFailure(id: String, message: String) {
        val m = message.lowercase()
        val now = System.currentTimeMillis()
        val pause = when {
            "http 402" in m || "insufficient" in m || "balance" in m || "credit" in m ->
                Pause(now + 6 * 3_600_000L, "sem saldo")
            "http 401" in m || "http 403" in m -> Pause(now + 6 * 3_600_000L, "chave recusada")
            "http 404" in m -> Pause(now + 30 * 60_000L, "modelo não encontrado")
            "http 429" in m -> Pause(now + 2 * 60_000L, "limite atingido")
            else -> null
        }
        if (pause != null) paused[id] = pause
    }

    private suspend fun tryInOrder(providers: List<LlmProvider>, messages: List<ChatMessage>, tools: List<ToolSpec>): LlmResponse {
        if (providers.isEmpty()) {
            throw ProviderException("Nenhuma IA configurada. Abra a aba IAs e cole pelo menos uma chave.")
        }
        val attempts = mutableListOf<Attempt>()
        for (p in providers) {
            currentProvider = p.info.name
            try {
                val r = p.chat(messages, tools)
                attempts.add(Attempt(p.info.name, true, "ok"))
                lastAttempts = attempts
                return r
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                registerFailure(p.info.id, if (msg.contains("timeout", true)) "HTTP 429 timeout" else msg)
                attempts.add(Attempt(p.info.name, false, msg))
                com.jeconias.nexo.core.FlowLog.add("REDE", p.info.name, "Falhou (${msg.take(80)}). Tentando a próxima IA.", ok = false)
            }
        }
        lastAttempts = attempts
        throw ProviderException(
            "Todas as IAs falharam:\n" + attempts.joinToString("\n") { "• ${it.provider}: ${it.detail.take(160)}" }
        )
    }

    suspend fun chat(messages: List<ChatMessage>, tools: List<ToolSpec>): LlmResponse =
        tryInOrder(availableProviders(), messages, tools)

    /**
     * Para o Conselho: cada papel começa por uma IA diferente da fila
     * (papel 0 = 1ª IA, papel 1 = 2ª IA...), e cai para as seguintes se falhar.
     */
    suspend fun chatRole(role: Int, messages: List<ChatMessage>): LlmResponse {
        val list = availableProviders()
        if (list.isEmpty()) return tryInOrder(list, messages, emptyList())
        val start = role % list.size
        val rotated = list.drop(start) + list.take(start)
        return tryInOrder(rotated, messages, emptyList())
    }

    /** Teste isolado de um provedor, para o botão "Testar" da aba IAs. */
    suspend fun test(id: String): String {
        val info = ProviderCatalog.byId(id) ?: return "Provedor desconhecido"
        val key = settings.apiKey(id)
        if (key.isBlank()) return "Sem chave."
        return try {
            val r = build(info, key, settings.model(id))
                .chat(listOf(ChatMessage("user", "Responda apenas com a palavra OK.")), emptyList())
            clearPause(id)
            "✅ Funcionando: ${r.text.trim().take(40)}"
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            registerFailure(id, msg)
            "❌ ${msg.take(300)}"
        }
    }

    companion object {
        /** Lê o aviso do provedor e tira o nome do modelo novo que ele sugere, se houver. */
        fun suggestModel(error: String): String? =
            Regex("(?i)\\b(?:use|instead:?)\\s+(?:this slug instead:\\s*)?(?:models/)?([A-Za-z0-9._:/-]{3,})")
                .findAll(error)
                .map { it.groupValues[1].trimEnd('.', ',', '"', '\'') }
                .firstOrNull { name -> name.any(Char::isDigit) || "/" in name }
    }
}
