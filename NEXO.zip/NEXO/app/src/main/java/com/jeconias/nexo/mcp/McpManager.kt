package com.jeconias.nexo.mcp

import com.jeconias.nexo.core.Settings
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolRegistry
import com.jeconias.nexo.tools.ToolResult
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Guarda os servidores MCP e transforma as ferramentas deles em ferramentas do agente. */
class McpManager(
    private val settings: Settings,
    private val http: OkHttpClient,
    private val registry: ToolRegistry,
) {
    /** Situação de cada servidor, para mostrar na tela. */
    val status = mutableMapOf<String, String>()

    /** Ferramentas oferecidas por cada servidor (para a tela de permissões). */
    val toolsByServer = mutableMapOf<String, List<McpToolInfo>>()

    /** Conectores prontos: nome, endereço, se precisa de token e onde conseguir. */
    data class Preset(val name: String, val url: String, val needsToken: Boolean, val tokenHelp: String, val what: String)

    val catalog = listOf(
        Preset("GitHub (MCP oficial)", "https://api.githubcopilot.com/mcp/", true, "https://github.com/settings/tokens", "Repositórios, issues, pull requests e código."),
        Preset("Context7", "https://mcp.context7.com/mcp", false, "", "Documentação atualizada de bibliotecas, para programar no Estúdio."),
        Preset("DeepWiki", "https://mcp.deepwiki.com/mcp", false, "", "Explica qualquer repositório público do GitHub."),
        Preset("Hugging Face", "https://huggingface.co/mcp", true, "https://huggingface.co/settings/tokens", "Modelos, datasets e ferramentas de IA."),
        Preset("Zapier (seu link pessoal)", "", false, "https://mcp.zapier.com", "Liga o Alfredo a milhares de apps (Planilhas, Drive, Trello…). Cole o link gerado no site do Zapier."),
    )

    fun servers(): List<McpServerConfig> {
        val arr = JSONArray(settings.mcpServersJson())
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            McpServerConfig(o.getString("id"), o.getString("nome"), o.getString("url"), o.optString("token"))
        }
    }

    private fun save(list: List<McpServerConfig>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("nome", it.nome).put("url", it.url).put("token", it.token)) }
        settings.setMcpServersJson(arr.toString())
    }

    fun add(nome: String, url: String, token: String) =
        save(servers() + McpServerConfig(UUID.randomUUID().toString().take(6), nome.trim(), url.trim(), token.trim()))

    fun remove(id: String) {
        save(servers().filter { it.id != id })
        registry.unregisterPrefix("mcp_${id}_")
        status.remove(id)
    }

    /** Conecta todos e registra as ferramentas com o prefixo mcp_<id>_. */
    suspend fun connectAll() {
        for (s in servers()) {
            registry.unregisterPrefix("mcp_${s.id}_")
            try {
                val client = McpClient(s, http)
                val tools = client.connect()
                toolsByServer[s.id] = tools
                val perms = com.jeconias.nexo.core.Container.connectors
                tools.forEach { info ->
                    val perm = perms.mcpPermission(s.id, info.name)
                    if (perm == "bloqueado") return@forEach
                    val toolName = ("mcp_${s.id}_" + info.name.replace(Regex("[^a-zA-Z0-9_-]"), "_")).take(64)
                    registry.register(object : Tool {
                        override val name = toolName
                        override val description = "[${s.nome}] ${info.description}".take(1000)
                        override val parameters = info.inputSchema
                        override val level = if (perm == "sempre") Level.ACT else Level.SENSITIVE
                        override suspend fun run(args: JSONObject): ToolResult {
                            val (ok, out) = client.call(info.name, args)
                            return ToolResult(ok, out.take(6000))
                        }
                    })
                }
                val blocked = tools.count { perms.mcpPermission(s.id, it.name) == "bloqueado" }
                status[s.id] = "✅ conectado — ${tools.size} ferramentas" + if (blocked > 0) " ($blocked bloqueadas)" else ""
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status[s.id] = "❌ ${e.message?.take(150)}"
            }
        }
    }
}
