package com.jeconias.nexo.ui.deck

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.ActionLog
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.core.Metrics
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.holo.LocalProjector
import com.jeconias.nexo.ui.holo.Projection
import com.jeconias.nexo.ui.hud.FlowEventLine
import com.jeconias.nexo.ui.hud.FlowScreen
import com.jeconias.nexo.ui.hud.rememberTilt
import com.jeconias.nexo.ui.screens.BackupCard
import com.jeconias.nexo.ui.screens.DiagnosticsCard
import com.jeconias.nexo.ui.screens.SystemScreen
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.delay

/** LOG: fluxo ao vivo, ações, diagnóstico, backup e sistema. */
@Composable
fun LogDeck() {
    val ctx = LocalContext.current
    val projector = LocalProjector.current
    val tilt = rememberTilt()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(10_000); tick++ } }
    val integration = remember(tick, Metrics.version) { Metrics.integration(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        DeckHeader(
            "SYSTEM LOG", "FLOW · ACTIONS · DIAGNOSTICS",
            "Requests today" to "${Metrics.requestsToday()}", "Integration" to "${integration.percent}%",
        )
        Spacer(Modifier.height(8.dp))
        HoloTile("LIVE FLOW", tilt, Modifier.fillMaxWidth().padding(horizontal = 10.dp), accent = HoloCyan, onClick = {
            projector.project(Projection("Fluxo", HoloCyan) { FlowScreen(onBack = { projector.close() }) })
        }) {
            val req = FlowLog.requests.firstOrNull()
            if (req == null) Muted("Nenhum pedido ainda.")
            else {
                Text("“${req.question}”", color = NexoColors.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                FlowLog.eventsOf(req.id).takeLast(6).forEach { FlowEventLine(it) }
            }
        }
        Spacer(Modifier.height(8.dp))
        HoloTile("ACTIONS", tilt, Modifier.fillMaxWidth().padding(horizontal = 10.dp), accent = HoloOrange, depth = 0.8f, onClick = {
            projector.project(Projection("Registro de ações", HoloOrange) { ActionsPanel() })
        }) {
            val recent = ActionLog.entries.take(4)
            if (recent.isEmpty()) Muted("Nenhuma ação ainda.")
            recent.forEach { e ->
                Row {
                    Text(if (e.ok) "OK  " else "FALHA  ", color = if (e.ok) NexoColors.green else NexoColors.red, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("${e.tool} · ${e.time.takeLast(8)}", color = NexoColors.text, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HoloTile("DIAGNOSTIC", tilt, Modifier.weight(1f), accent = HoloCyan, onClick = {
                projector.project(Projection("Diagnóstico", HoloCyan) { Single { DiagnosticsCard() } })
            }) { Text("🩺", fontSize = 20.sp); Muted("testar tudo") }
            HoloTile("BACKUP", tilt, Modifier.weight(1f), accent = HoloBlue, onClick = {
                projector.project(Projection("Backup", HoloBlue) { Single { BackupCard() } })
            }) { Text("🛡️", fontSize = 20.sp); Muted("proteger dados") }
            HoloTile("SYSTEM", tilt, Modifier.weight(1f), accent = HoloOrange, onClick = {
                projector.project(Projection("Sistema", HoloOrange) { SystemScreen() })
            }) { Text("⚙️", fontSize = 20.sp); Muted("24/7, MCP") }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun Single(content: @Composable () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(12.dp)) { item { content() } }
}

@Composable
private fun ActionsPanel() {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (ActionLog.entries.isEmpty()) item { Muted("Nenhuma ação ainda.") }
        items(ActionLog.entries) { e ->
            GlassCard {
                Row {
                    Text(if (e.ok) "OK " else "FALHA ", color = if (e.ok) NexoColors.green else NexoColors.red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${e.tool} · ${e.time}", color = NexoColors.text, fontSize = 12.sp)
                }
                Muted(e.output)
            }
        }
    }
}
