package com.jeconias.nexo.providers

import org.json.JSONObject

/** Formato interno único. Cada provedor traduz de/para o formato da sua API. */
data class ToolCall(val id: String, val name: String, val argumentsJson: String)

data class ChatMessage(
    val role: String, // system | user | assistant | tool
    val content: String = "",
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
)

data class ToolSpec(val name: String, val description: String, val parameters: JSONObject)

data class LlmResponse(
    val text: String,
    val toolCalls: List<ToolCall>,
    val providerName: String = "",
    val model: String = "",
)

class ProviderException(message: String) : Exception(message)

interface LlmProvider {
    val info: ProviderInfo
    suspend fun chat(messages: List<ChatMessage>, tools: List<ToolSpec>): LlmResponse
}
