package com.jeconias.nexo.tools.builtin

import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder

private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

private fun stripHtml(html: String): String = html
    .replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
    .replace(Regex("(?s)<[^>]+>"), " ")
    .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'")
    .replace("&lt;", "<").replace("&gt;", ">")
    .replace(Regex("[ \\t]+"), " ")
    .replace(Regex("\\s*\\n\\s*"), "\n")
    .trim()

/**
 * PESQUISA GOOGLE pelo Gemini (pesquisa no Google e responde com as fontes).
 * Se não houver chave do Gemini, ou a cota de pesquisa acabar, usa o DuckDuckGo.
 */
object GoogleSearch {
    data class Result(val answer: String, val sources: List<Pair<String, String>>)

    suspend fun search(http: OkHttpClient, query: String): Result? = withContext(Dispatchers.IO) {
        val settings = com.jeconias.nexo.core.Container.settings
        val key = settings.apiKey("gemini")
        if (key.isBlank()) return@withContext null
        val prompt = "Pesquise no Google e responda em português do Brasil, com fatos, números e datas atuais: $query"
        val body = JSONObject()
            .put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt)))))
            .put("tools", org.json.JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${settings.model("gemini")}:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        runCatching {
            http.newCall(req).execute().use { r -> if (r.isSuccessful) parse(r.body?.string().orEmpty()) else null }
        }.getOrNull()
    }

    /** Lê a resposta do Gemini: texto + fontes do Google. Pura, testada automaticamente. */
    fun parse(json: String): Result? {
        val cand = runCatching { JSONObject(json).getJSONArray("candidates").getJSONObject(0) }.getOrNull() ?: return null
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: return null
        val text = (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }.trim()
        val chunks = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        val sources = if (chunks == null) emptyList() else (0 until chunks.length()).mapNotNull {
            chunks.getJSONObject(it).optJSONObject("web")?.let { w -> w.optString("title") to w.optString("uri") }
        }
        // Sem fontes = o Gemini respondeu de cabeça, sem pesquisar: não serve como pesquisa.
        return if (text.isBlank() || sources.isEmpty()) null else Result(text, sources)
    }
}

class BuscarWebTool(private val http: OkHttpClient) : Tool {
    override val level = Level.READ
    override val name = "buscar_web"
    override val description =
        "Pesquisa na internet (Google; se indisponível, DuckDuckGo) e devolve a resposta com as fontes. Use para notícias, preços, horários e qualquer informação atual."
    override val parameters = schema(Param("consulta", "string", "O que pesquisar"))

    override suspend fun run(args: JSONObject): ToolResult = withContext(Dispatchers.IO) {
        val q = args.optString("consulta").trim()
        if (q.isBlank()) return@withContext ToolResult(false, "Consulta vazia.")
        val google = GoogleSearch.search(http, q)
        if (google != null) {
            com.jeconias.nexo.core.FlowLog.add("PESQUISA", "Google", q)
            val fontes = google.sources.distinctBy { it.second }.take(6).joinToString("\n") { "• ${it.first} — ${it.second}" }
            return@withContext ToolResult(true, "(via Google)\n${google.answer.take(3500)}\n\nFontes:\n$fontes")
        }
        com.jeconias.nexo.core.FlowLog.add("PESQUISA", "DuckDuckGo", q)
        val req = Request.Builder()
            .url("https://html.duckduckgo.com/html/?kl=br-pt&q=" + URLEncoder.encode(q, "UTF-8"))
            .header("User-Agent", UA)
            .build()
        val html = http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return@withContext ToolResult(false, "Busca falhou (HTTP ${r.code}).")
            r.body?.string().orEmpty()
        }
        val blocks = html.split("class=\"result__body").drop(1).take(6)
        val results = blocks.mapNotNull { b ->
            val link = Regex("class=\"result__a\" href=\"([^\"]+)\"").find(b)?.groupValues?.get(1) ?: return@mapNotNull null
            val title = Regex("class=\"result__a\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).find(b)?.groupValues?.get(1) ?: ""
            val snippet = Regex("class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).find(b)?.groupValues?.get(1) ?: ""
            val real = Regex("uddg=([^&]+)").find(link)?.groupValues?.get(1)?.let { URLDecoder.decode(it, "UTF-8") } ?: link
            "• ${stripHtml(title)}\n  $real\n  ${stripHtml(snippet)}"
        }
        if (results.isEmpty()) ToolResult(false, "Nenhum resultado (a busca pode ter sido bloqueada). Tente outra forma de pesquisar.")
        else ToolResult(true, "(via DuckDuckGo)\n" + results.joinToString("\n"))
    }
}

class LerPaginaTool(private val http: OkHttpClient) : Tool {
    override val level = Level.READ
    override val name = "ler_pagina"
    override val description = "Abre um link e devolve o texto da página, para ler os detalhes de um resultado da busca."
    override val parameters = schema(Param("url", "string", "Endereço completo"))

    override suspend fun run(args: JSONObject): ToolResult = withContext(Dispatchers.IO) {
        val url = args.optString("url").trim()
        if (!url.startsWith("http")) return@withContext ToolResult(false, "Link inválido.")
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return@withContext ToolResult(false, "Página respondeu HTTP ${r.code}.")
            val text = stripHtml(r.body?.string().orEmpty())
            ToolResult(text.isNotBlank(), text.take(6000).ifBlank { "Página sem texto legível." })
        }
    }
}
