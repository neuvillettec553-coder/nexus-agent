package com.jeconias.nexo.ui.holo

import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

val HoloBlue = Color(0xFF38C8FF)
val HoloCyan = Color(0xFF6FF3FF)
val HoloOrange = Color(0xFFFF7A2F)
val LabDeep = Color(0xFF02060F)

/**
 * Cenário: laboratório escuro com fitas de LED no teto, monitores desfocados ao fundo
 * e bancadas de vidro com painéis azuis. Por cima, as ondas de comunicação azul/laranja.
 */
@Composable
fun LabBackground(modifier: Modifier = Modifier) {
    Box(modifier) {
        val blurOk = Build.VERSION.SDK_INT >= 31
        Canvas(Modifier.fillMaxSize().then(if (blurOk) Modifier.blur(10.dp) else Modifier)) { drawLab() }
        CommunicationWaves(Modifier.fillMaxSize())
    }
}

private fun DrawScope.drawLab() {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF071226), LabDeep, Color(0xFF040A18))))
    // fitas de LED no teto, em perspectiva
    for (i in 0 until 4) {
        val y = h * (0.03f + i * 0.035f)
        val inset = w * (0.08f + i * 0.08f)
        drawLine(HoloCyan.copy(alpha = 0.10f), Offset(inset, y), Offset(w - inset, y), 10.dp.toPx(), StrokeCap.Round)
        drawLine(Color.White.copy(alpha = 0.35f - i * 0.06f), Offset(inset, y), Offset(w - inset, y), 2.dp.toPx(), StrokeCap.Round)
    }
    // monitores desfocados ao fundo
    val monitors = listOf(Offset(0.04f, 0.22f) to Size(0.30f, 0.16f), Offset(0.70f, 0.18f) to Size(0.28f, 0.14f), Offset(0.40f, 0.12f) to Size(0.18f, 0.08f))
    monitors.forEach { (o, s) ->
        val tl = Offset(o.x * w, o.y * h)
        val sz = Size(s.width * w, s.height * h)
        drawRoundRect(Brush.linearGradient(listOf(HoloBlue.copy(alpha = 0.30f), Color(0xFF0A2A55).copy(alpha = 0.25f)), tl, Offset(tl.x + sz.width, tl.y + sz.height)), tl, sz, CornerRadius(12f))
        drawRoundRect(HoloCyan.copy(alpha = 0.25f), tl, sz, CornerRadius(12f), style = Stroke(2f))
    }
    // bancada de vidro reflexivo com painéis de toque
    val benchTop = h * 0.74f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0B2448).copy(alpha = 0.55f), Color(0xFF030814)), startY = benchTop, endY = h), Offset(0f, benchTop), Size(w, h - benchTop))
    drawLine(HoloCyan.copy(alpha = 0.45f), Offset(0f, benchTop), Offset(w, benchTop), 2.dp.toPx())
    for (i in 0 until 3) {
        val x = w * (0.08f + i * 0.32f)
        drawRoundRect(HoloBlue.copy(alpha = 0.22f), Offset(x, benchTop + h * 0.04f), Size(w * 0.22f, h * 0.05f), CornerRadius(10f))
    }
}

/** Filamentos de luz ondulados cruzando a tela, do ciano ao laranja, com brilho difuso. */
@Composable
fun CommunicationWaves(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "ondas")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "fase")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val brush = Brush.horizontalGradient(listOf(HoloCyan, HoloBlue, HoloOrange, HoloBlue, HoloCyan))
        val bundles = listOf(0.30f to 1f, 0.58f to -1f, 0.86f to 1f)
        bundles.forEachIndexed { b, (yRel, dir) ->
            for (k in 0 until 7) {
                val path = Path()
                val amp = h * (0.035f + k * 0.006f)
                val freq = 1.6f + b * 0.3f
                val shift = phase * dir + k * 0.35f + b
                var x = 0f
                path.moveTo(0f, yRel * h + sin(shift) * amp)
                while (x <= w) {
                    val y = yRel * h + sin(x / w * freq * 2 * PI.toFloat() + shift) * amp * (0.6f + 0.4f * sin(x / w * PI.toFloat()))
                    path.lineTo(x, y)
                    x += w / 60f
                }
                val alpha = 0.10f + 0.05f * (k % 3)
                drawPath(path, brush, alpha = alpha * 0.5f, style = Stroke(6.dp.toPx())) // brilho (bloom)
                drawPath(path, brush, alpha = alpha + 0.12f, style = Stroke(1.dp.toPx()))
            }
        }
    }
}
