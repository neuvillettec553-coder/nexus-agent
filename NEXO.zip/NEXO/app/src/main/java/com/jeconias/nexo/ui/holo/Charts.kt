package com.jeconias.nexo.ui.holo

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Metrics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Anel circular de integração do sistema ("85%"), com o valor REAL calculado. */
@Composable
fun IntegrationRing(percent: Int, modifier: Modifier = Modifier) {
    val animated by animateFloatAsState(percent / 100f, tween(900), label = "integracao")
    val spin = rememberInfiniteTransition(label = "giro")
    val a by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "a")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val px = 1.dp.toPx()
            val r = size.minDimension / 2f * 0.82f
            val tl = Offset(center.x - r, center.y - r)
            val sz = Size(r * 2, r * 2)
            drawCircle(Brush.radialGradient(listOf(HoloOrange.copy(alpha = 0.25f), Color.Transparent), center, r * 1.3f), r * 1.3f, center)
            drawCircle(HoloBlue.copy(alpha = 0.25f), r, center, style = Stroke(6 * px))
            drawArc(HoloOrange.copy(alpha = 0.35f), -90f, 360f * animated, false, tl, sz, style = Stroke(12 * px, cap = StrokeCap.Round))
            drawArc(HoloOrange, -90f, 360f * animated, false, tl, sz, style = Stroke(5 * px, cap = StrokeCap.Round))
            val r2 = r * 0.72f
            val p2 = Path().apply { addOval(androidx.compose.ui.geometry.Rect(center, r2)) }
            drawPath(p2, HoloBlue.copy(alpha = 0.6f), style = Stroke(1.5f * px, pathEffect = PathEffect.dashPathEffect(floatArrayOf(3 * px, 5 * px), a)))
        }
        Text("$percent%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

/**
 * PREDICTIVE MODELING: rede de nós ao vivo — Alfredo no centro, Motor Local, as IAs ativas e as Ações.
 * O nó que está trabalhando agora brilha.
 */
@Composable
fun ModelingGraph(nodes: List<String>, activeIndex: Int?, modifier: Modifier = Modifier) {
    val tm = rememberTextMeasurer()
    val pulse = rememberInfiniteTransition(label = "pulso")
    val p by pulse.animateFloat(0.4f, 1f, infiniteRepeatable(tween(700), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "p")
    Canvas(modifier) {
        val px = 1.dp.toPx()
        val c = center
        val r = size.minDimension / 2f * 0.70f
        val label = TextStyle(color = Color.White.copy(alpha = 0.85f), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        val positions = nodes.indices.map { i ->
            val a = (-90f + i * 360f / nodes.size.coerceAtLeast(1)) * PI.toFloat() / 180f
            c + Offset(cos(a), sin(a)) * r
        }
        // ligações (anel e raios)
        positions.forEachIndexed { i, pos ->
            drawLine(HoloBlue.copy(alpha = 0.35f), c, pos, px)
            val next = positions[(i + 1) % positions.size]
            drawLine(HoloOrange.copy(alpha = 0.30f), pos, next, px, pathEffect = PathEffect.dashPathEffect(floatArrayOf(3 * px, 4 * px)))
        }
        // centro
        drawCircle(Brush.radialGradient(listOf(HoloCyan.copy(alpha = 0.6f), Color.Transparent), c, 18 * px), 18 * px, c)
        drawCircle(HoloCyan, 6 * px, c)
        // nós
        positions.forEachIndexed { i, pos ->
            val active = i == activeIndex
            val col = if (active) HoloOrange else HoloBlue
            if (active) drawCircle(col.copy(alpha = 0.35f * p), 16 * px, pos)
            drawCircle(col, if (active) 6 * px else 4.5f * px, pos)
            val txt = tm.measure(nodes[i].take(10), label)
            val tx = (pos.x - txt.size.width / 2f).coerceIn(0f, size.width - txt.size.width)
            val ty = if (pos.y < c.y) pos.y - txt.size.height - 6 * px else pos.y + 8 * px
            drawText(txt, topLeft = Offset(tx, ty.coerceIn(0f, size.height - txt.size.height)))
        }
    }
}

/**
 * AI BEHAVIORAL EVOLUTION: duas ondas entrelaçadas com profundidade —
 * azul = Adaptação (aprendizado), laranja = Autonomia (Motor Local) — e os pontos de cada dia.
 */
@Composable
fun EvolutionChart(points: List<Metrics.Point>, modifier: Modifier = Modifier, compact: Boolean = false) {
    val tm = rememberTextMeasurer()
    val flow = rememberInfiniteTransition(label = "fluxo")
    val ph by flow.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "ph")
    Canvas(modifier) {
        val px = 1.dp.toPx()
        val left = if (compact) 4 * px else 28 * px
        val bottom = size.height - if (compact) 4 * px else 18 * px
        val top = if (compact) 4 * px else 10 * px
        val w = size.width - left - 4 * px
        val h = bottom - top
        val small = TextStyle(color = Color.White.copy(alpha = 0.55f), fontSize = 8.sp, fontFamily = FontFamily.Monospace)

        // grade
        for (i in 0..4) {
            val y = top + h * i / 4f
            drawLine(HoloBlue.copy(alpha = 0.12f), Offset(left, y), Offset(left + w, y), px)
            if (!compact) drawText(tm.measure("${100 - i * 25}", small), topLeft = Offset(2 * px, y - 6 * px))
        }
        for (i in 0..6) {
            val x = left + w * i / 6f
            drawLine(HoloBlue.copy(alpha = 0.08f), Offset(x, top), Offset(x, bottom), px)
        }

        // série: usa os dados reais; com poucos dias, completa com a linha do valor atual
        val data = if (points.size >= 2) points else List(2) { points.firstOrNull() ?: Metrics.Point("", 0, 0) }
        fun series(value: (Metrics.Point) -> Int, wave: Float): List<Offset> {
            val n = 48
            return (0..n).map { k ->
                val t = k / n.toFloat()
                val pos = t * (data.size - 1)
                val i = pos.toInt().coerceAtMost(data.size - 2)
                val f = pos - i
                val v = value(data[i]) * (1 - f) + value(data[i + 1]) * f
                // leve ondulação viva (amplitude pequena para não distorcer o valor real)
                val y = bottom - h * (v / 100f) + sin(t * 9f + ph + wave) * h * 0.04f
                Offset(left + w * t, y.coerceIn(top, bottom))
            }
        }
        fun drawRibbon(pts: List<Offset>, color: Color) {
            for (layer in 5 downTo 0) {
                val path = Path()
                pts.forEachIndexed { i, o ->
                    val q = Offset(o.x + layer * 2.2f * px, o.y - layer * 1.6f * px) // profundidade 3D
                    if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y)
                }
                val alpha = if (layer == 0) 1f else 0.10f + 0.04f * (5 - layer)
                drawPath(path, color.copy(alpha = alpha), style = Stroke(if (layer == 0) 2 * px else 1 * px))
            }
            drawPath(Path().apply { pts.forEachIndexed { i, o -> if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y) } },
                color.copy(alpha = 0.25f), style = Stroke(8 * px))
        }
        val blue = series({ it.adaptation }, 0f)
        val orange = series({ it.autonomy }, 2.2f)
        drawRibbon(blue, HoloBlue)
        drawRibbon(orange, HoloOrange)
        // pontos dispersos (um por dia real)
        data.forEachIndexed { i, pt ->
            val x = left + w * (if (data.size == 1) 0f else i / (data.size - 1f))
            drawCircle(HoloCyan, 2.5f * px, Offset(x, bottom - h * pt.adaptation / 100f))
            drawCircle(HoloOrange, 2.5f * px, Offset(x, bottom - h * pt.autonomy / 100f))
        }
        if (!compact && points.isNotEmpty()) {
            drawText(tm.measure(points.first().date, small), topLeft = Offset(left, bottom + 3 * px))
            val lastLabel = tm.measure(points.last().date, small)
            drawText(lastLabel, topLeft = Offset(left + w - lastLabel.size.width, bottom + 3 * px))
        }
    }
}
