package com.jeconias.nexo.life

import com.jeconias.nexo.core.Container
import com.jeconias.nexo.live.LiveData
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolRegistry
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import org.json.JSONArray
import org.json.JSONObject

/** Ferramentas da Central Financeira e dos módulos de vida, para o Alfredo usar por voz. */
object LifeTools {
    fun registerAll(r: ToolRegistry, store: LifeStore, ctx: android.content.Context) {
        r.register(AgendaListar(ctx))
        r.register(AgendaCriar(ctx))
        listOf(
            FinRegistrar(store), FinResumo(store), FinConta(store), FinPagarConta(store), FinDivida(store),
            FinLimite(store), FinMeta(store), TarefaCriar(store), TarefaListar(store), TarefaConcluir(store),
            HabitoCriar(store), HabitoMarcar(store), MetaVidaCriar(store), MetaPasso(store), DiarioRegistrar(store),
            VidaResumo(store), ClimaAgora(),
        ).forEach { r.register(it) }
    }
}

private fun money(v: Double) = FinanceMath.money(v)

class FinRegistrar(private val s: LifeStore) : Tool {
    override val name = "fin_registrar"
    override val description = "Registra um gasto ou uma entrada de dinheiro. Ex.: 'gastei 45 no mercado' → tipo gasto, valor 45, categoria mercado. Renda extra: tipo entrada, categoria 'renda extra'."
    override val parameters = schema(
        Param("tipo", "string", "'gasto' ou 'entrada'"),
        Param("valor", "number", "Valor em reais"),
        Param("categoria", "string", "mercado, contas, transporte, lazer, saúde, salário, renda extra, outros…"),
        Param("descricao", "string", "Detalhe curto", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val valor = args.optDouble("valor", -1.0)
        if (valor <= 0) return ToolResult(false, "Valor inválido.")
        val tipo = if (args.optString("tipo").startsWith("e")) "entrada" else "gasto"
        s.add(LifeStore.TX, JSONObject().put("tipo", tipo).put("valor", valor)
            .put("categoria", args.optString("categoria").lowercase().ifBlank { "outros" })
            .put("descricao", args.optString("descricao")).put("data", LifeStore.today()))
        val sum = s.monthSummary()
        val alerta = s.list(LifeStore.BUDGETS).firstOrNull { it.optString("categoria").equals(args.optString("categoria"), true) }?.let { b ->
            val spent = sum.byCategory.firstOrNull { it.first.equals(b.optString("categoria"), true) }?.second ?: 0.0
            val use = FinanceMath.budgetUse(spent, b.optDouble("limite"))
            if (use >= 80) " ATENÇÃO: ${use}% do limite de ${b.optString("categoria")}." else ""
        } ?: ""
        return ToolResult(true, "Registrado: $tipo de ${money(valor)}. Saldo do mês: ${money(sum.balance)}.$alerta")
    }
}

class FinResumo(private val s: LifeStore) : Tool {
    override val name = "fin_resumo"
    override val level = Level.READ
    override val description = "Situação financeira completa: saldo do mês, gastos por categoria, limites, contas a pagar, dívidas, metas e previsão do fim do mês."
    override val parameters = schema()
    override suspend fun run(args: JSONObject) = ToolResult(true, s.financeReport())
}

class FinConta(private val s: LifeStore) : Tool {
    override val name = "fin_conta"
    override val description = "Cadastra uma conta fixa mensal (luz, água, aluguel, internet) com dia de vencimento. O Alfredo avisa 1 dia antes."
    override val parameters = schema(
        Param("nome", "string", "Nome da conta"),
        Param("valor", "number", "Valor aproximado"),
        Param("dia", "integer", "Dia do vencimento (1 a 31)"),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val dia = args.optInt("dia", 0)
        if (dia !in 1..31) return ToolResult(false, "Dia inválido.")
        s.add(LifeStore.BILLS, JSONObject().put("nome", args.optString("nome")).put("valor", args.optDouble("valor", 0.0)).put("dia", dia).put("pagas", ""))
        return ToolResult(true, "Conta ${args.optString("nome")} cadastrada, vence todo dia $dia. Vou avisar um dia antes.")
    }
}

class FinPagarConta(private val s: LifeStore) : Tool {
    override val name = "fin_pagar_conta"
    override val description = "Marca uma conta como paga neste mês e registra o gasto."
    override val parameters = schema(Param("nome", "string", "Nome da conta"))
    override suspend fun run(args: JSONObject): ToolResult {
        val b = s.find(LifeStore.BILLS, args.optString("nome"), "nome") ?: return ToolResult(false, "Conta não encontrada.")
        val month = FinanceMath.currentMonth()
        s.update(LifeStore.BILLS, b.optString("id")) { it.put("pagas", (it.optString("pagas") + ",$month").trim(',')) }
        s.add(LifeStore.TX, JSONObject().put("tipo", "gasto").put("valor", b.optDouble("valor")).put("categoria", "contas")
            .put("descricao", b.optString("nome")).put("data", LifeStore.today()))
        return ToolResult(true, "${b.optString("nome")} marcada como paga (${money(b.optDouble("valor"))}).")
    }
}

class FinDivida(private val s: LifeStore) : Tool {
    override val name = "fin_divida"
    override val description = "Registra uma dívida (cartão, empréstimo, loja) com valor total, parcela e juros ao mês, para o Alfredo montar a melhor ordem de quitação."
    override val parameters = schema(
        Param("credor", "string", "Com quem é a dívida"),
        Param("total", "number", "Valor total devido"),
        Param("parcela", "number", "Quanto paga por mês", required = false),
        Param("juros", "number", "Juros ao mês em % (ex.: 12 no cartão)", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        s.add(LifeStore.DEBTS, JSONObject().put("credor", args.optString("credor")).put("total", args.optDouble("total", 0.0))
            .put("parcela", args.optDouble("parcela", 0.0)).put("juros", args.optDouble("juros", 0.0)))
        val months = FinanceMath.monthsToPay(args.optDouble("total", 0.0), args.optDouble("parcela", 0.0), args.optDouble("juros", 0.0))
        val prazo = when {
            args.optDouble("parcela", 0.0) <= 0 -> ""
            months == null -> " ALERTA: essa parcela não cobre nem os juros; a dívida só cresce."
            else -> " Pagando ${money(args.optDouble("parcela"))} por mês, quita em cerca de $months meses."
        }
        return ToolResult(true, "Dívida com ${args.optString("credor")} registrada.$prazo")
    }
}

class FinLimite(private val s: LifeStore) : Tool {
    override val name = "fin_limite"
    override val description = "Define um limite mensal de gasto para uma categoria. O Alfredo avisa ao chegar em 80%."
    override val parameters = schema(Param("categoria", "string", "Categoria"), Param("limite", "number", "Valor máximo por mês"))
    override suspend fun run(args: JSONObject): ToolResult {
        val cat = args.optString("categoria").lowercase()
        s.save(LifeStore.BUDGETS, s.list(LifeStore.BUDGETS).filter { it.optString("categoria") != cat } +
            JSONObject().put("id", cat).put("categoria", cat).put("limite", args.optDouble("limite", 0.0)))
        return ToolResult(true, "Limite de $cat: ${money(args.optDouble("limite", 0.0))} por mês.")
    }
}

class FinMeta(private val s: LifeStore) : Tool {
    override val name = "fin_meta"
    override val description = "Cria uma meta de economia ou adiciona dinheiro guardado a uma meta existente."
    override val parameters = schema(
        Param("titulo", "string", "Nome da meta"),
        Param("alvo", "number", "Valor a juntar (só ao criar)", required = false),
        Param("guardar", "number", "Valor guardado agora (para somar)", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val existing = s.find(LifeStore.GOALS, args.optString("titulo"))
        return if (existing == null) {
            s.add(LifeStore.GOALS, JSONObject().put("titulo", args.optString("titulo")).put("alvo", args.optDouble("alvo", 0.0)).put("guardado", args.optDouble("guardar", 0.0)))
            ToolResult(true, "Meta ${args.optString("titulo")} criada: juntar ${money(args.optDouble("alvo", 0.0))}.")
        } else {
            s.update(LifeStore.GOALS, existing.optString("id")) { it.put("guardado", it.optDouble("guardado") + args.optDouble("guardar", 0.0)) }
            val g = s.find(LifeStore.GOALS, existing.optString("id"))!!
            ToolResult(true, "Meta ${g.optString("titulo")}: ${money(g.optDouble("guardado"))} de ${money(g.optDouble("alvo"))}.")
        }
    }
}

class TarefaCriar(private val s: LifeStore) : Tool {
    override val name = "tarefa_criar"
    override val description = "Cria uma tarefa (afazer) com prazo opcional (AAAA-MM-DD) e prioridade 1 (baixa) a 3 (alta)."
    override val parameters = schema(
        Param("titulo", "string", "O que fazer"),
        Param("prazo", "string", "Data limite AAAA-MM-DD", required = false),
        Param("prioridade", "integer", "1, 2 ou 3", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        s.add(LifeStore.TASKS, JSONObject().put("titulo", args.optString("titulo")).put("prazo", args.optString("prazo"))
            .put("prioridade", args.optInt("prioridade", 2).coerceIn(1, 3)).put("feita", false))
        return ToolResult(true, "Tarefa criada: ${args.optString("titulo")}.")
    }
}

class TarefaListar(private val s: LifeStore) : Tool {
    override val name = "tarefa_listar"
    override val level = Level.READ
    override val description = "Lista as tarefas abertas, as mais urgentes e importantes primeiro."
    override val parameters = schema()
    override suspend fun run(args: JSONObject): ToolResult {
        val t = s.openTasks()
        return ToolResult(true, if (t.isEmpty()) "Nenhuma tarefa aberta." else t.joinToString("\n") {
            "• ${it.optString("titulo")} [prioridade ${it.optInt("prioridade", 2)}]" + it.optString("prazo").let { p -> if (p.isNotBlank()) " até $p" else "" }
        })
    }
}

class TarefaConcluir(private val s: LifeStore) : Tool {
    override val name = "tarefa_concluir"
    override val description = "Marca uma tarefa como feita (pelo nome ou parte dele)."
    override val parameters = schema(Param("titulo", "string", "Nome da tarefa"))
    override suspend fun run(args: JSONObject): ToolResult {
        val t = s.find(LifeStore.TASKS, args.optString("titulo")) ?: return ToolResult(false, "Tarefa não encontrada.")
        s.update(LifeStore.TASKS, t.optString("id")) { it.put("feita", true).put("feita_em", LifeStore.today()) }
        return ToolResult(true, "Feito: ${t.optString("titulo")}.")
    }
}

class HabitoCriar(private val s: LifeStore) : Tool {
    override val name = "habito_criar"
    override val description = "Cria um hábito diário para acompanhar (ex.: beber água, ler 10 páginas)."
    override val parameters = schema(Param("nome", "string", "Nome do hábito"))
    override suspend fun run(args: JSONObject): ToolResult {
        s.add(LifeStore.HABITS, JSONObject().put("nome", args.optString("nome")).put("dias", ""))
        return ToolResult(true, "Hábito criado: ${args.optString("nome")}.")
    }
}

class HabitoMarcar(private val s: LifeStore) : Tool {
    override val name = "habito_marcar"
    override val description = "Marca um hábito como feito hoje e informa a sequência de dias."
    override val parameters = schema(Param("nome", "string", "Nome do hábito"))
    override suspend fun run(args: JSONObject): ToolResult {
        val h = s.find(LifeStore.HABITS, args.optString("nome"), "nome") ?: return ToolResult(false, "Hábito não encontrado.")
        val today = LifeStore.today()
        s.update(LifeStore.HABITS, h.optString("id")) { if (!it.optString("dias").contains(today)) it.put("dias", (it.optString("dias") + ",$today").trim(',')) }
        val updated = s.find(LifeStore.HABITS, h.optString("id"), "nome")!!
        return ToolResult(true, "${h.optString("nome")} feito hoje. Sequência: ${s.habitStreak(updated)} dia(s).")
    }
}

class MetaVidaCriar(private val s: LifeStore) : Tool {
    override val name = "meta_vida_criar"
    override val description = "Cria uma meta de desenvolvimento pessoal dividida em passos práticos."
    override val parameters = schema(
        Param("titulo", "string", "A meta"),
        Param("prazo", "string", "curto, medio ou longo", required = false),
        Param("passos", "string", "Passos separados por ';'"),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val steps = JSONArray()
        args.optString("passos").split(";").map { it.trim() }.filter { it.isNotBlank() }
            .forEach { steps.put(JSONObject().put("texto", it).put("feito", false)) }
        s.add(LifeStore.LIFE_GOALS, JSONObject().put("titulo", args.optString("titulo")).put("prazo", args.optString("prazo", "medio")).put("passos", steps))
        return ToolResult(true, "Meta criada com ${steps.length()} passos: ${args.optString("titulo")}.")
    }
}

class MetaPasso(private val s: LifeStore) : Tool {
    override val name = "meta_vida_passo"
    override val description = "Marca como feito um passo de uma meta de desenvolvimento pessoal."
    override val parameters = schema(Param("meta", "string", "Nome da meta"), Param("passo", "string", "Texto ou número do passo"))
    override suspend fun run(args: JSONObject): ToolResult {
        val g = s.find(LifeStore.LIFE_GOALS, args.optString("meta")) ?: return ToolResult(false, "Meta não encontrada.")
        var marked = ""
        s.update(LifeStore.LIFE_GOALS, g.optString("id")) { obj ->
            val steps = obj.optJSONArray("passos") ?: JSONArray()
            val q = args.optString("passo").lowercase()
            for (i in 0 until steps.length()) {
                val st = steps.getJSONObject(i)
                if (q == "${i + 1}" || st.optString("texto").lowercase().contains(q)) { st.put("feito", true); marked = st.optString("texto"); break }
            }
        }
        return if (marked.isBlank()) ToolResult(false, "Passo não encontrado.") else ToolResult(true, "Passo concluído: $marked.")
    }
}

class DiarioRegistrar(private val s: LifeStore) : Tool {
    override val name = "diario_registrar"
    override val description = "Registra no diário de reflexão o que o usuário contar sobre o dia (conquistas, dificuldades, aprendizados)."
    override val parameters = schema(Param("texto", "string", "O registro"))
    override suspend fun run(args: JSONObject): ToolResult {
        s.add(LifeStore.JOURNAL, JSONObject().put("texto", args.optString("texto")).put("data", LifeStore.today()))
        return ToolResult(true, "Registrado no diário.")
    }
}

class VidaResumo(private val s: LifeStore) : Tool {
    override val name = "vida_resumo"
    override val level = Level.READ
    override val description = "Resumo de tarefas abertas, hábitos (com sequência) e metas de desenvolvimento pessoal."
    override val parameters = schema()
    override suspend fun run(args: JSONObject) = ToolResult(true, s.lifeReport())
}

class ClimaAgora : Tool {
    override val name = "clima_agora"
    override val level = Level.READ
    override val description = "Clima atual e máxima/mínima do dia na cidade do usuário."
    override val parameters = schema()
    override suspend fun run(args: JSONObject): ToolResult {
        val city = Container.settings.city()
        if (city.isBlank()) return ToolResult(false, "Cidade não definida. Peça ao usuário para tocar em WEATHER no PREDICT.")
        val w = LiveData.weather(Container.http, city) ?: return ToolResult(false, "Não consegui o clima agora.")
        return ToolResult(true, "${w.city}: ${w.temp}°, ${w.desc}; mínima ${w.min}°, máxima ${w.max}°.")
    }
}
