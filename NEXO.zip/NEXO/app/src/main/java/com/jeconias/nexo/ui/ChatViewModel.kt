package com.jeconias.nexo.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jeconias.nexo.agent.AgentEvent
import com.jeconias.nexo.agent.Confirmer
import com.jeconias.nexo.agent.LocalEngine
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.providers.ChatMessage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class UiMessage(val fromUser: Boolean, val text: String, val meta: String = "", val error: Boolean = false)

/** Estado do agente, usado pelo núcleo holográfico para mudar cor e ritmo. */
enum class Phase(val label: String) {
    IDLE("EM ESPERA"),
    LISTENING("ESCUTANDO"),
    THINKING("PENSANDO"),
    ACTING("EXECUTANDO"),
    SPEAKING("FALANDO"),
}

class ChatViewModel : ViewModel() {
    val messages = mutableStateListOf<UiMessage>()
    var busy by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    var phase by mutableStateOf(Phase.IDLE)
        private set
    var lastSource by mutableStateOf("")
        private set

    /** Texto da confirmação pendente (null = nenhuma). A tela mostra um diálogo Sim/Não. */
    var pendingConfirm by mutableStateOf<String?>(null)
        private set
    private var confirmAnswer: CompletableDeferred<Boolean>? = null

    private val history = mutableListOf<ChatMessage>()
    private val brain = Container.newOrchestrator()
    private var speechJob: Job? = null
    private var lastLocalPhrase: String? = null
    private var currentJob: Job? = null

    /** Quando o pedido atual começou (0 = nenhum). A tela mostra o tempo correndo. */
    var startedAt by mutableStateOf(0L)
        private set

    /** Qual IA está trabalhando agora. */
    val currentProvider: String get() = Container.router.currentProvider

    /** Cancela o pedido em andamento. */
    fun stop() {
        currentJob?.cancel()
        stopSpeaking()
    }

    init {
        viewModelScope.launch { runCatching { Container.mcp.connectAll() } }
    }

    fun setListening(on: Boolean) {
        if (busy) return
        phase = if (on) Phase.LISTENING else Phase.IDLE
    }

    private suspend fun askConfirm(text: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        confirmAnswer = d
        pendingConfirm = text
        val answer = withTimeoutOrNull(120_000) { d.await() } ?: false
        pendingConfirm = null
        confirmAnswer = null
        return answer
    }

    private val confirmer: Confirmer = { text -> askConfirm(text) }

    fun answerConfirm(yes: Boolean) {
        confirmAnswer?.complete(yes)
    }

    private fun onEvent(ev: AgentEvent) {
        when (ev) {
            is AgentEvent.Thinking -> {
                phase = Phase.THINKING
                status = if (ev.step == 1) "Pensando…" else "Avaliando o próximo passo…"
            }
            is AgentEvent.Acting -> {
                phase = Phase.ACTING
                status = "Executando: ${ev.tool}"
            }
            is AgentEvent.ActionDone -> {
                status = if (ev.ok) "✓ ${ev.tool} deu certo" else "✗ ${ev.tool} falhou, buscando outro caminho"
            }
            is AgentEvent.Council -> {
                phase = Phase.THINKING
                status = "Conselho: ${ev.stage}…"
            }
            AgentEvent.Local -> {
                phase = Phase.ACTING
                status = "Motor Local resolvendo…"
            }
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isBlank() || busy) return
        stopSpeaking()

        // "Para", "chega", "silêncio": só para de falar.
        if (LocalEngine.isStop(t)) {
            phase = Phase.IDLE
            return
        }

        messages.add(UiMessage(true, t))
        busy = true
        phase = Phase.THINKING
        val correctionOf = if (LocalEngine.isCorrection(t)) lastLocalPhrase else null
        startedAt = System.currentTimeMillis()
        currentJob = viewModelScope.launch {
            try {
                val outcome = if (correctionOf != null) {
                    brain.correct(history, correctionOf, { onEvent(it) }, confirmer)
                } else {
                    brain.handle(history, t, { onEvent(it) }, confirmer)
                }
                lastLocalPhrase = outcome.localPhrase
                lastSource = outcome.source
                messages.add(UiMessage(false, outcome.reply, outcome.source))
                if (Container.settings.speakReplies()) {
                    speechJob = viewModelScope.launch {
                        phase = Phase.SPEAKING
                        try {
                            Container.voice.speak(outcome.reply)
                        } finally {
                            if (phase == Phase.SPEAKING) phase = Phase.IDLE
                        }
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                messages.add(UiMessage(false, "⏹ Parado. Pode pedir de novo ou de outro jeito.", error = true))
            } catch (e: Exception) {
                com.jeconias.nexo.core.Metrics.record(com.jeconias.nexo.core.Metrics.Kind.FAIL)
                messages.add(UiMessage(false, e.message ?: "Erro desconhecido", error = true))
            } finally {
                startedAt = 0L
                busy = false
                status = ""
                if (phase != Phase.SPEAKING) phase = Phase.IDLE
            }
        }
    }

    fun stopSpeaking() {
        speechJob?.cancel()
        Container.voice.stop()
        if (phase == Phase.SPEAKING) phase = Phase.IDLE
    }

    fun newSession() {
        stopSpeaking()
        history.clear()
        messages.clear()
        lastLocalPhrase = null
    }
}
