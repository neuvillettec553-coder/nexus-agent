package com.jeconias.nexo.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import com.jeconias.nexo.core.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

interface VoiceEngine {
    val id: String
    val label: String
    val needs: String
    fun available(): Boolean
    /** true = falou de verdade. false = falhou (o gerente passa para a próxima voz). */
    suspend fun speak(text: String): Boolean
    fun stop() {}
}

private val JSON_TYPE = "application/json".toMediaType()

/** Voz do próprio celular. Sempre fica por último, como reserva. */
class SystemTts(ctx: Context) : VoiceEngine {
    override val id = "system"
    override val label = "Voz do celular"
    override val needs = "Nada (reserva final)"
    @Volatile private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    override fun available() = ready

    override suspend fun speak(text: String): Boolean {
        if (!ready) return false
        tts.setLanguage(Locale("pt", "BR"))
        return suspendCancellableCoroutine { cont ->
            val utterance = UUID.randomUUID().toString()
            val done = AtomicBoolean(false)
            fun finish(ok: Boolean) { if (done.compareAndSet(false, true)) cont.resume(ok) }
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (utteranceId == utterance) finish(true) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { if (utteranceId == utterance) finish(false) }
            })
            val r = tts.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, null, utterance)
            if (r != TextToSpeech.SUCCESS) finish(false)
            cont.invokeOnCancellation { tts.stop() }
        }
    }

    override fun stop() { tts.stop() }
}

/** Toca áudio PCM 16-bit mono (formato que o Gemini devolve). */
class PcmPlayer {
    @Volatile private var current: AudioTrack? = null

    suspend fun play(pcm: ByteArray, sampleRate: Int): Boolean = withContext(Dispatchers.IO) {
        val data = if (pcm.size % 2 == 0) pcm else pcm.copyOf(pcm.size - 1)
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minBuf * 4, 16384))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        current = track
        try {
            track.play()
            var offset = 0
            while (offset < data.size && isActive) {
                val n = track.write(data, offset, minOf(8192, data.size - offset))
                if (n <= 0) break
                offset += n
            }
            val totalFrames = data.size / 2
            var waited = 0
            while (isActive && track.playbackHeadPosition < totalFrames && waited < 120_000) {
                delay(50); waited += 50
            }
            true
        } catch (_: Exception) {
            false
        } finally {
            runCatching { track.stop() }
            track.release()
            current = null
        }
    }

    fun stop() { runCatching { current?.stop() } }
}

/** Voz natural do Gemini (mesma chave da IA Gemini, na aba IAs). */
class GeminiTts(
    private val settings: Settings,
    private val http: OkHttpClient,
    private val player: PcmPlayer,
) : VoiceEngine {
    override val id = "gemini"
    override val label = "Gemini (voz natural)"
    override val needs = "Chave do Gemini na aba IAs"
    override fun available() = settings.apiKey("gemini").isNotBlank()

    override suspend fun speak(text: String): Boolean {
        val key = settings.apiKey("gemini")
        if (key.isBlank()) return false
        val audio = withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text.take(1500))))))
                .put(
                    "generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig", JSONObject().put(
                                "voiceConfig", JSONObject().put(
                                    "prebuiltVoiceConfig", JSONObject().put("voiceName", settings.geminiVoiceName())
                                )
                            )
                        )
                )
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/${settings.geminiTtsModel()}:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody(JSON_TYPE))
                .build()
            try {
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use null
                    val json = JSONObject(r.body?.string().orEmpty())
                    val inline = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                        .getJSONObject("inlineData")
                    val rate = Regex("rate=(\\d+)").find(inline.optString("mimeType"))?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                    Base64.decode(inline.getString("data"), Base64.DEFAULT) to rate
                }
            } catch (_: Exception) {
                null
            }
        } ?: return false
        return player.play(audio.first, audio.second)
    }

    override fun stop() = player.stop()
}

/** ElevenLabs (chave própria, plano grátis tem limite mensal). */
class ElevenLabsTts(
    private val ctx: Context,
    private val settings: Settings,
    private val http: OkHttpClient,
) : VoiceEngine {
    override val id = "elevenlabs"
    override val label = "ElevenLabs"
    override val needs = "Chave da ElevenLabs (campo abaixo)"
    @Volatile private var player: MediaPlayer? = null

    override fun available() = settings.elevenKey().isNotBlank()

    override suspend fun speak(text: String): Boolean {
        if (!available()) return false
        val file = File(ctx.cacheDir, "fala.mp3")
        val ok = withContext(Dispatchers.IO) {
            val body = JSONObject().put("text", text.take(1500)).put("model_id", "eleven_multilingual_v2")
            val req = Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/${settings.elevenVoiceId()}?output_format=mp3_44100_128")
                .header("xi-api-key", settings.elevenKey())
                .header("Accept", "audio/mpeg")
                .post(body.toString().toRequestBody(JSON_TYPE))
                .build()
            try {
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use false
                    val bytes = r.body?.bytes() ?: return@use false
                    file.writeBytes(bytes)
                    bytes.isNotEmpty()
                }
            } catch (_: Exception) {
                false
            }
        }
        if (!ok) return false
        return withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val done = AtomicBoolean(false)
                fun finish(v: Boolean) { if (done.compareAndSet(false, true)) cont.resume(v) }
                try {
                    val mp = MediaPlayer()
                    player = mp
                    mp.setDataSource(file.absolutePath)
                    mp.setOnCompletionListener { it.release(); player = null; finish(true) }
                    mp.setOnErrorListener { p, _, _ -> p.release(); player = null; finish(false); true }
                    mp.prepare()
                    mp.start()
                    cont.invokeOnCancellation { runCatching { mp.stop(); mp.release() } }
                } catch (_: Exception) {
                    finish(false)
                }
            }
        }
    }

    override fun stop() { runCatching { player?.stop() } }
}
