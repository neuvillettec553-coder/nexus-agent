package com.jeconias.nexo.tools.builtin

import android.content.Context
import com.jeconias.nexo.context.ContextStore
import com.jeconias.nexo.context.SkillStore
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DataHoraTool : Tool {
    override val level = Level.READ
    override val name = "data_hora"
    override val description = "Retorna a data, o dia da semana e a hora atuais do celular."
    override val parameters = schema()
    override suspend fun run(args: JSONObject) = ToolResult(
        true, SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
    )
}

class LembrarTool(private val context: ContextStore) : Tool {
    override val name = "lembrar"
    override val description =
        "Grava no MEMORY.md algo que deve valer para sempre: preferência do usuário, correção de um erro seu, regra nova. Use uma frase curta e clara."
    override val parameters = schema(
        Param("fato", "string", "O que deve ser lembrado, em uma frase."),
        Param("assunto", "string", "Pessoas, Preferências, Lugares, Rotina, Finanças, Regras ou Outros", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val fato = args.optString("fato").trim()
        if (fato.isBlank()) return ToolResult(false, "Nada para gravar.")
        context.appendMemory(fato, args.optString("assunto", "Outros"))
        val ok = context.readMemory().contains(fato)
        return ToolResult(ok, if (ok) "Gravado no MEMORY.md: $fato" else "Falhou ao gravar.")
    }
}

private fun notesDir(ctx: Context) = File(ctx.filesDir, "notas").apply { mkdirs() }

class SalvarNotaTool(private val ctx: Context) : Tool {
    override val name = "salvar_nota"
    override val description = "Salva ou substitui uma nota (lista de compras, ideias, anotações). Para acrescentar, leia antes com listar_notas."
    override val parameters = schema(
        Param("titulo", "string", "Título curto da nota"),
        Param("conteudo", "string", "Texto completo da nota"),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val titulo = args.optString("titulo").trim().ifBlank { "nota" }
        val f = File(notesDir(ctx), titulo.replace(Regex("[^\\p{L}0-9 _-]"), "") + ".txt")
        f.writeText(args.optString("conteudo"))
        return ToolResult(f.exists(), "Nota '$titulo' salva.")
    }
}

class ListarNotasTool(private val ctx: Context) : Tool {
    override val level = Level.READ
    override val name = "listar_notas"
    override val description = "Lista as notas salvas com o conteúdo de cada uma."
    override val parameters = schema()
    override suspend fun run(args: JSONObject): ToolResult {
        val files = notesDir(ctx).listFiles()?.sortedBy { it.name } ?: emptyList()
        if (files.isEmpty()) return ToolResult(true, "Nenhuma nota salva.")
        return ToolResult(true, files.joinToString("\n\n") { "## ${it.nameWithoutExtension}\n${it.readText().take(1500)}" })
    }
}

class LerSkillTool(private val skills: SkillStore) : Tool {
    override val level = Level.READ
    override val name = "ler_skill"
    override val description = "Lê os passos de uma skill salva, para seguir o procedimento."
    override val parameters = schema(Param("nome", "string", "Nome da skill, como aparece na lista"))
    override suspend fun run(args: JSONObject): ToolResult {
        val s = skills.read(args.optString("nome"))
        return if (s == null) ToolResult(false, "Skill não encontrada. Disponíveis: ${skills.names().joinToString()}")
        else ToolResult(true, s)
    }
}

class SalvarSkillTool(private val skills: SkillStore) : Tool {
    override val name = "salvar_skill"
    override val description =
        "Salva um procedimento recorrente como skill, para repetir depois. Só use quando o usuário pedir para salvar ou confirmar."
    override val parameters = schema(
        Param("nome", "string", "Nome curto"),
        Param("conteudo", "string", "Markdown: primeira linha '# Nome — para que serve', depois os passos numerados"),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val slug = skills.save(args.optString("nome"), args.optString("conteudo"))
        return ToolResult(skills.read(slug) != null, "Skill '$slug' salva.")
    }
}

class AnotarTool(private val ctx: Context) : Tool {
    override val name = "anotar"
    override val description = "Acrescenta uma linha na nota 'Anotações' sem apagar o que já existe. Use para 'anota...'."
    override val parameters = schema(Param("texto", "string", "O que anotar"))
    override suspend fun run(args: JSONObject): ToolResult {
        val texto = args.optString("texto").trim()
        if (texto.isBlank()) return ToolResult(false, "Nada para anotar.")
        val f = File(notesDir(ctx), "Anotações.txt")
        val data = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date())
        f.appendText((if (f.exists() && f.length() > 0) "\n" else "") + "• $texto ($data)")
        return ToolResult(f.readText().contains(texto), "Anotado: $texto")
    }
}
