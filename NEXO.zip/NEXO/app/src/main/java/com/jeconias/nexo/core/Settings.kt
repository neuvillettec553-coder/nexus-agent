package com.jeconias.nexo.core

import android.content.Context
import com.jeconias.nexo.providers.ProviderCatalog

/** Configurações salvas no aparelho (chaves, ordem das IAs, voz, modo 24/7). */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_settings", Context.MODE_PRIVATE)

    // ---------- Provedores de IA ----------
    fun apiKey(id: String): String = prefs.getString("key_$id", "") ?: ""
    fun setApiKey(id: String, value: String) = prefs.edit().putString("key_$id", value.trim()).apply()

    fun model(id: String): String =
        prefs.getString("model_$id", null) ?: (ProviderCatalog.byId(id)?.defaultModel ?: "")
    fun setModel(id: String, value: String) = prefs.edit().putString("model_$id", value.trim()).apply()

    fun isEnabled(id: String): Boolean = prefs.getBoolean("enabled_$id", true)
    fun setEnabled(id: String, value: Boolean) = prefs.edit().putBoolean("enabled_$id", value).apply()

    /** Ordem de tentativa. A primeira IA com chave é usada; se falhar, passa para a próxima. */
    fun providerOrder(): List<String> {
        val saved = prefs.getString("provider_order", null)
            ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
        val all = ProviderCatalog.all.map { it.id }
        return saved.filter { it in all } + all.filter { it !in saved }
    }
    fun setProviderOrder(order: List<String>) =
        prefs.edit().putString("provider_order", order.joinToString(",")).apply()

    // ---------- Voz ----------
    fun activeVoice(): String = prefs.getString("voice_active", "system") ?: "system"
    fun setActiveVoice(id: String) = prefs.edit().putString("voice_active", id).apply()

    fun speakReplies(): Boolean = prefs.getBoolean("speak_replies", true)
    fun setSpeakReplies(v: Boolean) = prefs.edit().putBoolean("speak_replies", v).apply()

    fun geminiVoiceName(): String = prefs.getString("gemini_voice", "Charon") ?: "Charon"
    fun setGeminiVoiceName(v: String) = prefs.edit().putString("gemini_voice", v).apply()

    fun geminiTtsModel(): String =
        prefs.getString("gemini_tts_model", "gemini-2.5-flash-preview-tts") ?: "gemini-2.5-flash-preview-tts"
    fun setGeminiTtsModel(v: String) = prefs.edit().putString("gemini_tts_model", v.trim()).apply()

    fun elevenKey(): String = prefs.getString("eleven_key", "") ?: ""
    fun setElevenKey(v: String) = prefs.edit().putString("eleven_key", v.trim()).apply()

    fun elevenVoiceId(): String = prefs.getString("eleven_voice", "pNInz6obpgDQGcFmaJgB") ?: "pNInz6obpgDQGcFmaJgB"
    fun setElevenVoiceId(v: String) = prefs.edit().putString("eleven_voice", v.trim()).apply()

    // ---------- Agente ----------
    fun userName(): String = prefs.getString("user_name", "Mateus") ?: "Mateus"
    fun setUserName(v: String) = prefs.edit().putString("user_name", v.trim()).apply()

    fun city(): String = prefs.getString("city", "") ?: ""
    fun setCity(v: String) = prefs.edit().putString("city", v.trim()).apply()

    fun persistentMode(): Boolean = prefs.getBoolean("persistent", false)
    fun setPersistentMode(v: Boolean) = prefs.edit().putBoolean("persistent", v).apply()

    // ---------- Conselho e Motor Local ----------
    /** "auto" = complexos + quando pedir, "pedido" = só quando pedir, "off" = desligado */
    fun councilMode(): String = prefs.getString("council_mode", "auto") ?: "auto"
    fun setCouncilMode(v: String) = prefs.edit().putString("council_mode", v).apply()

    fun councilMaxPerDay(): Int = prefs.getInt("council_max", 20)
    fun setCouncilMaxPerDay(v: Int) = prefs.edit().putInt("council_max", v.coerceIn(1, 200)).apply()

    private fun today() = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    fun councilUsedToday(): Int =
        if (prefs.getString("council_day", "") == today()) prefs.getInt("council_count", 0) else 0
    fun addCouncilUse() {
        val n = councilUsedToday() + 1
        prefs.edit().putString("council_day", today()).putInt("council_count", n).apply()
    }

    fun localEngine(): Boolean = prefs.getBoolean("local_engine", true)
    fun setLocalEngine(v: Boolean) = prefs.edit().putBoolean("local_engine", v).apply()

    // ---------- Backup ----------
    fun backupPassword(): String = prefs.getString("backup_pass", "") ?: ""
    fun setBackupPassword(v: String) = prefs.edit().putString("backup_pass", v).apply()
    fun backupFolder(): String = prefs.getString("backup_folder", "") ?: ""
    fun setBackupFolder(v: String) = prefs.edit().putString("backup_folder", v).apply()
    fun lastBackup(): Long = prefs.getLong("backup_last", 0L)
    fun setLastBackup(v: Long) = prefs.edit().putLong("backup_last", v).apply()

    // ---------- MCP ----------
    fun mcpServersJson(): String = prefs.getString("mcp_servers", "[]") ?: "[]"
    fun setMcpServersJson(v: String) = prefs.edit().putString("mcp_servers", v).apply()
}
