package com.jeconias.nexo.scheduler

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.Notifications
import com.jeconias.nexo.providers.ChatMessage

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Notifications.show(applicationContext, "⏰ Lembrete", inputData.getString("msg") ?: "Lembrete")
        return Result.success()
    }
}

/** Executa uma rotina com o agente completo, sem tela, e avisa o resultado. */
class RoutineWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Container.init(applicationContext)
        val id = inputData.getString("id") ?: return Result.failure()
        val routine = Container.routines.get(id) ?: return Result.failure()
        return try {
            val history = mutableListOf<ChatMessage>()
            val reply = Container.newOrchestrator().handle(
                history,
                "[Rotina automática \"${routine.nome}\" — o usuário não está olhando a tela. " +
                    "Não abra apps. Faça a tarefa e responda com um resumo curto.]\n${routine.instrucao}",
                confirm = null,
                allowLocal = false,
            ).reply
            Notifications.show(applicationContext, "🤖 ${routine.nome}", reply.take(900))
            Result.success()
        } catch (e: Exception) {
            Notifications.show(applicationContext, "⚠️ Rotina ${routine.nome} falhou", e.message?.take(300) ?: "Erro")
            Result.success()
        }
    }
}
