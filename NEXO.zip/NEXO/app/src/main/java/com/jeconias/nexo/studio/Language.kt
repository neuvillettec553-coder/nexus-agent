package com.jeconias.nexo.studio

/** Linguagens que o Estúdio reconhece. [runnable] = roda dentro do celular, sem internet. */
enum class Language(val label: String, val runnable: Boolean, vararg val extensions: String) {
    PYTHON("Python", true, "py"),
    JAVASCRIPT("JavaScript", true, "js", "mjs"),
    LUA("Lua", true, "lua"),
    SQL("SQL", true, "sql"),
    SHELL("Shell", true, "sh"),
    HTML("HTML", true, "html", "htm"),
    CSS("CSS", true, "css"),
    TYPESCRIPT("TypeScript", false, "ts", "tsx"),
    KOTLIN("Kotlin", false, "kt", "kts"),
    JAVA("Java", false, "java"),
    C("C", false, "c", "h"),
    CPP("C++", false, "cpp", "cc", "hpp"),
    CSHARP("C#", false, "cs"),
    GO("Go", false, "go"),
    RUST("Rust", false, "rs"),
    PHP("PHP", false, "php"),
    JSON("JSON", false, "json"),
    MARKDOWN("Markdown", false, "md"),
    TEXT("Texto", false, "txt");

    companion object {
        fun of(fileName: String): Language {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            return entries.firstOrNull { ext in it.extensions } ?: TEXT
        }
    }
}
