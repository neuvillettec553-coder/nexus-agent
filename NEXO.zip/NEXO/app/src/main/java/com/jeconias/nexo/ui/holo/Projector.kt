package com.jeconias.nexo.ui.holo

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Um painel holográfico projetado: título, cor de destaque e o conteúdo. */
class Projection(val title: String, val accent: Color, val content: @Composable () -> Unit)

/** Controla qual painel está projetado agora (um por vez, como um holograma). */
class ProjectorState {
    var current by mutableStateOf<Projection?>(null)
        private set

    fun project(p: Projection) { current = p }
    fun close() { current = null }
}

val LocalProjector = staticCompositionLocalOf { ProjectorState() }

/**
 * Envolve a tela: o conteúdo normal embaixo e, por cima, o painel projetado,
 * que "abre" do centro com brilho, linhas de varredura e cantoneiras.
 */
@Composable
fun ProjectorHost(state: ProjectorState, content: @Composable () -> Unit) {
    // Guarda o último painel para a animação de saída (sem gerar recomposição extra).
    val last = remember { java.util.concurrent.atomic.AtomicReference<Projection?>(null) }
    state.current?.let { last.set(it) }

    CompositionLocalProvider(LocalProjector provides state) {
        Box(Modifier.fillMaxSize()) {
            content()
            if (state.current != null) BackHandler { state.close() }
            AnimatedVisibility(
                visible = state.current != null,
                enter = fadeIn(tween(220)) + scaleIn(tween(320), initialScale = 0.82f),
                exit = fadeOut(tween(180)) + scaleOut(tween(180), targetScale = 0.9f),
            ) {
                Box(
                    Modifier.fillMaxSize()
                        .background(Color(0xF002040C))
                        .clickable(remember { MutableInteractionSource() }, null) { state.close() },
                ) {
                    last.get()?.let { p -> HoloFrame(p, onClose = { state.close() }) }
                }
            }
        }
    }
}

@Composable
private fun HoloFrame(p: Projection, onClose: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val sweep = rememberInfiniteTransition(label = "varredura")
    val y by sweep.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "linha")
    Column(
        Modifier.fillMaxSize()
            .padding(horizontal = 10.dp, vertical = 14.dp)
            .clip(shape)
            .background(Color(0xFF050914))
            .background(Brush.verticalGradient(listOf(p.accent.copy(alpha = 0.14f), Color.Transparent, Color.Transparent)))
            .border(1.dp, Brush.linearGradient(listOf(p.accent, p.accent.copy(alpha = 0.15f), p.accent)), shape)
            .clickable(remember { MutableInteractionSource() }, null) { } // toques no painel não fecham
            .drawWithContent {
                drawContent()
                // linhas de varredura do holograma
                val step = 4.dp.toPx()
                var yy = 0f
                while (yy < size.height) {
                    drawLine(p.accent.copy(alpha = 0.035f), Offset(0f, yy), Offset(size.width, yy), 1f)
                    yy += step
                }
                val sy = y * size.height
                drawRect(
                    Brush.verticalGradient(listOf(Color.Transparent, p.accent.copy(alpha = 0.10f), Color.Transparent), startY = sy - 40f, endY = sy + 40f),
                    topLeft = Offset(0f, sy - 40f), size = androidx.compose.ui.geometry.Size(size.width, 80f),
                )
                // cantoneiras
                val l = 22.dp.toPx(); val s = 2.dp.toPx(); val c = p.accent
                drawLine(c, Offset(0f, s), Offset(l, s), s); drawLine(c, Offset(s, 0f), Offset(s, l), s)
                drawLine(c, Offset(size.width - l, s), Offset(size.width, s), s); drawLine(c, Offset(size.width - s, 0f), Offset(size.width - s, l), s)
                drawLine(c, Offset(0f, size.height - s), Offset(l, size.height - s), s); drawLine(c, Offset(s, size.height - l), Offset(s, size.height), s)
                drawLine(c, Offset(size.width - l, size.height - s), Offset(size.width, size.height - s), s)
                drawLine(c, Offset(size.width - s, size.height - l), Offset(size.width - s, size.height), s)
            },
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(p.accent))
            Spacer(Modifier.size(8.dp))
            Text(
                p.title.uppercase(), color = p.accent, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f),
            )
            Text(
                "✕", color = p.accent, fontSize = 20.sp,
                modifier = Modifier.clickable { onClose() }.padding(horizontal = 14.dp, vertical = 6.dp),
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) { p.content() }
    }
}
