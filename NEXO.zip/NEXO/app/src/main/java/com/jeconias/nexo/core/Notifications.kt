package com.jeconias.nexo.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.jeconias.nexo.R
import com.jeconias.nexo.ui.MainActivity

object Notifications {
    const val CHANNEL_AGENT = "agente"
    const val CHANNEL_ALERTS = "avisos"
    const val PERSISTENT_ID = 1001

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_AGENT, "Agente ativo", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, "Lembretes e rotinas", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun openApp(ctx: Context): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun persistent(ctx: Context): Notification =
        NotificationCompat.Builder(ctx, CHANNEL_AGENT)
            .setSmallIcon(R.drawable.ic_nexo)
            .setContentTitle("NEXO ativo")
            .setContentText("Alfredo está de prontidão. Rotinas e lembretes rodando.")
            .setOngoing(true)
            .setContentIntent(openApp(ctx))
            .build()

    fun show(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_nexo)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openApp(ctx))
            .build()
        val nm = ctx.getSystemService(NotificationManager::class.java)
        try {
            nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
        } catch (_: SecurityException) {
            // Sem permissão de notificação: não há o que fazer aqui.
        }
    }
}
