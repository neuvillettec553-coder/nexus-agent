package com.jeconias.nexo.connectors

import android.content.Context
import android.util.Base64
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/**
 * GOOGLE (Gmail) com o login oficial do Google no Android.
 * Exige uma configuração única no Google Cloud (guia na tela de Conectores).
 */
object GoogleConnector {
    val SCOPES = listOf(
        "https://www.googleapis.com/auth/gmail.readonly",
        "https://www.googleapis.com/auth/gmail.send",
        "https://www.googleapis.com/auth/drive",
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/documents",
        "https://www.googleapis.com/auth/youtube.readonly",
    )

    @Volatile private var token: String? = null
    @Volatile private var expires = 0L

    fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(SCOPES.map { Scope(it) }).build()

    fun accept(result: AuthorizationResult) {
        token = result.accessToken
        expires = System.currentTimeMillis() + 50 * 60_000L
        Container.connectors.setGoogleConnected(token != null)
    }

    fun disconnect() {
        token = null
        Container.connectors.setGoogleConnected(false)
    }

    /** Pega um token válido sem mostrar tela. null = precisa autorizar de novo pelo app. */
    suspend fun silentToken(ctx: Context): String? {
        if (token != null && System.currentTimeMillis() < expires) return token
        if (!Container.connectors.googleConnected()) return null
        return try {
            val r = Identity.getAuthorizationClient(ctx).authorize(request()).await()
            if (r.hasResolution()) null else { accept(r); token }
        } catch (_: Exception) {
            null
        }
    }

    /** Chamada genérica às APIs do Google com o token do usuário. Devolve o texto da resposta. */
    suspend fun raw(ctx: Context, method: String, url: String, body: okhttp3.RequestBody? = null): String = withContext(Dispatchers.IO) {
        val t = silentToken(ctx) ?: throw IllegalStateException(
            "Google não autorizado para este serviço. Abra MODELS → CONNECTORS e toque em Conectar Google (de novo, se já estava conectado)."
        )
        val b = Request.Builder().url(url).header("Authorization", "Bearer $t")
        when (method) {
            "POST" -> b.post(body ?: ByteArray(0).toRequestBody(null))
            "PUT" -> b.put(body ?: ByteArray(0).toRequestBody(null))
            "PATCH" -> b.patch(body ?: ByteArray(0).toRequestBody(null))
            else -> b.get()
        }
        Container.http.newCall(b.build()).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (r.code == 403 && txt.contains("SERVICE_DISABLED", true)) {
                throw IllegalStateException("Este serviço não está ativado no Google Cloud. Ative a API dele no projeto NEXO (guia em CONNECTORS).")
            }
            if (!r.isSuccessful) throw IllegalStateException("Google respondeu ${r.code}: ${txt.take(200)}")
            txt
        }
    }

    suspend fun api(ctx: Context, method: String, url: String, body: JSONObject? = null): JSONObject {
        val txt = raw(ctx, method, url, body?.toString()?.toRequestBody("application/json".toMediaType()))
        return if (txt.isBlank()) JSONObject() else JSONObject(txt)
    }

    suspend fun search(ctx: Context, query: String, max: Int = 8): List<Triple<String, String, String>> {
        val q = java.net.URLEncoder.encode(query.ifBlank { "in:inbox" }, "UTF-8")
        val list = api(ctx, "GET", "https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=$max&q=$q")
        val ids = list.optJSONArray("messages") ?: return emptyList()
        return (0 until ids.length()).map { ids.getJSONObject(it).getString("id") }.map { id ->
            val m = api(ctx, "GET", "https://gmail.googleapis.com/gmail/v1/users/me/messages/$id?format=metadata&metadataHeaders=Subject&metadataHeaders=From")
            val headers = m.optJSONObject("payload")?.optJSONArray("headers")
            fun h(name: String) = headers?.let { arr -> (0 until arr.length()).map { arr.getJSONObject(it) }.firstOrNull { it.optString("name").equals(name, true) }?.optString("value") } ?: ""
            Triple(id, "${h("From")} — ${h("Subject")}", m.optString("snippet"))
        }
    }

    suspend fun read(ctx: Context, id: String): String {
        val m = api(ctx, "GET", "https://gmail.googleapis.com/gmail/v1/users/me/messages/$id?format=full")
        fun walk(part: JSONObject?): String? {
            if (part == null) return null
            if (part.optString("mimeType") == "text/plain") {
                val data = part.optJSONObject("body")?.optString("data").orEmpty()
                if (data.isNotBlank()) return String(Base64.decode(data, Base64.URL_SAFE))
            }
            val parts = part.optJSONArray("parts") ?: return null
            for (i in 0 until parts.length()) walk(parts.getJSONObject(i))?.let { return it }
            return null
        }
        return (walk(m.optJSONObject("payload")) ?: m.optString("snippet")).take(6000)
    }

    suspend fun send(ctx: Context, to: String, subject: String, body: String) {
        val encodedSubject = "=?UTF-8?B?" + Base64.encodeToString(subject.toByteArray(), Base64.NO_WRAP) + "?="
        val raw = "To: $to\r\nSubject: $encodedSubject\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$body"
        val encoded = Base64.encodeToString(raw.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        api(ctx, "POST", "https://gmail.googleapis.com/gmail/v1/users/me/messages/send", JSONObject().put("raw", encoded))
    }
}

class GmailBuscar(private val ctx: Context) : Tool {
    override val name = "gmail_buscar"
    override val level = Level.READ
    override val description = "Busca e-mails no Gmail do usuário (mesma sintaxe da busca do Gmail: from:, subject:, is:unread, newer_than:2d)."
    override val parameters = schema(Param("consulta", "string", "O que buscar (vazio = caixa de entrada)", required = false))
    override suspend fun run(args: JSONObject): ToolResult {
        val r = GoogleConnector.search(ctx, args.optString("consulta"))
        return ToolResult(true, if (r.isEmpty()) "Nenhum e-mail encontrado." else r.joinToString("\n") { "• [${it.first}] ${it.second}: ${it.third.take(140)}" })
    }
}

class GmailLer(private val ctx: Context) : Tool {
    override val name = "gmail_ler"
    override val level = Level.READ
    override val description = "Lê o texto completo de um e-mail pelo id (o id vem do gmail_buscar)."
    override val parameters = schema(Param("id", "string", "Id do e-mail"))
    override suspend fun run(args: JSONObject) = ToolResult(true, GoogleConnector.read(ctx, args.optString("id")))
}

class GmailEnviar(private val ctx: Context) : Tool {
    override val name = "gmail_enviar"
    override val level = Level.SENSITIVE
    override val description = "Envia um e-mail pelo Gmail do usuário. Sempre pede confirmação."
    override val parameters = schema(Param("para", "string", "E-mail do destinatário"), Param("assunto", "string", "Assunto"), Param("texto", "string", "Corpo do e-mail"))
    override suspend fun run(args: JSONObject): ToolResult {
        val to = args.optString("para").trim()
        if (!to.contains("@")) return ToolResult(false, "Destinatário inválido.")
        GoogleConnector.send(ctx, to, args.optString("assunto"), args.optString("texto"))
        return ToolResult(true, "E-mail enviado para $to.")
    }
}
