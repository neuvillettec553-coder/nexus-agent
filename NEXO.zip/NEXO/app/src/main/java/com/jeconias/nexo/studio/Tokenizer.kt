package com.jeconias.nexo.studio

/**
 * Separa o código em pedaços coloridos (comentário, texto, número, palavra-chave).
 * Função pura, sem Android: é testada automaticamente a cada compilação.
 */
object Tokenizer {
    enum class Type { COMMENT, STRING, NUMBER, KEYWORD }
    data class Token(val start: Int, val end: Int, val type: Type)

    private val C_LIKE_KW = "if else for while do switch case break continue return new class interface extends implements " +
        "public private protected static final void int long double float boolean char byte short true false null this super " +
        "try catch finally throw throws import package const let var function async await typeof instanceof enum struct " +
        "namespace using fun val object when is in as override data sealed suspend fn mut impl trait pub use mod match loop " +
        "go func defer chan map range type nil string bool echo foreach default yield export from of"

    private val KEYWORDS: Map<Language, Set<String>> = mapOf(
        Language.PYTHON to ("False None True and as assert async await break class continue def del elif else except finally " +
            "for from global if import in is lambda nonlocal not or pass raise return try while with yield print self").split(" ").toSet(),
        Language.LUA to ("and break do else elseif end false for function goto if in local nil not or repeat return then true until while").split(" ").toSet(),
        Language.SQL to ("select from where insert into values update set delete create table drop alter add primary key foreign " +
            "references not null unique default index join left right inner outer on group by order having limit as and or in " +
            "like between is distinct count sum avg min max integer text real blob").split(" ").toSet(),
        Language.SHELL to ("if then else elif fi for while do done case esac in function return echo export local read exit cd ls cat").split(" ").toSet(),
    )

    private fun keywordsOf(lang: Language): Set<String> = when (lang) {
        Language.PYTHON, Language.LUA, Language.SQL, Language.SHELL -> KEYWORDS.getValue(lang)
        Language.HTML, Language.CSS, Language.MARKDOWN, Language.TEXT, Language.JSON -> emptySet()
        else -> C_LIKE_KW.split(" ").toSet()
    }

    private fun commentPattern(lang: Language): String = when (lang) {
        Language.PYTHON, Language.SHELL -> "#[^\\n]*"
        Language.LUA -> "--\\[\\[[\\s\\S]*?\\]\\]|--[^\\n]*"
        Language.SQL -> "--[^\\n]*|/\\*[\\s\\S]*?\\*/"
        Language.HTML, Language.MARKDOWN -> "<!--[\\s\\S]*?-->"
        Language.CSS -> "/\\*[\\s\\S]*?\\*/"
        Language.TEXT, Language.JSON -> "(?!x)x"
        else -> "//[^\\n]*|/\\*[\\s\\S]*?\\*/"
    }

    private fun stringPattern(lang: Language): String = when (lang) {
        Language.PYTHON -> "\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'"
        Language.JAVASCRIPT, Language.TYPESCRIPT -> "`(?:\\\\.|[^`\\\\])*`|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'"
        Language.TEXT, Language.MARKDOWN -> "(?!x)x"
        else -> "\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'"
    }

    private val cache = mutableMapOf<Language, Regex>()

    private fun regexFor(lang: Language): Regex = synchronized(cache) {
        cache.getOrPut(lang) {
            val kw = keywordsOf(lang)
            val kwPart = if (kw.isEmpty()) "(?!x)x" else "\\b(?:" + kw.joinToString("|") { Regex.escape(it) } + ")\\b"
            val flags = if (lang == Language.SQL) setOf(RegexOption.IGNORE_CASE) else emptySet()
            Regex(
                "(${commentPattern(lang)})|(${stringPattern(lang)})|(\\b\\d+(?:\\.\\d+)?\\b)|($kwPart)",
                flags,
            )
        }
    }

    fun tokenize(text: String, lang: Language): List<Token> {
        if (text.length > 60_000) return emptyList() // arquivos enormes: sem cores, para não travar
        val out = ArrayList<Token>()
        for (m in regexFor(lang).findAll(text)) {
            val type = when {
                m.groups[1] != null -> Type.COMMENT
                m.groups[2] != null -> Type.STRING
                m.groups[3] != null -> Type.NUMBER
                else -> Type.KEYWORD
            }
            if (m.range.last >= m.range.first) out.add(Token(m.range.first, m.range.last + 1, type))
        }
        return out
    }
}
