package com.jeconias.nexo.ui

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.delay

/** “Pensando… 12 s · Groq” com botão Parar. Só aparece enquanto o Alfredo trabalha. */
@Composable
fun BusyIndicator(vm: ChatViewModel) {
    if (!vm.busy) return
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(vm.startedAt) { while (true) { now = System.currentTimeMillis(); delay(500) } }
    val secs = if (vm.startedAt > 0) ((now - vm.startedAt) / 1000).coerceAtLeast(0) else 0
    val who = vm.currentProvider
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "${vm.status.ifBlank { "Pensando…" }}  ${secs}s" + if (who.isNotBlank()) " · $who" else "",
            color = NexoColors.amber, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = { vm.stop() }) { Text("■ Parar", color = NexoColors.red, fontSize = 12.sp) }
    }
}
