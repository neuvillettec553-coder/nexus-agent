package com.jeconias.nexo.life

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Dados de vida (só no celular, entram no backup):
 * finanças, tarefas, hábitos, metas de desenvolvimento, diário e oportunidades de renda.
 * Cada coleção é um arquivo JSON em files/vida/.
 */
class LifeStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "vida").apply { mkdirs() }

    /** Muda a cada gravação; as telas observam para se atualizar. */
    var version by mutableIntStateOf(0)
        private set

    @Synchronized
    fun list(name: String): List<JSONObject> {
        val f = File(dir, "$name.json")
        if (!f.exists()) return emptyList()
        val arr = runCatching { JSONArray(f.readText()) }.getOrDefault(JSONArray())
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    @Synchronized
    fun save(name: String, items: List<JSONObject>) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        File(dir, "$name.json").writeText(arr.toString())
        android.os.Handler(android.os.Looper.getMainLooper()).post { version++ }
    }

    fun add(name: String, item: JSONObject): JSONObject {
        if (!item.has("id")) item.put("id", UUID.randomUUID().toString().take(8))
        if (!item.has("criado")) item.put("criado", today())
        save(name, list(name) + item)
        return item
    }

    fun update(name: String, id: String, change: (JSONObject) -> Unit): Boolean {
        val items = list(name)
        val found = items.firstOrNull { it.optString("id") == id } ?: return false
        change(found)
        save(name, items)
        return true
    }

    fun remove(name: String, id: String) = save(name, list(name).filter { it.optString("id") != id })

    /** Procura um item pelo id ou por parte do título/nome. */
    fun find(name: String, idOrText: String, field: String = "titulo"): JSONObject? {
        val q = idOrText.trim().lowercase()
        return list(name).firstOrNull { it.optString("id") == idOrText }
            ?: list(name).firstOrNull { it.optString(field).lowercase().contains(q) }
    }

    // ---------------- Finanças ----------------

    fun transactions(): List<FinanceMath.Tx> = list(TX).map {
        FinanceMath.Tx(it.optString("data"), it.optString("tipo"), it.optDouble("valor", 0.0), it.optString("categoria"))
    }

    fun monthSummary(month: String = FinanceMath.currentMonth()) = FinanceMath.summary(transactions(), month)

    /** Contas que ainda não foram pagas neste mês. */
    fun unpaidBills(month: String = FinanceMath.currentMonth()): List<JSONObject> =
        list(BILLS).filter { b -> !b.optString("pagas").split(",").contains(month) }

    fun forecast(): Double {
        val c = Calendar.getInstance()
        return FinanceMath.forecast(
            monthSummary(), c.get(Calendar.DAY_OF_MONTH), c.getActualMaximum(Calendar.DAY_OF_MONTH),
            unpaidBills().sumOf { it.optDouble("valor", 0.0) },
        )
    }

    fun debts(): List<FinanceMath.Debt> = list(DEBTS).map {
        FinanceMath.Debt(it.optString("credor"), it.optDouble("total", 0.0), it.optDouble("parcela", 0.0), it.optDouble("juros", 0.0))
    }

    /** Texto completo da situação financeira, usado pela IA e pelo resumo da manhã. */
    fun financeReport(): String {
        val s = monthSummary()
        val m = FinanceMath::money
        val bills = unpaidBills()
        val budgets = list(BUDGETS)
        return buildString {
            append("MÊS ${FinanceMath.currentMonth()}: entradas ${m(s.income)}, gastos ${m(s.expense)}, saldo ${m(s.balance)}")
            if (s.extraIncome > 0) append(", renda extra ${m(s.extraIncome)}")
            append(". Previsão para o fim do mês: ${m(forecast())}.\n")
            if (s.byCategory.isNotEmpty()) append("Gastos por categoria: " + s.byCategory.joinToString { "${it.first} ${m(it.second)}" } + ".\n")
            budgets.forEach { b ->
                val cat = b.optString("categoria")
                val spent = s.byCategory.firstOrNull { it.first.equals(cat, true) }?.second ?: 0.0
                append("Limite $cat: ${m(spent)} de ${m(b.optDouble("limite"))} (${FinanceMath.budgetUse(spent, b.optDouble("limite"))}%).\n")
            }
            if (bills.isNotEmpty()) append("Contas a pagar: " + bills.joinToString { "${it.optString("nome")} ${m(it.optDouble("valor"))} dia ${it.optInt("dia")}" } + ".\n")
            val d = debts()
            if (d.isNotEmpty()) append("Dívidas (ordem sugerida, maiores juros primeiro): " + FinanceMath.avalanche(d).joinToString { "${it.creditor} ${m(it.total)} (${it.monthlyRate}% a.m.)" } + ".\n")
            list(GOALS).forEach { g -> append("Meta ${g.optString("titulo")}: ${m(g.optDouble("guardado"))} de ${m(g.optDouble("alvo"))}.\n") }
        }.trim()
    }

    // ---------------- Vida ----------------

    fun openTasks(): List<JSONObject> = list(TASKS).filter { !it.optBoolean("feita") }
        .sortedWith(compareBy<JSONObject> { it.optString("prazo").ifBlank { "9999" } }.thenByDescending { it.optInt("prioridade", 2) })

    fun habitStreak(h: JSONObject): Int {
        val days = h.optString("dias").split(",").filter { it.isNotBlank() }.toSet()
        var streak = 0
        val c = Calendar.getInstance()
        if (!days.contains(fmt.format(c.time))) c.add(Calendar.DAY_OF_MONTH, -1) // hoje ainda pode ser marcado
        while (days.contains(fmt.format(c.time))) { streak++; c.add(Calendar.DAY_OF_MONTH, -1) }
        return streak
    }

    fun lifeReport(): String = buildString {
        val t = openTasks()
        append("Tarefas abertas: ${t.size}. ")
        t.take(5).forEach { append("• ${it.optString("titulo")}${it.optString("prazo").let { p -> if (p.isNotBlank()) " (até $p)" else "" }} ") }
        val habits = list(HABITS)
        if (habits.isNotEmpty()) append("\nHábitos: " + habits.joinToString { "${it.optString("nome")} ${habitStreak(it)} dias seguidos" + if (it.optString("dias").contains(today())) " ✓hoje" else "" })
        val goals = list(LIFE_GOALS)
        if (goals.isNotEmpty()) append("\nMetas: " + goals.joinToString { g ->
            val steps = g.optJSONArray("passos") ?: JSONArray()
            val done = (0 until steps.length()).count { steps.getJSONObject(it).optBoolean("feito") }
            "${g.optString("titulo")} ($done/${steps.length()} passos)"
        })
    }.trim()

    companion object {
        const val TX = "transacoes"
        const val BILLS = "contas"
        const val DEBTS = "dividas"
        const val GOALS = "metas_financeiras"
        const val BUDGETS = "limites"
        const val TASKS = "tarefas"
        const val HABITS = "habitos"
        const val LIFE_GOALS = "metas_vida"
        const val JOURNAL = "diario"
        const val OPPORTUNITIES = "oportunidades"
        const val PROFILE = "perfil"
        private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun today(): String = fmt.format(Date())
    }
}
