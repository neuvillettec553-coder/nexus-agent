package com.jeconias.nexo.life

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Agenda do celular (a mesma do Google Agenda, se estiver sincronizada).
 * Precisa da permissão de agenda, pedida no painel AGENDA do PREDICT.
 */
object Agenda {
    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    data class Event(val title: String, val start: Long, val end: Long, val location: String)

    suspend fun upcoming(ctx: Context, days: Int = 7): List<Event> = withContext(Dispatchers.IO) {
        if (!hasPermission(ctx)) return@withContext emptyList()
        val now = System.currentTimeMillis()
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .appendPath(now.toString()).appendPath((now + days * 86_400_000L).toString()).build()
        val out = mutableListOf<Event>()
        ctx.contentResolver.query(
            uri,
            arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION),
            null, null, CalendarContract.Instances.BEGIN + " ASC",
        )?.use { c ->
            while (c.moveToNext() && out.size < 50) {
                out += Event(c.getString(0) ?: "(sem título)", c.getLong(1), c.getLong(2), c.getString(3) ?: "")
            }
        }
        out
    }

    fun format(e: Event): String {
        val f = SimpleDateFormat("EEE dd/MM HH:mm", Locale("pt", "BR"))
        return "${f.format(Date(e.start))} · ${e.title}" + if (e.location.isNotBlank()) " (${e.location})" else ""
    }

    /** Cria o evento na primeira agenda do celular que aceita escrita (normalmente a do Google). */
    suspend fun create(ctx: Context, title: String, start: Long, end: Long, description: String): Boolean = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) return@withContext false
        val calId = ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.IS_PRIMARY),
            null, null, null,
        )?.use { c ->
            var best: Long? = null
            while (c.moveToNext()) {
                val access = c.getInt(1)
                if (access >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) {
                    if (best == null || c.getInt(2) == 1) best = c.getLong(0)
                }
            }
            best
        } ?: return@withContext false
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) != null
    }
}

class AgendaListar(private val ctx: Context) : Tool {
    override val name = "agenda_listar"
    override val level = Level.READ
    override val description = "Lista os compromissos da agenda do celular nos próximos dias."
    override val parameters = schema(Param("dias", "integer", "Quantos dias à frente (padrão 7)", required = false))
    override suspend fun run(args: JSONObject): ToolResult {
        if (!Agenda.hasPermission(ctx)) return ToolResult(false, "Sem acesso à agenda. Peça ao usuário para tocar em AGENDA no PREDICT e permitir.")
        val ev = Agenda.upcoming(ctx, args.optInt("dias", 7).coerceIn(1, 60))
        return ToolResult(true, if (ev.isEmpty()) "Nenhum compromisso." else ev.joinToString("\n") { "• " + Agenda.format(it) })
    }
}

class AgendaCriar(private val ctx: Context) : Tool {
    override val name = "agenda_criar"
    override val description = "Cria um compromisso na agenda do celular. Data e hora no formato AAAA-MM-DD HH:MM."
    override val parameters = schema(
        Param("titulo", "string", "Título"),
        Param("inicio", "string", "AAAA-MM-DD HH:MM"),
        Param("duracao_min", "integer", "Duração em minutos (padrão 60)", required = false),
        Param("descricao", "string", "Detalhes", required = false),
    )
    override suspend fun run(args: JSONObject): ToolResult {
        val start = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(args.optString("inicio"))?.time }.getOrNull()
            ?: return ToolResult(false, "Data inválida. Use AAAA-MM-DD HH:MM.")
        val end = start + args.optInt("duracao_min", 60).coerceIn(5, 1440) * 60_000L
        val ok = Agenda.create(ctx, args.optString("titulo"), start, end, args.optString("descricao"))
        return if (ok) ToolResult(true, "Compromisso criado: ${args.optString("titulo")} em ${args.optString("inicio")}.")
        else ToolResult(false, "Não consegui criar (sem permissão de agenda ou nenhuma agenda editável).")
    }
}
