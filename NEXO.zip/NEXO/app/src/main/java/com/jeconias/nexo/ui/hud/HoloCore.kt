package com.jeconias.nexo.ui.hud

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.jeconias.nexo.ui.Phase
import com.jeconias.nexo.ui.theme.NexoColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun phaseColor(phase: Phase): Color = when (phase) {
    Phase.IDLE -> NexoColors.cyan
    Phase.LISTENING -> NexoColors.violet
    Phase.THINKING -> NexoColors.amber
    Phase.ACTING -> Color(0xFFFF8A3D)
    Phase.SPEAKING -> NexoColors.green
}

/**
 * Núcleo holográfico: anéis girando, marcações, onda de voz e esfera de energia.
 * Muda de cor e velocidade conforme o que o Alfredo está fazendo.
 */
@Composable
fun HoloCore(phase: Phase, modifier: Modifier = Modifier) {
    val color by animateColorAsState(phaseColor(phase), tween(600), label = "corNucleo")
    val speed = when (phase) {
        Phase.IDLE -> 1f
        Phase.LISTENING -> 1.8f
        Phase.THINKING -> 3.2f
        Phase.ACTING -> 4f
        Phase.SPEAKING -> 2f
    }
    val speedState = rememberUpdatedState(speed)
    var angle by remember { mutableFloatStateOf(0f) }
    var time by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = (now - last) / 1_000_000_000f
                    angle = (angle + dt * 30f * speedState.value) % 360f
                    time += dt
                }
                last = now
            }
        }
    }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f * 0.80f
        val speaking = phase == Phase.SPEAKING
        val pulse = 1f + 0.07f * sin(time * (if (speaking) 9f else 2.2f))

        // Brilho de fundo
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent), center = c, radius = r * 1.3f),
            radius = r * 1.3f, center = c,
        )
        // Anel fino externo
        drawCircle(color.copy(alpha = 0.25f), radius = r * 1.1f, center = c, style = Stroke(1.dp.toPx()))

        // Anel de segmentos
        rotate(angle, c) {
            for (i in 0 until 12) {
                drawArc(
                    color.copy(alpha = 0.85f), i * 30f, 18f, false,
                    Offset(c.x - r, c.y - r), Size(r * 2, r * 2),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
                )
            }
        }
        // Arcos violeta girando ao contrário
        val r2 = r * 0.80f
        rotate(-angle * 1.6f, c) {
            for (i in 0 until 3) {
                drawArc(
                    NexoColors.violet.copy(alpha = 0.8f), i * 120f, 70f, false,
                    Offset(c.x - r2, c.y - r2), Size(r2 * 2, r2 * 2),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
                )
            }
        }
        // Marcações tipo mostrador
        val ra = r * 0.60f
        val rb = r * 0.67f
        rotate(angle * 0.5f, c) {
            for (i in 0 until 60) {
                val a = i * 6.0 * PI / 180.0
                val cs = cos(a).toFloat()
                val sn = sin(a).toFloat()
                val major = i % 5 == 0
                drawLine(
                    color.copy(alpha = if (major) 0.9f else 0.35f),
                    Offset(c.x + cs * ra, c.y + sn * ra),
                    Offset(c.x + cs * rb, c.y + sn * rb),
                    strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                )
            }
        }
        // Onda de voz (ouvindo ou falando)
        if (speaking || phase == Phase.LISTENING) {
            val path = Path()
            val base = r * 0.50f
            val amp = r * 0.07f
            for (k in 0..120) {
                val th = k / 120f * 2f * PI.toFloat()
                val rr = base + amp * sin(th * 8f + time * 10f) * sin(time * 3f + th * 3f)
                val x = c.x + cos(th) * rr
                val y = c.y + sin(th) * rr
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, color.copy(alpha = 0.9f), style = Stroke(2.dp.toPx()))
        }
        // Satélites orbitando (pensando ou executando)
        if (phase == Phase.THINKING || phase == Phase.ACTING) {
            for (i in 0 until 3) {
                val a = (angle * 3f + i * 120f) * PI.toFloat() / 180f
                drawCircle(Color.White, 4.dp.toPx(), Offset(c.x + cos(a) * r * 0.9f, c.y + sin(a) * r * 0.9f))
            }
        }
        // Esfera de energia
        val cr = r * 0.36f * pulse
        drawCircle(
            Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0f)), center = c, radius = cr * 1.3f),
            radius = cr * 1.3f, center = c,
        )
    }
}
