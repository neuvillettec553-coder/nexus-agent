package com.jeconias.nexo.connectors

import android.content.Context
import org.json.JSONObject

/** Configurações dos conectores (tokens e permissões). Ficam só no celular e entram no backup criptografado. */
class ConnectorStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nexo_conectores", Context.MODE_PRIVATE)

    fun githubToken(): String = prefs.getString("github_token", "") ?: ""
    fun setGithubToken(v: String) = prefs.edit().putString("github_token", v.trim()).apply()

    fun googleConnected(): Boolean = prefs.getBoolean("google_ok", false)
    fun setGoogleConnected(v: Boolean) = prefs.edit().putBoolean("google_ok", v).apply()

    /** "sempre" = executa direto · "perguntar" = pede confirmação · "bloqueado" = o Alfredo não vê a ferramenta. */
    fun mcpPermission(server: String, tool: String): String {
        val all = JSONObject(prefs.getString("mcp_perm", "{}") ?: "{}")
        return all.optJSONObject(server)?.optString(tool, "perguntar") ?: "perguntar"
    }

    fun setMcpPermission(server: String, tool: String, value: String) {
        val all = JSONObject(prefs.getString("mcp_perm", "{}") ?: "{}")
        val s = all.optJSONObject(server) ?: JSONObject()
        s.put(tool, value)
        all.put(server, s)
        prefs.edit().putString("mcp_perm", all.toString()).apply()
    }
}
