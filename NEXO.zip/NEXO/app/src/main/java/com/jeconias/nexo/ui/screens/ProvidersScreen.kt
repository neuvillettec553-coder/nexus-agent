package com.jeconias.nexo.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.providers.ProviderCatalog
import com.jeconias.nexo.providers.ProviderInfo
import com.jeconias.nexo.providers.ProviderRouter
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import com.jeconias.nexo.ui.theme.SectionTitle
import kotlinx.coroutines.launch

@Composable
fun ProvidersScreen() {
    val settings = Container.settings
    var refresh by remember { mutableIntStateOf(0) }
    val order = remember(refresh) { settings.providerOrder() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionTitle("PROVEDORES DE IA")
            Muted("O NEXO tenta de cima para baixo. Se uma IA falhar ou acabar a cota, passa sozinho para a próxima. Use ↑ ↓ para mudar a ordem.")
        }
        items(order, key = { it }) { id ->
            val info = ProviderCatalog.byId(id) ?: return@items
            ProviderCard(
                info = info,
                position = order.indexOf(id),
                total = order.size,
                onMove = { delta ->
                    val list = order.toMutableList()
                    val i = list.indexOf(id)
                    val j = i + delta
                    if (j in list.indices) {
                        list.removeAt(i); list.add(j, id)
                        settings.setProviderOrder(list)
                        refresh++
                    }
                },
            )
        }
    }
}

@Composable
private fun ProviderCard(info: ProviderInfo, position: Int, total: Int, onMove: (Int) -> Unit) {
    val settings = Container.settings
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember(info.id) { mutableStateOf(settings.apiKey(info.id)) }
    var model by remember(info.id) { mutableStateOf(settings.model(info.id)) }
    var enabled by remember(info.id) { mutableStateOf(settings.isEnabled(info.id)) }
    var testResult by remember(info.id) { mutableStateOf("") }
    var testing by remember(info.id) { mutableStateOf(false) }

    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${position + 1}. ", color = NexoColors.muted)
            Text(info.name, color = NexoColors.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (info.free) Text("GRÁTIS ", color = NexoColors.green, fontSize = 11.sp)
            Switch(checked = enabled, onCheckedChange = { enabled = it; settings.setEnabled(info.id, it) })
        }
        OutlinedTextField(
            value = key,
            onValueChange = { key = it; settings.setApiKey(info.id, it) },
            label = { Text("Chave (API key)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = model,
            onValueChange = { model = it; settings.setModel(info.id, it) },
            label = { Text("Modelo") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { onMove(-1) }, enabled = position > 0) { Text("↑ Subir", maxLines = 1) }
            TextButton(onClick = { onMove(1) }, enabled = position < total - 1) { Text("↓ Descer", maxLines = 1) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = {
                    testing = true
                    testResult = "Testando…"
                    scope.launch {
                        testResult = Container.router.test(info.id)
                        testing = false
                    }
                },
                enabled = key.isNotBlank() && !testing,
                modifier = Modifier.weight(1f),
            ) { Text("Testar", maxLines = 1) }
            TextButton(
                onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(info.keyUrl))) } },
                modifier = Modifier.weight(1f),
            ) { Text("Pegar chave", maxLines = 1) }
        }
        Container.router.pauseInfo(info.id)?.let { Text(it, color = NexoColors.amber, fontSize = 12.sp) }
        val suggestion = if (testResult.startsWith("❌")) ProviderRouter.suggestModel(testResult) else null
        if (suggestion != null && suggestion != model) {
            Muted("O provedor sugere trocar o modelo para: $suggestion (pode ser pago; confira antes).")
            OutlinedButton(onClick = {
                model = suggestion
                settings.setModel(info.id, suggestion)
                Container.router.clearPause(info.id)
                testResult = "Modelo trocado. Toque em Testar."
            }) { Text("Usar $suggestion", maxLines = 1) }
        }
        if (testResult.isNotBlank()) Muted(testResult)
    }
}
