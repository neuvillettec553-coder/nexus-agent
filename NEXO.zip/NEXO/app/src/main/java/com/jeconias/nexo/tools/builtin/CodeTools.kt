package com.jeconias.nexo.tools.builtin

import android.content.Context
import com.jeconias.nexo.studio.Runners
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import org.json.JSONObject

/** Deixa o agente executar código de verdade (contas exatas, conferir lógica, processar dados). */
class ExecutarCodigoTool(private val ctx: Context) : Tool {
    override val name = "executar_codigo"
    override val level = Level.ACT
    override val description =
        "Executa código de verdade no celular e devolve a saída. Linguagens: python, javascript, lua, sql. " +
            "Use para cálculos exatos, conferir lógica e processar dados. Mostre resultados com print() ou console.log()."
    override val parameters = schema(
        Param("linguagem", "string", "python, javascript, lua ou sql"),
        Param("codigo", "string", "O código completo"),
    )

    override suspend fun run(args: JSONObject): ToolResult {
        val code = args.optString("codigo")
        if (code.isBlank()) return ToolResult(false, "Código vazio.")
        val r = when (args.optString("linguagem").lowercase().trim()) {
            "python", "py" -> Runners.pythonCode(ctx, code)
            "javascript", "js" -> Runners.javascript(ctx, code)
            "lua" -> Runners.lua(code)
            "sql", "sqlite" -> Runners.sql(code)
            else -> return ToolResult(false, "Linguagem não suportada aqui. Use python, javascript, lua ou sql.")
        }
        return ToolResult(!r.error, r.output.take(6000))
    }
}
