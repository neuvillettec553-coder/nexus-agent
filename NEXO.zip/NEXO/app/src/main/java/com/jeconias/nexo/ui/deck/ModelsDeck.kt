package com.jeconias.nexo.ui.deck

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.providers.ProviderCatalog
import com.jeconias.nexo.ui.ChatViewModel
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.holo.LocalProjector
import com.jeconias.nexo.ui.holo.ModelingGraph
import com.jeconias.nexo.ui.holo.Projection
import com.jeconias.nexo.ui.hud.rememberTilt
import com.jeconias.nexo.ui.screens.MotorPanel
import com.jeconias.nexo.ui.screens.ProvidersScreen
import com.jeconias.nexo.ui.screens.VoiceScreen
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.delay

/** MODELS: as IAs, a voz e o Conselho. */
@Composable
fun ModelsDeck(vm: ChatViewModel) {
    val projector = LocalProjector.current
    val tilt = rememberTilt()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(5_000); tick++ } }
    val settings = Container.settings
    val active = remember(tick) { Container.router.activeProviders() }
    val nodes = remember(tick) { modelNodes() }
    val voice = remember(tick) { Container.voice.engines.firstOrNull { it.id == settings.activeVoice() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        DeckHeader(
            "NEURAL MODEL MATRIX", "PROVIDERS · VOICE · COUNCIL",
            "Active models" to "${active.size}", "Council today" to "${settings.councilUsedToday()}/${settings.councilMaxPerDay()}",
        )
        Spacer(Modifier.height(8.dp))
        HoloTile(
            "MODEL NETWORK", tilt, Modifier.fillMaxWidth().padding(horizontal = 10.dp), accent = HoloCyan, onClick = {
                projector.project(Projection("Provedores de IA", HoloCyan) { ProvidersScreen() })
            },
        ) {
            ModelingGraph(nodes, activeNode(nodes, vm.busy), Modifier.fillMaxWidth().height(200.dp))
            Muted("Toque para configurar chaves, modelos e a ordem de reserva.")
        }
        Spacer(Modifier.height(8.dp))
        HoloTile("PROVIDERS", tilt, Modifier.fillMaxWidth().padding(horizontal = 10.dp), accent = HoloBlue, depth = 0.8f, onClick = {
            projector.project(Projection("Provedores de IA", HoloCyan) { ProvidersScreen() })
        }) {
            if (active.isEmpty()) Text("Nenhuma IA ativa. Toque para configurar.", color = NexoColors.red, fontSize = 13.sp)
            active.forEachIndexed { i, p ->
                val pause = Container.router.pauseInfo(p.info.id)
                Text(
                    "${i + 1}. ${p.info.name} · ${settings.model(p.info.id)}" + (pause?.let { "  $it" } ?: ""),
                    color = if (pause != null) HoloOrange else NexoColors.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            val off = ProviderCatalog.all.size - active.size
            Muted("$off provedor(es) desligado(s) ou sem chave.")
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HoloTile("VOICE", tilt, Modifier.weight(1f), accent = HoloOrange, onClick = {
                projector.project(Projection("Voz", HoloOrange) { VoiceScreen() })
            }) {
                Text("🔊", fontSize = 20.sp)
                Text(voice?.label ?: "—", color = NexoColors.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Muted(if (voice?.available() == true) "pronta" else "usando reserva")
            }
            HoloTile("COUNCIL", tilt, Modifier.weight(1f), accent = HoloCyan, onClick = {
                projector.project(Projection("Motor Local e Conselho", HoloCyan) { MotorPanel() })
            }) {
                Text("⚖️", fontSize = 20.sp)
                Text(
                    when (settings.councilMode()) { "auto" -> "Automático"; "pedido" -> "Sob pedido"; else -> "Desligado" },
                    color = NexoColors.text, fontSize = 12.sp,
                )
                Muted(if (active.size >= 2) "pronto" else "precisa de 2 IAs")
            }
        }
        Spacer(Modifier.height(8.dp))
        HoloTile("CONNECTORS", tilt, Modifier.fillMaxWidth().padding(horizontal = 10.dp), accent = HoloOrange, depth = 1.2f, onClick = {
            projector.project(Projection("Conectores", HoloOrange) { com.jeconias.nexo.ui.screens.ConnectorsScreen() })
        }) {
            val c = Container.connectors
            Text("🔌 Gmail · GitHub · MCP", color = NexoColors.text, fontSize = 13.sp)
            Muted(
                listOf(
                    "Gmail " + if (c.googleConnected()) "●" else "○",
                    "GitHub " + if (c.githubToken().isNotBlank()) "●" else "○",
                    "MCP ${Container.mcp.servers().size}",
                ).joinToString("  ·  ")
            )
        }
        Spacer(Modifier.height(10.dp))
    }
}
