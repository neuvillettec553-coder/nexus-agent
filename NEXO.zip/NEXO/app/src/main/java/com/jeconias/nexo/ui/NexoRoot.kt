package com.jeconias.nexo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jeconias.nexo.ui.deck.CognitiveDeck
import com.jeconias.nexo.ui.deck.LogDeck
import com.jeconias.nexo.ui.deck.ModelsDeck
import com.jeconias.nexo.ui.deck.PredictDeck
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.LabBackground
import com.jeconias.nexo.ui.holo.ProjectorHost
import com.jeconias.nexo.ui.holo.ProjectorState

/** As 4 áreas da barra de baixo, como na imagem de referência. */
enum class Deck(val label: String) { COGNITIVE("COGNITIVE"), MODELS("MODELS"), PREDICT("PREDICT"), LOG("LOG") }

@Composable
fun NexoRoot() {
    var deck by rememberSaveable { mutableStateOf(Deck.COGNITIVE) }
    val chatVm: ChatViewModel = viewModel()
    val projector = remember { ProjectorState() }

    Box(Modifier.fillMaxSize().background(Color(0xFF02060F))) {
        LabBackground(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                ProjectorHost(projector) {
                    when (deck) {
                        Deck.COGNITIVE -> CognitiveDeck(chatVm)
                        Deck.MODELS -> ModelsDeck(chatVm)
                        Deck.PREDICT -> PredictDeck()
                        Deck.LOG -> LogDeck()
                    }
                }
            }
            // Barra de status base com botões virtuais fixos
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE030814))))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Deck.entries.forEach { d ->
                    val selected = d == deck
                    val shape = RoundedCornerShape(6.dp)
                    Box(
                        Modifier.weight(1f).clip(shape)
                            .background(if (selected) HoloCyan.copy(alpha = 0.22f) else Color(0x55061428))
                            .border(1.dp, if (selected) HoloCyan else HoloBlue.copy(alpha = 0.35f), shape)
                            .clickable { projector.close(); deck = d }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            d.label, color = if (selected) Color.White else HoloCyan.copy(alpha = 0.75f),
                            fontFamily = FontFamily.Monospace, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.sp, letterSpacing = 1.sp, maxLines = 1,
                        )
                    }
                }
            }
        }
        // Confirmação de ações sensíveis (aparece em qualquer tela)
        val pending = chatVm.pendingConfirm
        if (pending != null) {
            AlertDialog(
                onDismissRequest = { chatVm.answerConfirm(false) },
                title = { Text("Posso fazer isso?") },
                text = { Text(pending) },
                confirmButton = { Button(onClick = { chatVm.answerConfirm(true) }) { Text("Sim, pode") } },
                dismissButton = { TextButton(onClick = { chatVm.answerConfirm(false) }) { Text("Não") } },
            )
        }
    }
}
