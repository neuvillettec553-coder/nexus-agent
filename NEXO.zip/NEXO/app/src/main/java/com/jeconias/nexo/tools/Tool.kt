package com.jeconias.nexo.tools

import com.jeconias.nexo.providers.ToolSpec
import org.json.JSONArray
import org.json.JSONObject

/**
 * ok = a ação aconteceu DE VERDADE (verificado quando possível).
 * output = o que a IA vai ler sobre o resultado.
 */
data class ToolResult(val ok: Boolean, val output: String, val refused: Boolean = false)

/**
 * Nível de confirmação:
 *  READ      = só mostra informação, faz na hora.
 *  ACT       = mexe em algo do celular, faz e avisa.
 *  SENSITIVE = envia algo, apaga ou mexe com dinheiro: SEMPRE pede sua confirmação.
 */
enum class Level { READ, ACT, SENSITIVE }

interface Tool {
    val name: String
    val description: String
    val parameters: JSONObject
    val level: Level get() = Level.ACT
    suspend fun run(args: JSONObject): ToolResult
}

data class Param(val name: String, val type: String, val description: String, val required: Boolean = true)

/** Monta o esquema JSON dos parâmetros de uma ferramenta. */
fun schema(vararg params: Param): JSONObject {
    val props = JSONObject()
    val req = JSONArray()
    params.forEach {
        props.put(it.name, JSONObject().put("type", it.type).put("description", it.description))
        if (it.required) req.put(it.name)
    }
    return JSONObject().put("type", "object").put("properties", props).put("required", req)
}

class ToolRegistry {
    private val tools = LinkedHashMap<String, Tool>()

    @Synchronized fun register(tool: Tool) { tools[tool.name] = tool }
    @Synchronized fun unregisterPrefix(prefix: String) { tools.keys.filter { it.startsWith(prefix) }.forEach { tools.remove(it) } }
    @Synchronized fun get(name: String): Tool? = tools[name]
    @Synchronized fun all(): List<Tool> = tools.values.toList()
    fun specs(): List<ToolSpec> = all().map { ToolSpec(it.name, it.description, it.parameters) }
}
