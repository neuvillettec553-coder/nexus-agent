package com.jeconias.nexo.backup

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.jeconias.nexo.core.Container
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Backup criptografado (AES-256-GCM, chave derivada da sua senha).
 * Guarda: AGENTS.md, MEMORY.md, skills, notas, configurações, rotinas e atalhos aprendidos.
 * Sem a senha, o arquivo não pode ser aberto por ninguém, nem por você.
 */
object BackupManager {
    private const val MAGIC = "NEXOBK1"
    private val FOLDERS = listOf("contexto", "skills", "notas", "vida", "projetos")
    private val PREFS = listOf("nexo_settings", "nexo_rotinas", "nexo_atalhos", "nexo_metricas", "nexo_conectores")
    /** Nunca entram no backup: a própria senha e a pasta do backup automático. */
    private val SKIP_KEYS = setOf("backup_pass", "backup_folder", "backup_last")

    fun fileName(auto: Boolean = false): String =
        "nexo-backup-" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + (if (auto) "-auto" else "") + ".nexo"

    // ---------------- montar e restaurar ----------------

    private fun buildZip(ctx: Context): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            for (folder in FOLDERS) {
                val dir = File(ctx.filesDir, folder)
                if (!dir.exists()) continue
                dir.walkTopDown().filter { it.isFile }.forEach { f ->
                    zip.putNextEntry(ZipEntry("$folder/${f.relativeTo(dir).path}"))
                    zip.write(f.readBytes())
                    zip.closeEntry()
                }
            }
            for (name in PREFS) {
                val json = JSONObject()
                ctx.getSharedPreferences(name, Context.MODE_PRIVATE).all.forEach { (k, v) ->
                    if (k in SKIP_KEYS) return@forEach
                    val entry = when (v) {
                        is String -> JSONObject().put("t", "s").put("v", v)
                        is Boolean -> JSONObject().put("t", "b").put("v", v)
                        is Int -> JSONObject().put("t", "i").put("v", v)
                        is Long -> JSONObject().put("t", "l").put("v", v)
                        is Float -> JSONObject().put("t", "f").put("v", v.toDouble())
                        is Set<*> -> JSONObject().put("t", "set").put("v", JSONArray(v.map { it.toString() }))
                        else -> null
                    }
                    if (entry != null) json.put(k, entry)
                }
                zip.putNextEntry(ZipEntry("prefs/$name.json"))
                zip.write(json.toString().toByteArray())
                zip.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun restoreZip(ctx: Context, data: ByteArray) {
        ZipInputStream(ByteArrayInputStream(data)).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val name = e.name
                val bytes = zip.readBytes()
                if (name.contains("..")) continue
                if (name.startsWith("prefs/") && name.endsWith(".json")) {
                    val prefName = name.removePrefix("prefs/").removeSuffix(".json")
                    if (prefName !in PREFS) continue
                    val json = JSONObject(String(bytes))
                    val ed = ctx.getSharedPreferences(prefName, Context.MODE_PRIVATE).edit()
                    json.keys().forEach { k ->
                        val o = json.getJSONObject(k)
                        when (o.getString("t")) {
                            "s" -> ed.putString(k, o.getString("v"))
                            "b" -> ed.putBoolean(k, o.getBoolean("v"))
                            "i" -> ed.putInt(k, o.getInt("v"))
                            "l" -> ed.putLong(k, o.getLong("v"))
                            "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                            "set" -> {
                                val arr = o.getJSONArray("v")
                                ed.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                            }
                        }
                    }
                    ed.apply()
                } else {
                    val folder = name.substringBefore("/")
                    if (folder !in FOLDERS) continue
                    val target = File(ctx.filesDir, name)
                    target.parentFile?.mkdirs()
                    target.writeBytes(bytes)
                }
            }
        }
    }

    // ---------------- criptografia ----------------

    private fun key(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, 120_000, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    internal fun encrypt(data: ByteArray, password: String): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
        return MAGIC.toByteArray() + salt + iv + cipher.doFinal(data)
    }

    internal fun decrypt(data: ByteArray, password: String): ByteArray {
        val m = MAGIC.toByteArray()
        require(data.size > m.size + 28 && data.copyOfRange(0, m.size).contentEquals(m)) { "Este arquivo não é um backup do NEXO." }
        val salt = data.copyOfRange(m.size, m.size + 16)
        val iv = data.copyOfRange(m.size + 16, m.size + 28)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
        return try {
            cipher.doFinal(data.copyOfRange(m.size + 28, data.size))
        } catch (_: Exception) {
            throw IllegalArgumentException("Senha errada ou arquivo danificado.")
        }
    }

    // ---------------- operações públicas ----------------

    suspend fun exportTo(ctx: Context, uri: Uri, password: String): String = withContext(Dispatchers.IO) {
        require(password.length >= 4) { "Defina uma senha de backup com pelo menos 4 caracteres." }
        val bytes = encrypt(buildZip(ctx), password)
        ctx.contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
            ?: throw IllegalStateException("Não consegui gravar o arquivo.")
        Container.settings.setLastBackup(System.currentTimeMillis())
        "✅ Backup salvo (${bytes.size / 1024} KB)."
    }

    /** Backup pronto (criptografado) em memória, para enviar ao Google Drive. */
    suspend fun encryptedBytes(ctx: Context, password: String): ByteArray = withContext(Dispatchers.IO) {
        require(password.length >= 4) { "Defina uma senha de backup com pelo menos 4 caracteres." }
        encrypt(buildZip(ctx), password)
    }

    suspend fun importFrom(ctx: Context, uri: Uri, password: String): String = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Não consegui ler o arquivo.")
        restoreZip(ctx, decrypt(bytes, password))
        Container.routines.rescheduleAll()
        "✅ Backup restaurado. Feche e abra o NEXO para carregar tudo."
    }

    /** Backup automático diário na pasta escolhida. */
    suspend fun autoBackup(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        val s = Container.settings
        val folder = s.backupFolder()
        val pass = s.backupPassword()
        if (folder.isBlank() || pass.length < 4) return@withContext false
        val tree = Uri.parse(folder)
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, "application/octet-stream", fileName(auto = true))
            ?: return@withContext false
        val bytes = encrypt(buildZip(ctx), pass)
        ctx.contentResolver.openOutputStream(doc, "w")?.use { it.write(bytes) } ?: return@withContext false
        s.setLastBackup(System.currentTimeMillis())
        true
    }

    fun scheduleAuto(ctx: Context, on: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (!on) { wm.cancelUniqueWork("backup_auto"); return }
        val req = PeriodicWorkRequestBuilder<BackupWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(1, TimeUnit.HOURS)
            .build()
        wm.enqueueUniquePeriodicWork("backup_auto", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

class BackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Container.init(applicationContext)
        return try {
            if (BackupManager.autoBackup(applicationContext)) Result.success() else Result.retry()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
