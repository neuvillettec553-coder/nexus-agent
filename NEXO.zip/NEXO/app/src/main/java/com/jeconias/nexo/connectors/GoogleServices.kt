package com.jeconias.nexo.connectors

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Param
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolResult
import com.jeconias.nexo.tools.schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Google Drive, Planilhas, Docs e YouTube, com o mesmo login do Gmail. */
object GoogleServices {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ------------------------------ DRIVE ------------------------------
    data class DriveFile(val id: String, val name: String, val mime: String, val modified: String)

    suspend fun driveSearch(ctx: Context, text: String, max: Int = 10): List<DriveFile> {
        val q = if (text.isBlank()) "trashed=false" else "name contains '${text.replace("'", "\\'")}' and trashed=false"
        val r = GoogleConnector.api(
            ctx, "GET",
            "https://www.googleapis.com/drive/v3/files?pageSize=$max&orderBy=modifiedTime desc&fields=files(id,name,mimeType,modifiedTime)&q=${enc(q)}",
        )
        val arr = r.optJSONArray("files") ?: JSONArray()
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            DriveFile(it.optString("id"), it.optString("name"), it.optString("mimeType"), it.optString("modifiedTime").take(10))
        }
    }

    suspend fun driveRead(ctx: Context, id: String): String {
        val meta = GoogleConnector.api(ctx, "GET", "https://www.googleapis.com/drive/v3/files/$id?fields=name,mimeType")
        val mime = meta.optString("mimeType")
        val url = when (mime) {
            "application/vnd.google-apps.document" -> "https://www.googleapis.com/drive/v3/files/$id/export?mimeType=text/plain"
            "application/vnd.google-apps.spreadsheet" -> "https://www.googleapis.com/drive/v3/files/$id/export?mimeType=text/csv"
            "application/vnd.google-apps.presentation" -> "https://www.googleapis.com/drive/v3/files/$id/export?mimeType=text/plain"
            else -> if (mime.startsWith("text/") || mime.contains("json") || mime.contains("csv")) "https://www.googleapis.com/drive/v3/files/$id?alt=media"
            else return "O arquivo “${meta.optString("name")}” é do tipo $mime e não dá para ler como texto."
        }
        return GoogleConnector.raw(ctx, "GET", url).take(8000)
    }

    /** Pasta "NEXO" no Drive (cria se não existir). */
    suspend fun nexoFolder(ctx: Context): String {
        val q = "name='NEXO' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        val found = GoogleConnector.api(ctx, "GET", "https://www.googleapis.com/drive/v3/files?fields=files(id)&q=${enc(q)}")
            .optJSONArray("files")
        if (found != null && found.length() > 0) return found.getJSONObject(0).getString("id")
        return GoogleConnector.api(
            ctx, "POST", "https://www.googleapis.com/drive/v3/files",
            JSONObject().put("name", "NEXO").put("mimeType", "application/vnd.google-apps.folder"),
        ).getString("id")
    }

    /** Envia um arquivo para a pasta NEXO do Drive. Devolve o link. */
    suspend fun driveUpload(ctx: Context, name: String, bytes: ByteArray, mime: String): String = withContext(Dispatchers.IO) {
        val folder = nexoFolder(ctx)
        val meta = JSONObject().put("name", name).put("parents", JSONArray().put(folder))
        val body = MultipartBody.Builder()
            .setType("multipart/related".toMediaType())
            .addPart(meta.toString().toRequestBody("application/json; charset=UTF-8".toMediaType()))
            .addPart(bytes.toRequestBody(mime.toMediaType()))
            .build()
        val r = JSONObject(
            GoogleConnector.raw(ctx, "POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink", body)
        )
        r.optString("webViewLink").ifBlank { "https://drive.google.com/file/d/${r.optString("id")}" }
    }

    // ------------------------------ PLANILHAS ------------------------------
    /** Cria uma planilha com as linhas dadas. Devolve o link. */
    suspend fun sheetCreate(ctx: Context, title: String, rows: List<List<Any>>): String {
        val created = GoogleConnector.api(ctx, "POST", "https://sheets.googleapis.com/v4/spreadsheets",
            JSONObject().put("properties", JSONObject().put("title", title)))
        val id = created.getString("spreadsheetId")
        if (rows.isNotEmpty()) sheetWrite(ctx, id, "A1", rows)
        return created.optString("spreadsheetUrl", "https://docs.google.com/spreadsheets/d/$id")
    }

    suspend fun sheetWrite(ctx: Context, id: String, range: String, rows: List<List<Any>>) {
        val values = JSONArray()
        rows.forEach { row -> values.put(JSONArray().apply { row.forEach { put(it) } }) }
        GoogleConnector.raw(
            ctx, "PUT",
            "https://sheets.googleapis.com/v4/spreadsheets/$id/values/${enc(range)}?valueInputOption=USER_ENTERED",
            JSONObject().put("values", values).toString().toRequestBody("application/json".toMediaType()),
        )
    }

    suspend fun sheetAppend(ctx: Context, id: String, rows: List<List<Any>>) {
        val values = JSONArray()
        rows.forEach { row -> values.put(JSONArray().apply { row.forEach { put(it) } }) }
        GoogleConnector.api(
            ctx, "POST",
            "https://sheets.googleapis.com/v4/spreadsheets/$id/values/${enc("A1")}:append?valueInputOption=USER_ENTERED",
            JSONObject().put("values", values),
        )
    }

    suspend fun sheetRead(ctx: Context, id: String, range: String): String {
        val r = GoogleConnector.api(ctx, "GET", "https://sheets.googleapis.com/v4/spreadsheets/$id/values/${enc(range.ifBlank { "A1:Z200" })}")
        val arr = r.optJSONArray("values") ?: return "(planilha vazia)"
        return (0 until arr.length()).joinToString("\n") { i ->
            val row = arr.getJSONArray(i)
            (0 until row.length()).joinToString(" | ") { row.optString(it) }
        }.take(8000)
    }

    /** Aceita o link completo ou só o id da planilha/documento. */
    fun idFrom(linkOrId: String): String =
        Regex("/d/([A-Za-z0-9_-]{20,})").find(linkOrId)?.groupValues?.get(1) ?: linkOrId.trim()

    // ------------------------------ DOCS ------------------------------
    suspend fun docCreate(ctx: Context, title: String, text: String): String {
        val doc = GoogleConnector.api(ctx, "POST", "https://docs.googleapis.com/v1/documents", JSONObject().put("title", title))
        val id = doc.getString("documentId")
        if (text.isNotBlank()) {
            GoogleConnector.api(
                ctx, "POST", "https://docs.googleapis.com/v1/documents/$id:batchUpdate",
                JSONObject().put("requests", JSONArray().put(
                    JSONObject().put("insertText", JSONObject().put("location", JSONObject().put("index", 1)).put("text", text))
                )),
            )
        }
        return "https://docs.google.com/document/d/$id/edit"
    }

    // ------------------------------ YOUTUBE ------------------------------
    suspend fun youtubeSearch(ctx: Context, query: String, max: Int = 5): List<Pair<String, String>> {
        val r = GoogleConnector.api(ctx, "GET", "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=$max&q=${enc(query)}")
        val arr = r.optJSONArray("items") ?: JSONArray()
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            val title = it.optJSONObject("snippet")?.optString("title").orEmpty()
            val channel = it.optJSONObject("snippet")?.optString("channelTitle").orEmpty()
            "$title — $channel" to "https://www.youtube.com/watch?v=${it.optJSONObject("id")?.optString("videoId")}"
        }
    }
}

// ============================== FERRAMENTAS ==============================

class DriveBuscar(private val ctx: Context) : Tool {
    override val name = "drive_buscar"
    override val level = Level.READ
    override val description = "Busca arquivos no Google Drive do usuário pelo nome (vazio = mais recentes)."
    override val parameters = schema(Param("nome", "string", "Parte do nome do arquivo", required = false))
    override suspend fun run(args: JSONObject): ToolResult {
        val r = GoogleServices.driveSearch(ctx, args.optString("nome"))
        return ToolResult(true, if (r.isEmpty()) "Nenhum arquivo encontrado." else r.joinToString("\n") { "• [${it.id}] ${it.name} (${it.modified})" })
    }
}

class DriveLer(private val ctx: Context) : Tool {
    override val name = "drive_ler"
    override val level = Level.READ
    override val description = "Lê o conteúdo de um arquivo do Drive (Docs, Planilhas, textos) pelo id vindo do drive_buscar."
    override val parameters = schema(Param("id", "string", "Id do arquivo"))
    override suspend fun run(args: JSONObject) = ToolResult(true, GoogleServices.driveRead(ctx, args.optString("id")))
}

class DriveSalvar(private val ctx: Context) : Tool {
    override val name = "drive_salvar"
    override val description = "Salva um texto como arquivo na pasta NEXO do Google Drive do usuário."
    override val parameters = schema(Param("nome", "string", "Nome do arquivo (ex.: lista.txt)"), Param("conteudo", "string", "Texto"))
    override suspend fun run(args: JSONObject): ToolResult {
        val link = GoogleServices.driveUpload(ctx, args.optString("nome").ifBlank { "nota.txt" }, args.optString("conteudo").toByteArray(), "text/plain")
        return ToolResult(true, "Salvo no Drive (pasta NEXO): $link")
    }
}

class PlanilhaCriar(private val ctx: Context) : Tool {
    override val name = "planilha_criar"
    override val description = "Cria uma planilha no Google Planilhas. Linhas em JSON: [[\"Coluna A\",\"Coluna B\"],[\"x\",1]]."
    override val parameters = schema(Param("titulo", "string", "Título"), Param("linhas_json", "string", "Linhas em JSON (lista de listas)", required = false))
    override suspend fun run(args: JSONObject): ToolResult {
        val rows = parseRows(args.optString("linhas_json"))
        return ToolResult(true, "Planilha criada: " + GoogleServices.sheetCreate(ctx, args.optString("titulo").ifBlank { "Planilha NEXO" }, rows))
    }
}

class PlanilhaLer(private val ctx: Context) : Tool {
    override val name = "planilha_ler"
    override val level = Level.READ
    override val description = "Lê valores de uma planilha do Google pelo link ou id (intervalo opcional, ex.: A1:D30)."
    override val parameters = schema(Param("planilha", "string", "Link ou id"), Param("intervalo", "string", "Ex.: A1:D30", required = false))
    override suspend fun run(args: JSONObject) =
        ToolResult(true, GoogleServices.sheetRead(ctx, GoogleServices.idFrom(args.optString("planilha")), args.optString("intervalo")))
}

class PlanilhaAdicionar(private val ctx: Context) : Tool {
    override val name = "planilha_adicionar"
    override val description = "Acrescenta linhas no fim de uma planilha do Google (pelo link ou id). Linhas em JSON."
    override val parameters = schema(Param("planilha", "string", "Link ou id"), Param("linhas_json", "string", "Ex.: [[\"07/10\",\"mercado\",45]]"))
    override suspend fun run(args: JSONObject): ToolResult {
        val rows = parseRows(args.optString("linhas_json"))
        if (rows.isEmpty()) return ToolResult(false, "Nenhuma linha válida.")
        GoogleServices.sheetAppend(ctx, GoogleServices.idFrom(args.optString("planilha")), rows)
        return ToolResult(true, "${rows.size} linha(s) adicionada(s).")
    }
}

class DocCriar(private val ctx: Context) : Tool {
    override val name = "doc_criar"
    override val description = "Cria um documento no Google Docs com o texto informado e devolve o link."
    override val parameters = schema(Param("titulo", "string", "Título"), Param("texto", "string", "Conteúdo"))
    override suspend fun run(args: JSONObject) =
        ToolResult(true, "Documento criado: " + GoogleServices.docCreate(ctx, args.optString("titulo").ifBlank { "Documento NEXO" }, args.optString("texto")))
}

class YoutubeBuscar(private val ctx: Context) : Tool {
    override val name = "youtube_buscar"
    override val level = Level.READ
    override val description = "Busca vídeos no YouTube (tutoriais, aulas, notícias) e devolve títulos e links."
    override val parameters = schema(Param("consulta", "string", "O que buscar"))
    override suspend fun run(args: JSONObject): ToolResult {
        val r = GoogleServices.youtubeSearch(ctx, args.optString("consulta"))
        return ToolResult(true, if (r.isEmpty()) "Nenhum vídeo." else r.joinToString("\n") { "• ${it.first}\n  ${it.second}" })
    }
}

/** Rotas e lugares pelo app do Google Maps (sem API paga: o Maps abre já com o destino). */
class MapaRota(private val ctx: Context) : Tool {
    override val name = "mapa_rota"
    override val description = "Abre o Google Maps com a rota até um destino. Modo: carro, a pé, ônibus, bicicleta."
    override val parameters = schema(Param("destino", "string", "Endereço ou nome do lugar"), Param("modo", "string", "carro, a pé, ônibus ou bicicleta", required = false))
    override suspend fun run(args: JSONObject): ToolResult {
        val mode = when (args.optString("modo").lowercase()) {
            "a pé", "a pe", "andando", "caminhando" -> "walking"
            "ônibus", "onibus", "transporte", "transporte público" -> "transit"
            "bicicleta", "bike" -> "bicycling"
            else -> "driving"
        }
        val url = "https://www.google.com/maps/dir/?api=1&destination=${Uri.encode(args.optString("destino"))}&travelmode=$mode"
        return openMaps(ctx, url, "Rota para ${args.optString("destino")} aberta no Maps.")
    }
}

class MapaBuscar(private val ctx: Context) : Tool {
    override val name = "mapa_buscar"
    override val description = "Abre o Google Maps procurando lugares (ex.: 'farmácia aberta perto de mim', 'mecânico de moto')."
    override val parameters = schema(Param("consulta", "string", "O que procurar"))
    override suspend fun run(args: JSONObject): ToolResult {
        val url = "https://www.google.com/maps/search/?api=1&query=${Uri.encode(args.optString("consulta"))}"
        return openMaps(ctx, url, "Busca aberta no Maps: ${args.optString("consulta")}.")
    }
}

private suspend fun openMaps(ctx: Context, url: String, ok: String): ToolResult = withContext(Dispatchers.Main) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ToolResult(true, "$ok O usuário vê o resultado no app do Maps.")
    } catch (e: Exception) {
        ToolResult(false, "Não consegui abrir o Maps: ${e.message}")
    }
}

internal fun parseRows(json: String): List<List<Any>> = runCatching {
    val arr = JSONArray(json.trim().ifBlank { "[]" })
    (0 until arr.length()).map { i ->
        val row = arr.getJSONArray(i)
        (0 until row.length()).map { j -> row.get(j) }
    }
}.getOrDefault(emptyList())

object GoogleTools {
    fun registerAll(r: com.jeconias.nexo.tools.ToolRegistry, ctx: Context) {
        listOf(
            DriveBuscar(ctx), DriveLer(ctx), DriveSalvar(ctx), PlanilhaCriar(ctx), PlanilhaLer(ctx), PlanilhaAdicionar(ctx),
            DocCriar(ctx), YoutubeBuscar(ctx), MapaRota(ctx), MapaBuscar(ctx),
        ).forEach { r.register(it) }
    }
}
