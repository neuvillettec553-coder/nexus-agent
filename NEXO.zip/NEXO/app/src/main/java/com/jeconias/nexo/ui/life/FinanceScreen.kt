package com.jeconias.nexo.ui.life

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.life.FinanceMath
import com.jeconias.nexo.life.LifeStore
import com.jeconias.nexo.life.MoneyCoach
import com.jeconias.nexo.studio.ProjectStore
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.theme.GlassCard
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.launch
import org.json.JSONObject

private val CATEGORIES = listOf("mercado", "contas", "transporte", "alimentação", "saúde", "lazer", "filho", "casa", "dívidas", "outros")
private val INCOME_CATS = listOf("salário", "renda extra", "outros")

/** CENTRAL FINANCEIRA: estancar o aperto, contas e dívidas, renda extra e metas. Protegida por digital. */
@Composable
fun FinanceScreen() {
    val activity = LocalContext.current as? FragmentActivity
    var unlocked by remember { mutableStateOf(Lock.isUnlocked()) }
    var lockMsg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        if (!unlocked) Lock.request(activity) { ok, msg -> unlocked = ok; lockMsg = msg }
    }
    if (!unlocked) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🔒", fontSize = 42.sp)
            Text("Central Financeira protegida", color = NexoColors.text, fontWeight = FontWeight.Bold)
            if (lockMsg.isNotBlank()) Muted(lockMsg)
            Button(onClick = { Lock.request(activity) { ok, msg -> unlocked = ok; lockMsg = msg } }) { Text("Desbloquear") }
        }
        return
    }
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        if (lockMsg.isNotBlank()) Muted("  $lockMsg")
        SubTabs(listOf("RAIO-X", "CONTAS E DÍVIDAS", "RENDA EXTRA", "METAS"), tab) { tab = it }
        when (tab) {
            0 -> XRayTab()
            1 -> BillsDebtsTab()
            2 -> IncomeTab()
            else -> GoalsTab()
        }
    }
}

// ============================ RAIO-X ============================

@Composable
private fun XRayTab() {
    val store = Container.life
    val coach = remember { MoneyCoach(store) }
    val scope = rememberCoroutineScope()
    val v = store.version
    val sum = remember(v) { store.monthSummary() }
    val forecast = remember(v) { store.forecast() }
    val txs = remember(v) { store.list(LifeStore.TX).sortedByDescending { it.optString("data") + it.optString("criado") }.take(40) }
    var tipo by remember { mutableStateOf("gasto") }
    var valor by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("mercado") }
    var desc by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            GlassCard {
                SectionLabel("MÊS ATUAL")
                Row {
                    Column(Modifier.weight(1f)) { Muted("Entradas"); Text(FinanceMath.money(sum.income), color = NexoColors.green, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f)) { Muted("Gastos"); Text(FinanceMath.money(sum.expense), color = NexoColors.red, fontWeight = FontWeight.Bold) }
                }
                Row {
                    Column(Modifier.weight(1f)) { Muted("Saldo"); Text(FinanceMath.money(sum.balance), color = NexoColors.text, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f)) {
                        Muted("Previsão fim do mês")
                        Text(FinanceMath.money(forecast), color = if (forecast < 0) NexoColors.red else NexoColors.green, fontWeight = FontWeight.Bold)
                    }
                }
                if (forecast < 0) Text("No ritmo atual, o mês fecha no vermelho. Veja o plano abaixo.", color = HoloOrange, fontSize = 12.sp)
            }
        }
        if (sum.byCategory.isNotEmpty()) item {
            GlassCard {
                SectionLabel("PARA ONDE O DINHEIRO VAI")
                val max = sum.byCategory.first().second
                sum.byCategory.forEach { (c, value) ->
                    Row { Text(c, color = NexoColors.text, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(FinanceMath.money(value), color = NexoColors.text, fontSize = 12.sp) }
                    Bar((value / max).toFloat(), HoloOrange)
                }
            }
        }
        item {
            GlassCard {
                SectionLabel("REGISTRAR")
                Muted("Ou fale: “gastei 45 no mercado”, “recebi 300 de renda extra”.")
                Chips(listOf("gasto", "entrada"), tipo) { tipo = it; cat = if (it == "gasto") "mercado" else "salário" }
                Field(valor, { valor = it }, "Valor (R$)", number = true)
                Chips(if (tipo == "gasto") CATEGORIES else INCOME_CATS, cat) { cat = it }
                Field(desc, { desc = it }, "Descrição (opcional)")
                Button(onClick = {
                    val v2 = FinanceMath.parseMoney(valor) ?: return@Button
                    store.add(LifeStore.TX, JSONObject().put("tipo", tipo).put("valor", v2).put("categoria", cat).put("descricao", desc).put("data", LifeStore.today()))
                    valor = ""; desc = ""
                }, enabled = FinanceMath.parseMoney(valor) != null, modifier = Modifier.fillMaxWidth()) { Text("Salvar") }
            }
        }
        item {
            GlassCard {
                SectionLabel("ALIVIAR O APERTO")
                Muted("A IA lê os seus números reais e monta um plano de cortes e prioridades para este mês.")
                Button(onClick = {
                    busy = "Analisando…"
                    scope.launch { plan = runCatching { coach.cutPlan() }.getOrElse { "❌ ${it.message}" }; busy = "" }
                }, enabled = busy.isBlank(), modifier = Modifier.fillMaxWidth()) { Text("🤖 Montar plano do mês") }
                Busy(busy)
            }
        }
        if (plan.isNotBlank()) item { AiResult(plan, "Plano financeiro do mês") }
        if (Container.connectors.googleConnected()) item {
            var sheetMsg by remember { mutableStateOf("") }
            val ctx = LocalContext.current
            OutlinedButtonRow("📊 Exportar o mês para Google Planilhas") {
                sheetMsg = "Criando a planilha…"
                scope.launch {
                    sheetMsg = try {
                        val month = FinanceMath.currentMonth()
                        val rows = mutableListOf<List<Any>>(listOf("Data", "Tipo", "Categoria", "Descrição", "Valor"))
                        store.list(LifeStore.TX).filter { it.optString("data").startsWith(month) }.sortedBy { it.optString("data") }.forEach {
                            rows += listOf(it.optString("data"), it.optString("tipo"), it.optString("categoria"), it.optString("descricao"),
                                if (it.optString("tipo") == "gasto") -it.optDouble("valor") else it.optDouble("valor"))
                        }
                        rows += listOf("", "", "", "SALDO", "=SUM(E2:E${rows.size})")
                        val link = com.jeconias.nexo.connectors.GoogleServices.sheetCreate(ctx, "NEXO Finanças $month", rows)
                        runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(link)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        "✅ Planilha criada."
                    } catch (e: Exception) { "❌ ${e.message}" }
                }
            }
            if (sheetMsg.isNotBlank()) Muted(sheetMsg)
        }
        item { SectionLabel("ÚLTIMOS LANÇAMENTOS") }
        if (txs.isEmpty()) item { Empty("Nada registrado ainda.") }
        items(txs, key = { it.optString("id") }) { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (t.optString("tipo") == "entrada") "＋" else "－", color = if (t.optString("tipo") == "entrada") NexoColors.green else NexoColors.red, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text("${t.optString("categoria")} · ${FinanceMath.money(t.optDouble("valor"))}", color = NexoColors.text, fontSize = 13.sp)
                    Muted("${t.optString("data")} ${t.optString("descricao")}")
                }
                TextButton(onClick = { store.remove(LifeStore.TX, t.optString("id")) }) { Text("✕", color = NexoColors.muted) }
            }
        }
    }
}

// ============================ CONTAS E DÍVIDAS ============================

@Composable
private fun BillsDebtsTab() {
    val store = Container.life
    val coach = remember { MoneyCoach(store) }
    val scope = rememberCoroutineScope()
    val v = store.version
    val month = FinanceMath.currentMonth()
    val bills = remember(v) { store.list(LifeStore.BILLS).sortedBy { it.optInt("dia") } }
    val debts = remember(v) { store.list(LifeStore.DEBTS).sortedByDescending { it.optDouble("juros") } }
    var bName by remember { mutableStateOf("") }
    var bValue by remember { mutableStateOf("") }
    var bDay by remember { mutableStateOf("") }
    var dName by remember { mutableStateOf("") }
    var dTotal by remember { mutableStateOf("") }
    var dInst by remember { mutableStateOf("") }
    var dRate by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionLabel("CONTAS FIXAS DO MÊS") }
        if (bills.isEmpty()) item { Empty("Nenhuma conta cadastrada. Eu aviso um dia antes de cada vencimento.") }
        items(bills, key = { it.optString("id") }) { b ->
            val paid = b.optString("pagas").split(",").contains(month)
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${b.optString("nome")} · ${FinanceMath.money(b.optDouble("valor"))}", color = NexoColors.text, fontWeight = FontWeight.Bold)
                        Muted("Vence todo dia ${b.optInt("dia")} · " + if (paid) "✅ paga este mês" else "⏳ em aberto")
                    }
                    if (!paid) TextButton(onClick = {
                        store.update(LifeStore.BILLS, b.optString("id")) { it.put("pagas", (it.optString("pagas") + ",$month").trim(',')) }
                        store.add(LifeStore.TX, JSONObject().put("tipo", "gasto").put("valor", b.optDouble("valor")).put("categoria", "contas").put("descricao", b.optString("nome")).put("data", LifeStore.today()))
                    }) { Text("Paguei") }
                    TextButton(onClick = { store.remove(LifeStore.BILLS, b.optString("id")) }) { Text("✕", color = NexoColors.muted) }
                }
            }
        }
        item {
            GlassCard {
                SectionLabel("NOVA CONTA")
                Field(bName, { bName = it }, "Nome (luz, água, aluguel…)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(bValue, { bValue = it }, "Valor", number = true, modifier = Modifier.weight(1f))
                    Field(bDay, { bDay = it }, "Dia", number = true, modifier = Modifier.weight(1f))
                }
                Button(onClick = {
                    store.add(LifeStore.BILLS, JSONObject().put("nome", bName).put("valor", FinanceMath.parseMoney(bValue) ?: 0.0).put("dia", bDay.toIntOrNull() ?: 1).put("pagas", ""))
                    bName = ""; bValue = ""; bDay = ""
                }, enabled = bName.isNotBlank() && (bDay.toIntOrNull() ?: 0) in 1..31, modifier = Modifier.fillMaxWidth()) { Text("Adicionar conta") }
            }
        }
        item { SectionLabel("DÍVIDAS · ORDEM SUGERIDA (MAIORES JUROS PRIMEIRO)") }
        if (debts.isEmpty()) item { Empty("Nenhuma dívida registrada.") }
        items(debts, key = { it.optString("id") }) { d ->
            val months = FinanceMath.monthsToPay(d.optDouble("total"), d.optDouble("parcela"), d.optDouble("juros"))
            GlassCard {
                Text("${d.optString("credor")} · ${FinanceMath.money(d.optDouble("total"))}", color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted("Juros ${d.optDouble("juros")}% a.m. · parcela ${FinanceMath.money(d.optDouble("parcela"))}")
                Text(
                    when {
                        d.optDouble("parcela") <= 0 -> "Sem parcela informada."
                        months == null -> "⚠️ A parcela não cobre os juros: a dívida cresce. Priorize negociar esta."
                        else -> "Quitação em cerca de $months meses no ritmo atual."
                    },
                    color = if (months == null && d.optDouble("parcela") > 0) HoloOrange else NexoColors.text, fontSize = 12.sp,
                )
                Row {
                    TextButton(onClick = {
                        busy = "Preparando a negociação…"
                        scope.launch {
                            message = runCatching { coach.negotiation(d.optString("credor"), d.optDouble("total"), d.optDouble("parcela"), d.optDouble("juros")) }
                                .getOrElse { "❌ ${it.message}" }
                            busy = ""
                        }
                    }, enabled = busy.isBlank()) { Text("🤖 Mensagem para negociar") }
                    TextButton(onClick = { store.remove(LifeStore.DEBTS, d.optString("id")) }) { Text("Quitada / remover", color = NexoColors.muted) }
                }
            }
        }
        item { Busy(busy) }
        if (message.isNotBlank()) item { AiResult(message, "Negociação de dívida") }
        item {
            GlassCard {
                SectionLabel("NOVA DÍVIDA")
                Field(dName, { dName = it }, "Credor (cartão, banco, loja…)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(dTotal, { dTotal = it }, "Total", number = true, modifier = Modifier.weight(1f))
                    Field(dInst, { dInst = it }, "Parcela", number = true, modifier = Modifier.weight(1f))
                }
                Field(dRate, { dRate = it }, "Juros ao mês (%)", number = true)
                Button(onClick = {
                    store.add(LifeStore.DEBTS, JSONObject().put("credor", dName).put("total", FinanceMath.parseMoney(dTotal) ?: 0.0)
                        .put("parcela", FinanceMath.parseMoney(dInst) ?: 0.0).put("juros", FinanceMath.parseMoney(dRate) ?: 0.0))
                    dName = ""; dTotal = ""; dInst = ""; dRate = ""
                }, enabled = dName.isNotBlank() && FinanceMath.parseMoney(dTotal) != null, modifier = Modifier.fillMaxWidth()) { Text("Adicionar dívida") }
                Muted("Dica: nunca pague boleto ou Pix de contatos desconhecidos dizendo ser o credor. Negocie pelos canais oficiais.")
            }
        }
    }
}

// ============================ RENDA EXTRA ============================

@Composable
private fun IncomeTab() {
    val store = Container.life
    val coach = remember { MoneyCoach(store) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val v = store.version
    val profile = remember(v) { coach.profile() }
    var skills by remember { mutableStateOf(profile.optString("habilidades")) }
    var time by remember { mutableStateOf(profile.optString("tempo")) }
    var resources by remember { mutableStateOf(profile.optString("recursos")) }
    var avoid by remember { mutableStateOf(profile.optString("evitar")) }
    var ideas by remember { mutableStateOf<List<MoneyCoach.Opportunity>>(emptyList()) }
    var material by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf("") }
    val saved = remember(v) { store.list(LifeStore.OPPORTUNITIES) }
    val extraMonth = remember(v) { store.monthSummary().extraIncome }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            GlassCard {
                SectionLabel("RENDA EXTRA ESTE MÊS")
                Text(FinanceMath.money(extraMonth), color = NexoColors.green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Muted("Ideias realistas com o que você já tem. Sem apostas, pirâmides ou “tarefinhas que pagam”.")
            }
        }
        item {
            GlassCard {
                SectionLabel("SEU PERFIL (QUANTO MAIS DETALHE, MELHOR)")
                Field(skills, { skills = it }, "…Habilidades (ex.: operador industrial, crio apps e sites com IA)")
                Field(time, { time = it }, "Tempo livre por semana (ex.: 6 horas, à noite)")
                Field(resources, { resources = it }, "Recursos (celular, computador, moto, ferramentas…)")
                Field(avoid, { avoid = it }, "O que você NÃO quer fazer")
                Button(onClick = {
                    coach.saveProfile(coach.profile().put("habilidades", skills).put("tempo", time).put("recursos", resources).put("evitar", avoid))
                    busy = "Pensando nas melhores oportunidades para você…"
                    scope.launch {
                        val r = runCatching { coach.opportunities() }
                        ideas = r.getOrDefault(emptyList())
                        busy = if (r.isFailure) "❌ ${r.exceptionOrNull()?.message}" else if (ideas.isEmpty()) "A IA não devolveu ideias válidas. Tente de novo." else ""
                    }
                }, enabled = busy.isBlank() || busy.startsWith("❌") || busy.startsWith("A IA"), modifier = Modifier.fillMaxWidth()) { Text("🤖 Gerar oportunidades") }
                Busy(busy)
            }
        }
        items(ideas) { o ->
            GlassCard {
                Text(o.title, color = HoloCyan, fontWeight = FontWeight.Bold)
                Text("Hoje: ${o.firstStep}", color = NexoColors.text, fontSize = 13.sp)
                Muted("Retorno: ${o.expected} · Tempo: ${o.time} · Risco: ${o.risk}")
                Row {
                    TextButton(onClick = {
                        store.add(LifeStore.OPPORTUNITIES, JSONObject().put("titulo", o.title).put("primeiro_passo", o.firstStep)
                            .put("retorno", o.expected).put("tipo", o.kind).put("status", "começando").put("ganho", 0.0))
                        ideas = ideas - o
                    }) { Text("Quero fazer") }
                }
            }
        }
        item { SectionLabel("MINHAS OPORTUNIDADES") }
        if (saved.isEmpty()) item { Empty("Escolha uma ideia acima com “Quero fazer”.") }
        items(saved, key = { it.optString("id") }) { o ->
            var gain by remember { mutableStateOf("") }
            GlassCard {
                Text(o.optString("titulo"), color = NexoColors.text, fontWeight = FontWeight.Bold)
                Muted("Próximo passo: ${o.optString("primeiro_passo")}")
                Text("Já ganhou: ${FinanceMath.money(o.optDouble("ganho", 0.0))}", color = NexoColors.green, fontSize = 12.sp)
                Row {
                    TextButton(onClick = {
                        busy = "Preparando o material…"
                        scope.launch {
                            material = runCatching { coach.prepare(o, "proposta de serviço, mensagem de oferta para WhatsApp, post curto de divulgação e tabela de preços") }
                                .getOrElse { "❌ ${it.message}" }
                            busy = ""
                        }
                    }) { Text("🤖 Preparar material") }
                    if (o.optString("tipo") == "site") TextButton(onClick = {
                        busy = "Criando um site modelo no Estúdio…"
                        scope.launch {
                            val r = runCatching {
                                val (name, files) = Container.newCodeAssistant().scaffold("site de apresentação profissional para: ${o.optString("titulo")}. Página única, responsiva, com seções de serviços, contato por WhatsApp e preço.")
                                ProjectStore(ctx.applicationContext).createFromFiles(name, files)
                            }
                            busy = r.fold({ "✅ Projeto “$it” criado no Estúdio (COGNITIVE → ESTÚDIO)." }, { "❌ ${it.message}" })
                        }
                    }) { Text("Criar site") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(gain, { gain = it }, "Recebi (R$)", number = true, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val g = FinanceMath.parseMoney(gain) ?: return@TextButton
                        store.update(LifeStore.OPPORTUNITIES, o.optString("id")) { it.put("ganho", it.optDouble("ganho", 0.0) + g) }
                        store.add(LifeStore.TX, JSONObject().put("tipo", "entrada").put("valor", g).put("categoria", "renda extra").put("descricao", o.optString("titulo")).put("data", LifeStore.today()))
                        gain = ""
                    }) { Text("Registrar") }
                }
                TextButton(onClick = { store.remove(LifeStore.OPPORTUNITIES, o.optString("id")) }) { Text("Remover", color = NexoColors.muted) }
            }
        }
        if (material.isNotBlank()) item { AiResult(material, "Material de renda extra") }
    }
}

// ============================ METAS E LIMITES ============================

@Composable
private fun GoalsTab() {
    val store = Container.life
    val v = store.version
    val goals = remember(v) { store.list(LifeStore.GOALS) }
    val budgets = remember(v) { store.list(LifeStore.BUDGETS) }
    val sum = remember(v) { store.monthSummary() }
    var gTitle by remember { mutableStateOf("") }
    var gTarget by remember { mutableStateOf("") }
    var lCat by remember { mutableStateOf("mercado") }
    var lValue by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionLabel("METAS DE ECONOMIA") }
        if (goals.isEmpty()) item { Empty("Nenhuma meta. Ex.: “reserva de emergência — R$ 1.000”.") }
        items(goals, key = { it.optString("id") }) { g ->
            var add by remember { mutableStateOf("") }
            val frac = if (g.optDouble("alvo") > 0) (g.optDouble("guardado") / g.optDouble("alvo")).toFloat() else 0f
            GlassCard {
                Text(g.optString("titulo"), color = NexoColors.text, fontWeight = FontWeight.Bold)
                Text("${FinanceMath.money(g.optDouble("guardado"))} de ${FinanceMath.money(g.optDouble("alvo"))}", color = NexoColors.text, fontSize = 12.sp)
                Bar(frac, HoloBlue)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(add, { add = it }, "Guardei (R$)", number = true, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val a = FinanceMath.parseMoney(add) ?: return@TextButton
                        store.update(LifeStore.GOALS, g.optString("id")) { it.put("guardado", it.optDouble("guardado") + a) }
                        add = ""
                    }) { Text("Somar") }
                }
                TextButton(onClick = { store.remove(LifeStore.GOALS, g.optString("id")) }) { Text("Remover", color = NexoColors.muted) }
            }
        }
        item {
            GlassCard {
                Field(gTitle, { gTitle = it }, "Nova meta")
                Field(gTarget, { gTarget = it }, "Valor alvo (R$)", number = true)
                Button(onClick = {
                    store.add(LifeStore.GOALS, JSONObject().put("titulo", gTitle).put("alvo", FinanceMath.parseMoney(gTarget) ?: 0.0).put("guardado", 0.0))
                    gTitle = ""; gTarget = ""
                }, enabled = gTitle.isNotBlank() && FinanceMath.parseMoney(gTarget) != null, modifier = Modifier.fillMaxWidth()) { Text("Criar meta") }
            }
        }
        item { SectionLabel("LIMITES POR CATEGORIA") }
        items(budgets, key = { it.optString("id") }) { b ->
            val spent = sum.byCategory.firstOrNull { it.first.equals(b.optString("categoria"), true) }?.second ?: 0.0
            val use = FinanceMath.budgetUse(spent, b.optDouble("limite"))
            GlassCard {
                Row { Text(b.optString("categoria"), color = NexoColors.text, modifier = Modifier.weight(1f)); Text("$use%", color = if (use >= 80) NexoColors.red else NexoColors.green) }
                Muted("${FinanceMath.money(spent)} de ${FinanceMath.money(b.optDouble("limite"))}")
                Bar(use / 100f, if (use >= 80) NexoColors.red else HoloCyan)
                TextButton(onClick = { store.remove(LifeStore.BUDGETS, b.optString("id")) }) { Text("Remover", color = NexoColors.muted) }
            }
        }
        item {
            GlassCard {
                Chips(CATEGORIES, lCat) { lCat = it }
                Field(lValue, { lValue = it }, "Limite por mês (R$)", number = true)
                Button(onClick = {
                    store.save(LifeStore.BUDGETS, store.list(LifeStore.BUDGETS).filter { it.optString("categoria") != lCat } +
                        JSONObject().put("id", lCat).put("categoria", lCat).put("limite", FinanceMath.parseMoney(lValue) ?: 0.0))
                    lValue = ""
                }, enabled = FinanceMath.parseMoney(lValue) != null, modifier = Modifier.fillMaxWidth()) { Text("Definir limite") }
            }
        }
    }
}

@Composable
private fun OutlinedButtonRow(label: String, onClick: () -> Unit) {
    androidx.compose.material3.OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(label) }
}
