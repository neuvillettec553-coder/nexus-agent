package com.jeconias.nexo.mcp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

data class McpServerConfig(val id: String, val nome: String, val url: String, val token: String)
data class McpToolInfo(val name: String, val description: String, val inputSchema: JSONObject)

/**
 * Cliente MCP (Model Context Protocol) por HTTP ("Streamable HTTP").
 * No celular só servidores REMOTOS funcionam (os que rodam por linha de comando não).
 */
class McpClient(private val config: McpServerConfig, private val http: OkHttpClient) {
    private var sessionId: String? = null
    private var nextId = 1

    private suspend fun rpc(method: String, params: JSONObject?, notification: Boolean = false): JSONObject? =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("jsonrpc", "2.0").put("method", method)
            if (params != null) body.put("params", params)
            val id = nextId++
            if (!notification) body.put("id", id)

            val builder = Request.Builder()
                .url(config.url)
                .header("Accept", "application/json, text/event-stream")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
            if (config.token.isNotBlank()) builder.header("Authorization", "Bearer ${config.token}")
            sessionId?.let { builder.header("Mcp-Session-Id", it) }

            http.newCall(builder.build()).execute().use { resp ->
                resp.header("Mcp-Session-Id")?.let { sessionId = it }
                val txt = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw Exception("MCP ${config.nome} HTTP ${resp.code}: ${txt.take(200)}")
                if (notification) return@use null
                val json = if ((resp.header("Content-Type") ?: "").contains("event-stream")) {
                    txt.lineSequence()
                        .filter { it.startsWith("data:") }
                        .map { it.removePrefix("data:").trim() }
                        .mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
                        .firstOrNull { it.optInt("id", -1) == id }
                        ?: throw Exception("MCP ${config.nome}: resposta vazia")
                } else JSONObject(txt)
                json.optJSONObject("error")?.let { throw Exception("MCP ${config.nome}: ${it.optString("message")}") }
                json.optJSONObject("result") ?: JSONObject()
            }
        }

    suspend fun connect(): List<McpToolInfo> {
        rpc(
            "initialize",
            JSONObject()
                .put("protocolVersion", "2025-06-18")
                .put("capabilities", JSONObject())
                .put("clientInfo", JSONObject().put("name", "NEXO").put("version", "1.0"))
        )
        rpc("notifications/initialized", null, notification = true)
        val result = rpc("tools/list", JSONObject()) ?: JSONObject()
        val arr = result.optJSONArray("tools") ?: return emptyList()
        return (0 until arr.length()).map {
            val t = arr.getJSONObject(it)
            McpToolInfo(
                t.getString("name"),
                t.optString("description", ""),
                t.optJSONObject("inputSchema") ?: JSONObject().put("type", "object").put("properties", JSONObject())
            )
        }
    }

    suspend fun call(tool: String, args: JSONObject): Pair<Boolean, String> {
        val r = rpc("tools/call", JSONObject().put("name", tool).put("arguments", args)) ?: JSONObject()
        val content = r.optJSONArray("content")
        val text = buildString {
            if (content != null) for (i in 0 until content.length()) {
                val c = content.getJSONObject(i)
                if (c.optString("type") == "text") append(c.optString("text")).append('\n')
                else append("[${c.optString("type")}]\n")
            }
        }.trim()
        return !r.optBoolean("isError", false) to text.ifBlank { r.toString().take(2000) }
    }
}
