package com.jeconias.nexo.tools.builtin

import android.content.Context
import com.jeconias.nexo.context.ContextStore
import com.jeconias.nexo.context.SkillStore
import com.jeconias.nexo.scheduler.RoutineStore
import com.jeconias.nexo.tools.ToolRegistry
import okhttp3.OkHttpClient

/** Registra todas as ferramentas nativas do NEXO num lugar só. */
object BuiltinTools {
    fun registerAll(
        registry: ToolRegistry,
        ctx: Context,
        context: ContextStore,
        skills: SkillStore,
        routines: RoutineStore,
        http: OkHttpClient,
    ) {
        // Memória e organização
        registry.register(DataHoraTool())
        registry.register(LembrarTool(context))
        registry.register(SalvarNotaTool(ctx))
        registry.register(ListarNotasTool(ctx))
        registry.register(AnotarTool(ctx))
        registry.register(LerSkillTool(skills))
        registry.register(SalvarSkillTool(skills))
        // Celular
        registry.register(AbrirAppTool(ctx))
        registry.register(ListarAppsTool(ctx))
        registry.register(CriarAlarmeTool(ctx))
        registry.register(AbrirLinkTool(ctx))
        registry.register(CompartilharTextoTool(ctx))
        registry.register(WhatsappTool(ctx))
        // Programação
        registry.register(ExecutarCodigoTool(ctx))
        // Internet
        registry.register(BuscarWebTool(http))
        registry.register(LerPaginaTool(http))
        // Tempo
        registry.register(CriarLembreteTool(ctx))
        registry.register(AgendarRotinaTool(routines))
        registry.register(ListarRotinasTool(routines))
        registry.register(CancelarRotinaTool(routines))
    }
}
