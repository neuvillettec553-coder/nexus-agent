package com.jeconias.nexo.ui.deck

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.core.Metrics
import com.jeconias.nexo.ui.ChatViewModel
import com.jeconias.nexo.ui.Phase
import com.jeconias.nexo.ui.holo.CognitiveCore
import com.jeconias.nexo.ui.holo.EvolutionChart
import com.jeconias.nexo.ui.holo.HoloBlue
import com.jeconias.nexo.ui.holo.HoloCyan
import com.jeconias.nexo.ui.holo.HoloOrange
import com.jeconias.nexo.ui.holo.IntegrationRing
import com.jeconias.nexo.ui.holo.LocalProjector
import com.jeconias.nexo.ui.holo.ModelingGraph
import com.jeconias.nexo.ui.holo.Projection
import com.jeconias.nexo.ui.hud.FlowScreen
import com.jeconias.nexo.ui.hud.rememberTilt
import com.jeconias.nexo.ui.rememberVoiceInput
import com.jeconias.nexo.ui.screens.BrainScreen
import com.jeconias.nexo.ui.screens.ChatScreen
import com.jeconias.nexo.ui.screens.DiagnosticsCard
import com.jeconias.nexo.ui.studio.StudioScreen
import com.jeconias.nexo.ui.theme.Muted
import com.jeconias.nexo.ui.theme.NexoColors
import kotlinx.coroutines.delay

/** Nós da rede PREDICTIVE MODELING: Motor Local, IAs ativas e Ações. */
fun modelNodes(): List<String> {
    val c = Container.connectors
    val connectors = buildList {
        if (c.googleConnected()) add("GMAIL")
        if (c.githubToken().isNotBlank()) add("GITHUB")
        if (Container.mcp.servers().isNotEmpty()) add("MCP")
    }
    return listOf("LOCAL") + Container.router.activeProviders().take(4).map { it.info.name.substringBefore(" ") } + connectors + listOf("AÇÕES")
}

/** Qual nó está trabalhando agora, pelo último evento do FLUXO. */
fun activeNode(nodes: List<String>, busy: Boolean): Int? {
    if (!busy) return null
    val e = FlowLog.eventsOf(FlowLog.currentId).lastOrNull() ?: return null
    return when (e.stage) {
        "MOTOR LOCAL" -> 0
        "AÇÃO", "CONFIRMAÇÃO" -> nodes.lastIndex
        else -> nodes.indexOfFirst { n -> e.who.startsWith(n, ignoreCase = true) || e.who.contains(n, ignoreCase = true) }.takeIf { it >= 0 }
    }
}

@Composable
fun CognitiveDeck(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val projector = LocalProjector.current
    val tilt = rememberTilt()
    val listen = rememberVoiceInput(vm)
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(10_000); tick++ } }

    val version = Metrics.version
    val autonomy = remember(version, tick) { Metrics.autonomy() }
    val adaptation = remember(version, tick) { Metrics.adaptation() }
    val integration = remember(version, tick) { Metrics.integration(ctx) }
    val evolution = remember(version, tick) { Metrics.evolution() }
    val nodes = remember(tick) { modelNodes() }
    val active = activeNode(nodes, vm.busy)

    fun openChat() = projector.project(Projection("Conversa", HoloCyan) { ChatScreen(vm, onBack = { projector.close() }) })
    fun openEvolution() = projector.project(Projection("AI Behavioral Evolution", HoloOrange) { EvolutionPanel(evolution, autonomy, adaptation) })

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            DeckHeader(
                "ADVANCED AI COGNITIVE CORE", "REAL-TIME BEHAVIORAL PROGRESSION",
                "Autonomy" to "$autonomy%", "Adaptation" to "$adaptation%",
            )
            // Núcleo + painel flutuante de evolução
            Box(Modifier.fillMaxWidth().height(270.dp)) {
                CognitiveCore(
                    vm.phase,
                    Modifier.size(250.dp).align(Alignment.Center)
                        .graphicsLayer {
                            rotationX = tilt.y * 12f
                            rotationY = -tilt.x * 12f
                            cameraDistance = 16f * density
                        }
                        .clickable(remember { MutableInteractionSource() }, null) { listen() },
                )
                HoloTile(
                    "EVOLUTION", tilt,
                    Modifier.align(Alignment.BottomEnd).padding(end = 6.dp).size(width = 130.dp, height = 84.dp)
                        .graphicsLayer { rotationY = -22f; cameraDistance = 12f * density },
                    accent = HoloOrange, depth = 1.6f, onClick = { openEvolution() },
                ) { EvolutionChart(evolution, Modifier.fillMaxSize(), compact = true) }
            }
            Text(
                vm.phase.label, color = if (vm.phase == Phase.IDLE) HoloCyan else HoloOrange, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 4.sp, fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
            Text(
                vm.status.ifBlank { if (vm.phase == Phase.IDLE) "Toque no núcleo para falar" else "" },
                color = NexoColors.muted, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))

            // Atalhos holográficos
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HoloTile("CONVERSA", tilt, Modifier.weight(1f), onClick = { openChat() }) {
                    Text("💬", fontSize = 20.sp); Muted("${vm.messages.size} msgs")
                }
                HoloTile("ESTÚDIO", tilt, Modifier.weight(1f), accent = HoloOrange, onClick = {
                    projector.project(Projection("Estúdio", HoloOrange) { StudioScreen() })
                }) { Text("⌨️", fontSize = 20.sp); Muted("código") }
                HoloTile("CÉREBRO", tilt, Modifier.weight(1f), accent = HoloBlue, onClick = {
                    projector.project(Projection("Cérebro", HoloBlue) { BrainScreen() })
                }) { Text("🧠", fontSize = 20.sp); Muted("memória") }
            }
            Spacer(Modifier.height(8.dp))

            // Integração + modelagem preditiva
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HoloTile("SYSTEM INTEGRATION", tilt, Modifier.weight(1f), accent = HoloOrange, depth = 0.8f, onClick = {
                    projector.project(Projection("System Integration", HoloOrange) { IntegrationPanel(integration) })
                }) { IntegrationRing(integration.percent, Modifier.fillMaxWidth().height(110.dp)) }
                HoloTile("PREDICTIVE MODELING", tilt, Modifier.weight(1f), accent = HoloCyan, depth = 1.2f, onClick = {
                    projector.project(Projection("Fluxo", HoloCyan) { FlowScreen(onBack = { projector.close() }) })
                }) { ModelingGraph(nodes, active, Modifier.fillMaxWidth().height(110.dp)) }
            }
            StatusLine(if (integration.percent >= 50) "ACTIVE" else "ATENÇÃO", integration.percent >= 50)
            Spacer(Modifier.height(6.dp))
        }
        Dock(vm, listen, onOpenChat = { openChat() })
    }
}

@Composable
fun EvolutionPanel(points: List<Metrics.Point>, autonomy: Int, adaptation: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row {
            MetricBox("Adaptation", "$adaptation%", HoloBlue)
            Spacer(Modifier.weight(1f))
            MetricBox("Autonomy", "$autonomy%", HoloOrange)
        }
        EvolutionChart(points, Modifier.fillMaxWidth().height(240.dp))
        Text("● Azul — Adaptação: quanto o Alfredo já aprendeu (atalhos + fatos na memória).", color = HoloBlue, fontSize = 13.sp)
        Text("● Laranja — Autonomia: % dos pedidos dos últimos 7 dias resolvidos sozinho pelo Motor Local.", color = HoloOrange, fontSize = 13.sp)
        Muted(
            if (points.size < 2) "Coletando dados: o gráfico ganha forma a cada dia de uso."
            else "${points.size} dias registrados, de ${points.first().date} a ${points.last().date}."
        )
    }
}

@Composable
fun IntegrationPanel(integration: Metrics.Integration) {
    androidx.compose.foundation.lazy.LazyColumn(
        contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { IntegrationRing(integration.percent, Modifier.fillMaxWidth().height(160.dp)) }
        item { Muted("Calculado com o estado real do celular. Cada item resolvido aumenta a integração.") }
        integration.items.forEach { (label, ok) ->
            item { Text((if (ok) "✅ " else "⬜ ") + label, color = NexoColors.text, fontSize = 14.sp) }
        }
        item { DiagnosticsCard() }
    }
}
