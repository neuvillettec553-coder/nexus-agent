package com.jeconias.nexo.studio

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Projetos do Estúdio, guardados no celular em files/projetos/<nome>/.
 * Cada vez que um arquivo é salvo, a versão anterior vai para .historico/ (até 30 por arquivo).
 */
class ProjectStore(ctx: Context) {
    data class Version(val file: File, val label: String)

    val root = File(ctx.filesDir, "projetos").apply { mkdirs() }

    fun projects(): List<String> =
        root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }?.map { it.name } ?: emptyList()

    fun dir(project: String) = File(root, safeName(project))

    fun create(name: String, template: Template): String {
        val n = uniqueName(safeName(name).ifBlank { "projeto" })
        val d = File(root, n).apply { mkdirs() }
        template.files.forEach { (path, content) -> write(n, path, content, keepHistory = false) }
        d.setLastModified(System.currentTimeMillis())
        return n
    }

    fun createFromFiles(name: String, files: Map<String, String>): String {
        val n = uniqueName(safeName(name).ifBlank { "projeto" })
        File(root, n).mkdirs()
        files.forEach { (path, content) -> write(n, path, content, keepHistory = false) }
        return n
    }

    fun delete(project: String) = dir(project).deleteRecursively()

    /** Caminhos relativos de todos os arquivos (sem o histórico). */
    fun files(project: String): List<String> {
        val base = dir(project)
        return base.walkTopDown()
            .filter { it.isFile && !it.relativeTo(base).path.startsWith(".historico") && !it.relativeTo(base).path.startsWith(".nexo") }
            .map { it.relativeTo(base).path }
            .sorted()
            .toList()
    }

    fun read(project: String, path: String): String {
        val f = resolve(project, path)
        return if (f.exists()) f.readText() else ""
    }

    fun write(project: String, path: String, content: String, keepHistory: Boolean = true) {
        val f = resolve(project, path)
        if (keepHistory && f.exists() && f.readText() != content) {
            val hist = historyDir(project, path).apply { mkdirs() }
            File(hist, System.currentTimeMillis().toString()).writeText(f.readText())
            hist.listFiles()?.sortedByDescending { it.name }?.drop(MAX_VERSIONS)?.forEach { it.delete() }
        }
        f.parentFile?.mkdirs()
        f.writeText(content)
        dir(project).setLastModified(System.currentTimeMillis())
    }

    fun newFile(project: String, path: String): Boolean {
        val f = resolve(project, path)
        if (f.exists()) return false
        f.parentFile?.mkdirs()
        return f.createNewFile()
    }

    fun deleteFile(project: String, path: String): Boolean = resolve(project, path).delete()

    fun rename(project: String, from: String, to: String): Boolean {
        val target = resolve(project, to)
        if (target.exists()) return false
        target.parentFile?.mkdirs()
        return resolve(project, from).renameTo(target)
    }

    fun history(project: String, path: String): List<Version> {
        val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale("pt", "BR"))
        return historyDir(project, path).listFiles()
            ?.sortedByDescending { it.name }
            ?.map { Version(it, fmt.format(Date(it.name.toLongOrNull() ?: it.lastModified()))) }
            ?: emptyList()
    }

    /** Todos os arquivos de texto do projeto (para rodar Python com vários arquivos e para a IA ler). */
    fun allContents(project: String, maxChars: Int = 200_000): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        var total = 0
        for (p in files(project)) {
            val text = read(project, p)
            if (total + text.length > maxChars) break
            out[p] = text
            total += text.length
        }
        return out
    }

    suspend fun exportZip(ctx: Context, project: String, uri: Uri) = withContext(Dispatchers.IO) {
        val base = dir(project)
        ctx.contentResolver.openOutputStream(uri, "w")?.use { os ->
            ZipOutputStream(os).use { zip ->
                for (p in files(project)) {
                    zip.putNextEntry(ZipEntry("${base.name}/$p"))
                    zip.write(File(base, p).readBytes())
                    zip.closeEntry()
                }
            }
        } ?: throw IllegalStateException("Não consegui gravar o arquivo.")
    }

    /** Conversa do construtor (pedidos e respostas), guardada dentro do projeto. */
    fun conversation(project: String): List<Pair<String, String>> {
        val f = File(dir(project), ".nexo/conversa.json")
        if (!f.exists()) return emptyList()
        val arr = runCatching { org.json.JSONArray(f.readText()) }.getOrDefault(org.json.JSONArray())
        return (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.optString("quem") to o.optString("texto") } }
    }

    fun addConversation(project: String, who: String, text: String) {
        val f = File(dir(project), ".nexo/conversa.json").apply { parentFile?.mkdirs() }
        val arr = runCatching { org.json.JSONArray(f.readText()) }.getOrDefault(org.json.JSONArray())
        arr.put(org.json.JSONObject().put("quem", who).put("texto", text.take(4000)))
        while (arr.length() > 60) arr.remove(0)
        f.writeText(arr.toString())
    }

    private fun resolve(project: String, path: String): File {
        val base = dir(project).canonicalFile
        val f = File(base, path.trimStart('/')).canonicalFile
        require(f.path.startsWith(base.path)) { "Caminho fora do projeto." }
        return f
    }

    private fun historyDir(project: String, path: String) =
        File(dir(project), ".historico/" + path.replace('/', '_'))

    private fun uniqueName(base: String): String {
        var n = base
        var i = 2
        while (File(root, n).exists()) n = "$base-${i++}"
        return n
    }

    companion object {
        const val MAX_VERSIONS = 30
        fun safeName(name: String): String =
            name.trim().replace(Regex("[^\\p{L}0-9 _.-]"), "").replace(Regex("\\s+"), "-").take(40)
    }
}
