package com.jeconias.nexo.context

import android.content.Context
import java.io.File

/**
 * Skills = rotinas de passos salvas em Markdown (uma por arquivo).
 * A primeira linha "# Nome — descrição" vira o resumo que a IA vê.
 */
class SkillStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "skills").apply { mkdirs() }

    init {
        if (dir.listFiles().isNullOrEmpty()) {
            ctx.assets.list("skills")?.forEach { name ->
                ctx.assets.open("skills/$name").use { input ->
                    File(dir, name).outputStream().use { input.copyTo(it) }
                }
            }
        }
    }

    fun names(): List<String> =
        dir.listFiles()?.filter { it.extension == "md" }?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()

    fun read(name: String): String? {
        val f = File(dir, slug(name) + ".md")
        return if (f.exists()) f.readText() else null
    }

    fun save(name: String, content: String): String {
        val s = slug(name)
        File(dir, "$s.md").writeText(content)
        return s
    }

    fun delete(name: String): Boolean = File(dir, slug(name) + ".md").delete()

    fun index(): String = names().joinToString("\n") { n ->
        val first = read(n)?.lineSequence()?.firstOrNull { it.isNotBlank() }?.removePrefix("#")?.trim() ?: n
        "- $n: $first"
    }

    private fun slug(name: String): String =
        java.text.Normalizer.normalize(name.lowercase().trim(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "")
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .ifBlank { "skill" }
}
