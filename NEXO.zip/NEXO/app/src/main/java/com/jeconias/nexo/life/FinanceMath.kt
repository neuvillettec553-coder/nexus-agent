package com.jeconias.nexo.life

import java.util.Calendar
import kotlin.math.max

/**
 * Cálculos financeiros PUROS (sem Android): testados automaticamente a cada compilação.
 */
object FinanceMath {
    data class Tx(val date: String, val type: String, val value: Double, val category: String)
    data class Debt(val creditor: String, val total: Double, val installment: Double, val monthlyRate: Double)
    data class Summary(
        val income: Double,
        val expense: Double,
        val balance: Double,
        val byCategory: List<Pair<String, Double>>,
        val extraIncome: Double,
    )

    /** Resumo de um mês ("yyyy-MM"). Entradas de "renda extra" também contam como entrada. */
    fun summary(txs: List<Tx>, month: String): Summary {
        val m = txs.filter { it.date.startsWith(month) }
        val income = m.filter { it.type == "entrada" }.sumOf { it.value }
        val expense = m.filter { it.type == "gasto" }.sumOf { it.value }
        val extra = m.filter { it.type == "entrada" && it.category.equals("renda extra", ignoreCase = true) }.sumOf { it.value }
        val byCat = m.filter { it.type == "gasto" }.groupBy { it.category.ifBlank { "outros" } }
            .map { (k, v) -> k to v.sumOf { it.value } }.sortedByDescending { it.second }
        return Summary(income, expense, income - expense, byCat, extra)
    }

    /**
     * Previsão do fim do mês: saldo atual, menos o ritmo médio de gastos nos dias que faltam,
     * menos as contas ainda não pagas.
     */
    fun forecast(summary: Summary, dayOfMonth: Int, daysInMonth: Int, unpaidBills: Double): Double {
        val day = dayOfMonth.coerceIn(1, daysInMonth)
        val dailyPace = summary.expense / day
        val remainingDays = daysInMonth - day
        return summary.balance - dailyPace * remainingDays - unpaidBills
    }

    /** Ordem sugerida para quitar dívidas: maiores juros primeiro (economiza mais dinheiro). */
    fun avalanche(debts: List<Debt>): List<Debt> = debts.sortedWith(compareByDescending<Debt> { it.monthlyRate }.thenBy { it.total })

    /** Alternativa motivacional: menores dívidas primeiro (vitórias rápidas). */
    fun snowball(debts: List<Debt>): List<Debt> = debts.sortedBy { it.total }

    /** Meses para quitar uma dívida com juros mensais e parcela fixa. null = a parcela não cobre os juros. */
    fun monthsToPay(total: Double, installment: Double, monthlyRatePercent: Double): Int? {
        if (installment <= 0) return null
        var balance = total
        val r = monthlyRatePercent / 100.0
        var months = 0
        while (balance > 0.005 && months < 600) {
            balance = balance * (1 + r) - installment
            months++
            if (months == 1 && balance >= total) return null
        }
        return if (months >= 600) null else months
    }

    /** % do limite usado em cada categoria. */
    fun budgetUse(spent: Double, limit: Double): Int = if (limit <= 0) 0 else (spent / limit * 100).toInt()

    fun currentMonth(): String {
        val c = Calendar.getInstance()
        return "%04d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)
    }

    fun money(v: Double): String {
        val s = "%,.2f".format(java.util.Locale("pt", "BR"), kotlin.math.abs(v))
        return (if (v < 0) "-R$ " else "R$ ") + s
    }

    /** Lê valores falados/escritos: "45", "45,90", "R$ 1.200,50", "1200.5". */
    fun parseMoney(text: String): Double? {
        var t = text.replace("R$", "").replace(" ", "").trim()
        if (t.isEmpty()) return null
        t = if (t.contains(",")) t.replace(".", "").replace(",", ".") else t
        return t.toDoubleOrNull()?.takeIf { it >= 0 }
    }

    fun max0(v: Double) = max(0.0, v)
}
