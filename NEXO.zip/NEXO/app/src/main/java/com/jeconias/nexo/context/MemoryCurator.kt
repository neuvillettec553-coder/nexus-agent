package com.jeconias.nexo.context

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.providers.ChatMessage
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Revisão semanal da memória (a "Evolução" do Alfredo antigo):
 * junta fatos repetidos, remove o que ficou velho ou contraditório e mantém tudo organizado por assunto.
 * Antes de mexer, guarda uma cópia (MEMORY.anterior.md) para poder voltar.
 */
object MemoryCurator {
    suspend fun curate(ctx: Context): String {
        val store = Container.context
        val original = store.readMemory()
        val facts = original.lines().count { it.trimStart().startsWith("- [") }
        if (facts < 15) return "Memória pequena (${facts} fatos): nada para revisar ainda."
        val prompt = """
            Abaixo está o MEMORY.md do assistente. Reorganize-o:
            - mantenha o título e as seções "## Pessoas", "## Preferências", "## Lugares", "## Rotina", "## Finanças", "## Regras", "## Outros";
            - mova cada fato para a seção certa; junte fatos repetidos (mantenha a data mais recente);
            - quando dois fatos se contradizem, fique só com o mais recente;
            - NÃO invente nada, NÃO apague correções nem regras dadas pelo usuário;
            - no máximo 200 linhas. Responda SOMENTE com o arquivo completo em Markdown.

            $original
        """.trimIndent()
        val t0 = System.currentTimeMillis()
        val r = Container.router.chat(listOf(ChatMessage("user", prompt)), emptyList())
        val result = r.text.replace(Regex("(?s)<think>.*?</think>"), "").replace(Regex("^```(?:markdown)?\\s*|\\s*```$"), "").trim()
        val newFacts = result.lines().count { it.trimStart().startsWith("- [") }
        // Proteção: se a IA "comeu" fatos demais ou devolveu algo estranho, não aplica.
        if (!result.contains("#") || newFacts < facts * 0.5) {
            FlowLog.add("MEMÓRIA", r.providerName, "Revisão descartada por segurança ($newFacts de $facts fatos).", ok = false)
            return "Revisão descartada por segurança: a IA reduziu demais a memória."
        }
        File(store.memoryFile.parentFile, "MEMORY.anterior.md").writeText(original)
        store.saveMemory(result)
        FlowLog.add("MEMÓRIA", r.providerName, "Memória reorganizada: $facts → $newFacts fatos.", System.currentTimeMillis() - t0)
        return "Memória reorganizada: $facts → $newFacts fatos. A versão anterior foi guardada."
    }

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<MemoryCuratorWorker>(7, TimeUnit.DAYS).setInitialDelay(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("revisao_memoria", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class MemoryCuratorWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Container.init(applicationContext)
        return try { MemoryCurator.curate(applicationContext); Result.success() } catch (_: Exception) { Result.retry() }
    }
}
