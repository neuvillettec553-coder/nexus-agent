package com.jeconias.nexo.agent

import com.jeconias.nexo.context.ContextStore
import com.jeconias.nexo.context.SkillStore
import com.jeconias.nexo.core.ActionLog
import com.jeconias.nexo.core.FlowLog
import com.jeconias.nexo.core.Settings
import com.jeconias.nexo.providers.ChatMessage
import com.jeconias.nexo.providers.ProviderRouter
import com.jeconias.nexo.providers.ToolCall
import com.jeconias.nexo.tools.Level
import com.jeconias.nexo.tools.Tool
import com.jeconias.nexo.tools.ToolRegistry
import com.jeconias.nexo.tools.ToolResult
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

/** O que está acontecendo agora, para a tela mostrar. */
sealed class AgentEvent {
    data class Thinking(val step: Int) : AgentEvent()
    data class Acting(val tool: String) : AgentEvent()
    data class ActionDone(val tool: String, val ok: Boolean) : AgentEvent()
    data class Council(val stage: String) : AgentEvent()
    data object Local : AgentEvent()
}

/** Pergunta ao usuário se pode executar uma ação sensível. null = ninguém para perguntar (rotina). */
typealias Confirmer = suspend (String) -> Boolean

/**
 * Loop do agente: OBSERVAR -> PENSAR -> AGIR -> AVALIAR.
 * Duas falhas seguidas = para e pergunta. Ações sensíveis só com a sua confirmação.
 */
class AgentLoop(
    private val router: ProviderRouter,
    private val tools: ToolRegistry,
    private val context: ContextStore,
    private val skills: SkillStore,
    private val settings: Settings,
) {
    var lastProvider: String = ""
        private set

    /** Ações executadas na última execução (o Motor Local aprende com elas). */
    var lastRunActions: List<Pair<ToolCall, ToolResult>> = emptyList()
        private set

    suspend fun run(
        history: MutableList<ChatMessage>,
        userText: String,
        onEvent: (AgentEvent) -> Unit = {},
        confirm: Confirmer? = null,
        extraSystem: String? = null,
    ): String {
        val actions = mutableListOf<Pair<ToolCall, ToolResult>>()
        lastRunActions = actions
        var sysText = context.systemPrompt(skills.index(), settings.userName(), settings.city())
        if (extraSystem != null) sysText += "\n\n---\n$extraSystem"
        val system = ChatMessage("system", sysText)
        history.add(ChatMessage("user", userText))
        var consecutiveFailures = 0
        // Só as ferramentas que fazem sentido para este pedido (respostas mais rápidas).
        val recentText = history.takeLast(6).filter { it.role == "user" }.joinToString(" ") { it.content } + " " + (extraSystem ?: "")
        val usedBefore = history.flatMap { m -> m.toolCalls.map { it.name } }
        val allowed = ToolSelector.select(recentText, tools.all().map { it.name }, usedBefore)
        val specs = tools.specs().filter { it.name in allowed }

        for (step in 1..MAX_STEPS) {
            onEvent(AgentEvent.Thinking(step))
            val t0 = System.currentTimeMillis()
            val response = router.chat(listOf(system) + trimmed(history), specs)
            val ms = System.currentTimeMillis() - t0
            lastProvider = "${response.providerName} · ${response.model}"

            if (response.toolCalls.isEmpty()) {
                val text = clean(response.text).ifBlank { "Pronto." }
                FlowLog.add("AGENTE", response.providerName, "Resposta: $text", ms)
                history.add(ChatMessage("assistant", text))
                return text
            }

            FlowLog.add("AGENTE", response.providerName, "Decidiu usar: " + response.toolCalls.joinToString { it.name }, ms)
            history.add(ChatMessage("assistant", response.text, response.toolCalls))
            for (call in response.toolCalls) {
                onEvent(AgentEvent.Acting(call.name))
                val t1 = System.currentTimeMillis()
                val result = execute(call, confirm)
                actions.add(call to result)
                ActionLog.add(call.name, call.argumentsJson, result.ok, result.output)
                FlowLog.add("AÇÃO", call.name, result.output.take(300), System.currentTimeMillis() - t1, result.ok)
                onEvent(AgentEvent.ActionDone(call.name, result.ok))
                val prefix = when {
                    result.refused -> "NÃO AUTORIZADO: "
                    result.ok -> "SUCESSO: "
                    else -> "FALHOU: "
                }
                history.add(ChatMessage("tool", prefix + result.output.take(6000), toolCallId = call.id, toolName = call.name))
                consecutiveFailures = when {
                    result.ok || result.refused -> 0
                    else -> consecutiveFailures + 1
                }
            }
            if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                return stopAndAsk(system, history)
            }
        }
        val msg = "Parei depois de $MAX_STEPS passos sem terminar, para não ficar em loop. Me diga como prefere seguir."
        history.add(ChatMessage("assistant", msg))
        return msg
    }

    /** Executa uma ferramenta respeitando o nível de confirmação. Usado também pelo Motor Local. */
    suspend fun execute(call: ToolCall, confirm: Confirmer?): ToolResult {
        val tool = tools.get(call.name) ?: return ToolResult(false, "A ferramenta '${call.name}' não existe.")
        val args = try {
            JSONObject(call.argumentsJson.ifBlank { "{}" })
        } catch (_: Exception) {
            return ToolResult(false, "Argumentos inválidos: ${call.argumentsJson.take(200)}")
        }
        if (tool.level == Level.SENSITIVE) {
            if (confirm == null) {
                return ToolResult(false, "Esta ação precisa da confirmação do usuário e ele não está presente. Não executei.", refused = true)
            }
            FlowLog.add("CONFIRMAÇÃO", tool.name, "Pedindo sua autorização…")
            val allowed = confirm(describe(tool, args))
            FlowLog.add("CONFIRMAÇÃO", tool.name, if (allowed) "Autorizado por você" else "Recusado por você", ok = allowed)
            if (!allowed) return ToolResult(false, "O usuário NÃO autorizou. Não executei.", refused = true)
        }
        return try {
            tool.run(args)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ToolResult(false, "Erro: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun describe(tool: Tool, args: JSONObject): String = when (tool.name) {
        "whatsapp_mensagem" -> "Abrir o WhatsApp para ${args.optString("numero")} com a mensagem:\n“${args.optString("mensagem")}”"
        "compartilhar_texto" -> "Compartilhar este texto:\n“${args.optString("texto").take(300)}”"
        "cancelar_rotina" -> "Cancelar a rotina “${args.optString("id_ou_nome")}”"
        else -> "Usar “${tool.name}” com: ${args.toString().take(300)}"
    }

    private suspend fun stopAndAsk(system: ChatMessage, history: MutableList<ChatMessage>): String {
        history.add(
            ChatMessage(
                "user",
                "[SISTEMA] Duas ações seguidas falharam. PARE agora e não chame nenhuma ferramenta. " +
                    "Explique em poucas linhas o que tentou, o que deu errado e pergunte como o usuário prefere seguir."
            )
        )
        val fallback = "Tentei duas vezes e não deu certo, então parei para não ficar repetindo. " +
            "Veja os detalhes no painel FLUXO. Como você prefere seguir?"
        val text = try {
            clean(router.chat(listOf(system) + trimmed(history), tools.specs()).text).ifBlank { fallback }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            fallback
        }
        FlowLog.add("AGENTE", "regra de parada", "Duas falhas seguidas: parei e perguntei", ok = false)
        history.add(ChatMessage("assistant", text))
        return text
    }

    private fun trimmed(history: List<ChatMessage>): List<ChatMessage> {
        val tail = history.takeLast(MAX_HISTORY).toMutableList()
        while (tail.isNotEmpty() && tail.first().role != "user") tail.removeAt(0)
        return tail
    }

    private fun clean(text: String): String =
        text.replace(Regex("(?s)<think>.*?</think>"), "").trim()

    companion object {
        const val MAX_STEPS = 10
        const val MAX_CONSECUTIVE_FAILURES = 2
        const val MAX_HISTORY = 40
    }
}
