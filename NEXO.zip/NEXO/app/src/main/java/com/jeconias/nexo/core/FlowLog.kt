package com.jeconias.nexo.core

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * FLUXO: tudo o que acontece dentro do Alfredo para responder um pedido,
 * na ordem: Motor Local, Triagem, Estrategista, Crítico, Juiz, Agente, Ações.
 * É o que o painel FLUXO mostra ao vivo.
 */
object FlowLog {
    data class Event(
        val requestId: Int,
        val stage: String,
        val who: String,
        val text: String,
        val ms: Long,
        val ok: Boolean,
        val time: String,
    )

    data class Request(val id: Int, val question: String, val time: String)

    val events = mutableStateListOf<Event>()
    val requests = mutableStateListOf<Request>()
    private val counter = AtomicInteger(0)
    private val main = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale("pt", "BR"))

    @Volatile var currentId: Int = 0
        private set

    fun newRequest(question: String): Int {
        val id = counter.incrementAndGet()
        currentId = id
        val r = Request(id, question.take(200), fmt.format(Date()))
        main.post {
            requests.add(0, r)
            while (requests.size > 30) requests.removeAt(requests.size - 1)
            val keep = requests.map { it.id }.toSet()
            events.removeAll { it.requestId !in keep }
        }
        return id
    }

    fun add(stage: String, who: String, text: String, ms: Long = 0, ok: Boolean = true) {
        val e = Event(currentId, stage, who, text.trim().take(4000), ms, ok, fmt.format(Date()))
        main.post { events.add(e) }
    }

    fun eventsOf(requestId: Int): List<Event> = events.filter { it.requestId == requestId }
}
