package com.jeconias.nexo.core

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Registro de cada ação real que o agente executou: ferramenta, argumentos e resultado.
 * Lição do Alfredo: nada de "toquei" sem prova. Se não está aqui, não aconteceu.
 */
object ActionLog {
    data class Entry(val time: String, val tool: String, val args: String, val ok: Boolean, val output: String)

    val entries = mutableStateListOf<Entry>()
    private var file: File? = null
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale("pt", "BR"))

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "logs/acoes.log").apply { parentFile?.mkdirs() }
    }

    @Synchronized
    fun add(tool: String, args: String, ok: Boolean, output: String) {
        val e = Entry(fmt.format(Date()), tool, args.take(300), ok, output.take(500))
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            entries.add(0, e)
            while (entries.size > 100) entries.removeAt(entries.size - 1)
        }
        try {
            file?.appendText("[${e.time}] ${if (ok) "OK  " else "FALHA"} ${e.tool} ${e.args} => ${e.output.replace('\n', ' ')}\n")
        } catch (_: Exception) {
        }
    }
}
