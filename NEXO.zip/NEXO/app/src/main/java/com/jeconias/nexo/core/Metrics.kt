package com.jeconias.nexo.core

import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Métricas REAIS do painel (nada de número de enfeite):
 *  - Autonomia: % dos pedidos dos últimos 7 dias resolvidos pelo Motor Local, sem IA.
 *  - Adaptação: o quanto o Alfredo já aprendeu (atalhos + fatos na memória).
 *  - Integração: saúde do sistema (IAs, voz, notificações, bateria, backup, último diagnóstico).
 *  - Evolução: histórico diário de Adaptação e Autonomia (gráfico "AI Behavioral Evolution").
 */
object Metrics {
    enum class Kind { LOCAL, COUNCIL, AI, FAIL }

    private var prefs: SharedPreferences? = null
    private val main = Handler(Looper.getMainLooper())

    /** Muda sempre que algo é registrado: as telas observam isso para se atualizar. */
    var version by mutableIntStateOf(0)
        private set

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("nexo_metricas", Context.MODE_PRIVATE)
    }

    private fun day(offset: Int = 0): String {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -offset) }
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }

    private fun days(): JSONObject = JSONObject(prefs?.getString("dias", "{}") ?: "{}")

    @Synchronized
    fun record(kind: Kind) {
        val p = prefs ?: return
        val all = days()
        val d = day()
        val o = all.optJSONObject(d) ?: JSONObject()
        o.put("total", o.optInt("total") + 1)
        val k = kind.name.lowercase()
        o.put(k, o.optInt(k) + 1)
        all.put(d, o)
        p.edit().putString("dias", all.toString()).apply()
        snapshot()
        main.post { version++ }
    }

    /** % de pedidos resolvidos pelo Motor Local nos últimos 7 dias. */
    fun autonomy(): Int {
        val all = days()
        var total = 0
        var local = 0
        for (i in 0 until 7) {
            val o = all.optJSONObject(day(i)) ?: continue
            total += o.optInt("total")
            local += o.optInt("local")
        }
        return if (total == 0) 0 else (local * 100 / total)
    }

    fun requestsToday(): Int = days().optJSONObject(day())?.optInt("total") ?: 0

    /** Aprendizado acumulado: cada atalho ou fato guardado vale 4 pontos (até 100). */
    fun adaptation(): Int {
        val shortcuts = runCatching { Container.shortcuts.all().size }.getOrDefault(0)
        val facts = runCatching { Container.context.readMemory().lines().count { it.trimStart().startsWith("- [") } }.getOrDefault(0)
        return ((shortcuts + facts) * 4).coerceAtMost(100)
    }

    fun setDiagnostic(ok: Int, total: Int) {
        prefs?.edit()?.putInt("diag_ok", ok)?.putInt("diag_total", total)?.apply()
        main.post { version++ }
    }

    data class Integration(val percent: Int, val items: List<Pair<String, Boolean>>)

    /** Saúde do sistema, calculada sem internet a partir do estado real do celular. */
    fun integration(ctx: Context): Integration {
        val s = Container.settings
        val items = mutableListOf<Pair<String, Boolean>>()
        var score = 0
        val ias = runCatching { Container.router.activeProviders().size }.getOrDefault(0)
        if (ias >= 1) score += 30
        items += "Pelo menos 1 IA ativa" to (ias >= 1)
        if (ias >= 2) score += 10
        items += "2+ IAs (Conselho)" to (ias >= 2)
        val voiceOk = Container.voice.engines.firstOrNull { it.id == s.activeVoice() }?.available() == true
        if (voiceOk) score += 15
        items += "Voz escolhida pronta" to voiceOk
        val notif = ctx.getSystemService(NotificationManager::class.java)?.areNotificationsEnabled() == true
        if (notif) score += 15
        items += "Notificações liberadas" to notif
        val battery = ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) == true
        if (battery) score += 10
        items += "Bateria liberada" to battery
        val recentBackup = s.backupPassword().length >= 4 && System.currentTimeMillis() - s.lastBackup() < 7 * 86_400_000L
        if (recentBackup) score += 10
        items += "Backup nos últimos 7 dias" to recentBackup
        val p = prefs
        val diagTotal = p?.getInt("diag_total", 0) ?: 0
        val diagOk = p?.getInt("diag_ok", 0) ?: 0
        if (diagTotal > 0) score += 20 * diagOk / diagTotal
        items += "Último diagnóstico (${if (diagTotal == 0) "nunca rodou" else "$diagOk de $diagTotal"})" to (diagTotal > 0 && diagOk == diagTotal)
        return Integration(score.coerceIn(0, 100), items)
    }

    data class Point(val date: String, val adaptation: Int, val autonomy: Int)

    @Synchronized
    private fun snapshot() {
        val p = prefs ?: return
        val evo = JSONObject(p.getString("evolucao", "{}") ?: "{}")
        evo.put(day(), JSONObject().put("a", adaptation()).put("u", autonomy()))
        val keys = evo.keys().asSequence().sorted().toList()
        keys.dropLast(60).forEach { evo.remove(it) }
        p.edit().putString("evolucao", evo.toString()).apply()
    }

    fun evolution(): List<Point> {
        val evo = JSONObject(prefs?.getString("evolucao", "{}") ?: "{}")
        val fmt = SimpleDateFormat("dd/MM", Locale("pt", "BR"))
        val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return evo.keys().asSequence().sorted().map { k ->
            val o = evo.getJSONObject(k)
            val label = runCatching { fmt.format(parse.parse(k) ?: Date()) }.getOrDefault(k)
            Point(label, o.optInt("a"), o.optInt("u"))
        }.toList().takeLast(30)
    }
}
