package com.jeconias.nexo.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jeconias.nexo.core.Container
import com.jeconias.nexo.ui.ChatViewModel
import com.jeconias.nexo.ui.UiMessage
import com.jeconias.nexo.ui.rememberVoiceInput
import com.jeconias.nexo.ui.theme.NexoColors

@Composable
fun ChatScreen(vm: ChatViewModel, onBack: () -> Unit = {}) {
    var input by remember { mutableStateOf("") }
    var speak by remember { mutableStateOf(Container.settings.speakReplies()) }
    val listState = rememberLazyListState()

    val listen = rememberVoiceInput(vm)

    LaunchedEffect(vm.messages.size, vm.busy) {
        val count = vm.messages.size + if (vm.busy) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Column(Modifier.fillMaxSize()) {
        // Cabeçalho
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) { Text("‹ Núcleo", color = NexoColors.cyan, maxLines = 1) }
            Box(
                Modifier.size(10.dp).clip(CircleShape)
                    .background(if (vm.busy) NexoColors.amber else NexoColors.cyan)
            )
            Spacer(Modifier.size(8.dp))
            Text(
                "CONVERSA", color = NexoColors.text, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                letterSpacing = 3.sp, maxLines = 1, modifier = Modifier.weight(1f),
            )
            TextButton(onClick = {
                speak = !speak
                Container.settings.setSpeakReplies(speak)
                if (!speak) vm.stopSpeaking()
            }) { Text(if (speak) "🔊" else "🔇", fontSize = 18.sp) }
            TextButton(onClick = { vm.newSession() }) { Text("Nova", color = NexoColors.cyan, maxLines = 1) }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (vm.messages.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Às suas ordens, ${Container.settings.userName()}.", color = NexoColors.text, fontSize = 18.sp)
                        Spacer(Modifier.size(8.dp))
                        Text(
                            "Experimente:\n“me lembra daqui 10 minutos de tirar a roupa do varal”\n“pesquise a previsão do tempo para amanhã”\n“todo dia às 7h me dá um resumo das notícias”\n“lembra que eu tomo café sem açúcar”",
                            color = NexoColors.muted, fontSize = 13.sp,
                        )
                    }
                }
            }
            items(vm.messages) { m -> Bubble(m) }
            if (vm.busy) {
                item { com.jeconias.nexo.ui.BusyIndicator(vm) }
            }
        }

        // Entrada
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Fale ou escreva…") },
                maxLines = 4,
            )
            Button(
                onClick = listen,
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NexoColors.violet),
            ) { Text("🎙", fontSize = 20.sp) }
            Button(
                onClick = { vm.send(input); input = "" },
                enabled = !vm.busy && input.isNotBlank(),
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(52.dp),
            ) { Text("➤", fontSize = 20.sp) }
        }
    }
}

@Composable
private fun Bubble(m: UiMessage) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 320.dp).clip(shape)
                .background(
                    if (m.fromUser) Brush.linearGradient(listOf(NexoColors.cyan.copy(alpha = 0.25f), NexoColors.violet.copy(alpha = 0.20f)))
                    else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.04f)))
                )
                .border(1.dp, if (m.error) NexoColors.red else Color.White.copy(alpha = 0.12f), shape)
                .padding(12.dp)
        ) {
            Text(m.text, color = NexoColors.text, fontSize = 15.sp)
            if (m.meta.isNotBlank()) Text(m.meta, color = NexoColors.muted, fontSize = 10.sp)
        }
    }
}
