"""Executa código Python do Estúdio do NEXO, capturando a saída e os erros (com traceback)."""
import io
import os
import runpy
import sys
import tempfile
import traceback


def _capturar(funcao):
    buf = io.StringIO()
    antigo = (sys.stdout, sys.stderr)
    sys.stdout = sys.stderr = buf
    try:
        funcao()
    except SystemExit:
        pass
    except BaseException:
        traceback.print_exc()
    finally:
        sys.stdout, sys.stderr = antigo
    return buf.getvalue()


def executar(codigo):
    def rodar():
        exec(compile(codigo, "<nexo>", "exec"), {"__name__": "__main__"})
    return _capturar(rodar)


def executar_projeto(arquivos, principal):
    """arquivos: dict caminho -> conteúdo. Grava numa pasta temporária e executa o principal."""
    pasta = tempfile.mkdtemp(prefix="nexo_")
    for nome, conteudo in dict(arquivos).items():
        caminho = os.path.join(pasta, nome.replace("..", "").lstrip("/"))
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        with open(caminho, "w", encoding="utf-8") as f:
            f.write(conteudo)

    def rodar():
        sys.path.insert(0, pasta)
        for nome in list(dict(arquivos).keys()):
            sys.modules.pop(os.path.splitext(os.path.basename(nome))[0], None)
        antes = os.getcwd()
        os.chdir(pasta)
        try:
            runpy.run_path(os.path.join(pasta, principal), run_name="__main__")
        finally:
            os.chdir(antes)
            sys.path.remove(pasta)
    return _capturar(rodar)
