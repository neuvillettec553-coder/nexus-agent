package com.jeconias.nexo

import com.jeconias.nexo.life.FinanceMath
import com.jeconias.nexo.life.MoneyCoach
import com.jeconias.nexo.studio.CodeAssistant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Cálculos financeiros e leitura das respostas da IA (oportunidades e construtor). */
class LifeTest {
    private val txs = listOf(
        FinanceMath.Tx("2026-10-01", "entrada", 2500.0, "salário"),
        FinanceMath.Tx("2026-10-03", "gasto", 400.0, "mercado"),
        FinanceMath.Tx("2026-10-05", "gasto", 150.0, "transporte"),
        FinanceMath.Tx("2026-10-06", "entrada", 200.0, "renda extra"),
        FinanceMath.Tx("2026-09-28", "gasto", 999.0, "mercado"), // outro mês: não conta
    )

    @Test fun resumoDoMes() {
        val s = FinanceMath.summary(txs, "2026-10")
        assertEquals(2700.0, s.income, 0.001)
        assertEquals(550.0, s.expense, 0.001)
        assertEquals(2150.0, s.balance, 0.001)
        assertEquals(200.0, s.extraIncome, 0.001)
        assertEquals("mercado", s.byCategory.first().first)
    }

    @Test fun previsaoConsideraRitmoEContas() {
        val s = FinanceMath.summary(txs, "2026-10")
        // dia 10 de 30: ritmo 55/dia × 20 dias = 1100; contas 300 → 2150 - 1100 - 300 = 750
        assertEquals(750.0, FinanceMath.forecast(s, 10, 30, 300.0), 0.001)
    }

    @Test fun ordemDeQuitacao() {
        val d = listOf(FinanceMath.Debt("loja", 500.0, 50.0, 3.0), FinanceMath.Debt("cartão", 2000.0, 200.0, 12.0))
        assertEquals("cartão", FinanceMath.avalanche(d).first().creditor)
        assertEquals("loja", FinanceMath.snowball(d).first().creditor)
    }

    @Test fun parcelaQueNaoCobreJuros() {
        assertNull(FinanceMath.monthsToPay(2000.0, 100.0, 12.0)) // juros = 240 > 100
        assertEquals(10, FinanceMath.monthsToPay(1000.0, 100.0, 0.0))
    }

    @Test fun leValoresEscritos() {
        assertEquals(1200.5, FinanceMath.parseMoney("R$ 1.200,50")!!, 0.001)
        assertEquals(45.9, FinanceMath.parseMoney("45,90")!!, 0.001)
        assertEquals(10.0, FinanceMath.parseMoney("10")!!, 0.001)
        assertNull(FinanceMath.parseMoney("abc"))
    }

    @Test fun oportunidadesDaIA() {
        val resp = "Claro!\n```json\n{\"oportunidades\":[{\"titulo\":\"Sites para comércios\",\"primeiro_passo\":\"Listar 5 lojas\",\"retorno\":\"R$ 150 a 400\",\"tempo\":\"4h\",\"risco\":\"baixo\",\"tipo\":\"site\"}]}\n```"
        val list = MoneyCoach.parseOpportunities(resp)
        assertEquals(1, list.size)
        assertEquals("site", list.first().kind)
    }

    @Test fun planoDoConstrutor() {
        val resp = "{\"plano\":\"Vou criar a calculadora\",\"principal\":\"main.py\",\"mudancas\":[" +
            "{\"caminho\":\"main.py\",\"acao\":\"criar\",\"conteudo\":\"print(1)\"},{\"caminho\":\"../fora.py\",\"acao\":\"criar\",\"conteudo\":\"x\"}]}"
        val p = CodeAssistant.parseBuild(resp)
        assertEquals("main.py", p.main)
        assertEquals(2, p.changes.size)
        assertTrue(p.changes.none { it.path.contains("..") })
    }
}
