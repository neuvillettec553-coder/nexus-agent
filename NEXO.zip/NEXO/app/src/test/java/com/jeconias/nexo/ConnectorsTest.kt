package com.jeconias.nexo

import com.jeconias.nexo.agent.ToolSelector
import com.jeconias.nexo.connectors.GoogleServices
import com.jeconias.nexo.connectors.parseRows
import com.jeconias.nexo.tools.builtin.GoogleSearch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Seleção de ferramentas por pedido, leitura da Pesquisa Google e utilitários dos conectores. */
class ConnectorsTest {
    private val all = listOf(
        "data_hora", "buscar_web", "abrir_app", "fin_registrar", "fin_resumo", "gmail_buscar", "gmail_enviar",
        "mapa_rota", "planilha_criar", "mcp_ab12_query-docs", "github_repos", "tarefa_criar",
    )

    @Test fun pedidoSimplesLevaSoOBasico() {
        val s = ToolSelector.select("abre o youtube", all)
        assertTrue("abrir_app" in s)
        assertFalse("fin_registrar" in s)
        assertFalse("gmail_enviar" in s)
    }

    @Test fun dinheiroTrazFinancas() {
        val s = ToolSelector.select("gastei 45 reais no mercado", all)
        assertTrue("fin_registrar" in s && "fin_resumo" in s)
    }

    @Test fun emailERota() {
        assertTrue("gmail_buscar" in ToolSelector.select("tem e-mail novo do banco?", all))
        assertTrue("mapa_rota" in ToolSelector.select("como chego na rodoviária?", all))
    }

    @Test fun ferramentaJaUsadaContinua() {
        assertTrue("planilha_criar" in ToolSelector.select("e agora?", all, used = listOf("planilha_criar")))
    }

    @Test fun pesquisaGoogleComFontes() {
        val json = """{"candidates":[{"content":{"parts":[{"text":"Amanhã chove em Joinville."}]},
            "groundingMetadata":{"groundingChunks":[{"web":{"uri":"https://exemplo.com","title":"Clima"}}]}}]}"""
        val r = GoogleSearch.parse(json)
        assertNotNull(r)
        assertEquals("https://exemplo.com", r!!.sources.first().second)
    }

    @Test fun respostaSemFontesNaoContaComoPesquisa() {
        assertNull(GoogleSearch.parse("""{"candidates":[{"content":{"parts":[{"text":"acho que chove"}]}}]}"""))
    }

    @Test fun idDaPlanilhaPeloLink() {
        assertEquals(
            "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789",
            GoogleServices.idFrom("https://docs.google.com/spreadsheets/d/1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789/edit#gid=0"),
        )
    }

    @Test fun linhasDaPlanilha() {
        val rows = parseRows("""[["Data","Valor"],["07/10",45.5]]""")
        assertEquals(2, rows.size)
        assertEquals(45.5, rows[1][1])
    }
}
