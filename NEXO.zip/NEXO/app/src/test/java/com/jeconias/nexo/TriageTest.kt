package com.jeconias.nexo

import com.jeconias.nexo.agent.Orchestrator
import com.jeconias.nexo.providers.ProviderRouter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Triagem do Conselho e leitura dos avisos de modelo aposentado. */
class TriageTest {
    @Test fun conselhoQuandoPedido() {
        assertTrue(Orchestrator.asksCouncil("Alfredo, consulta o conselho sobre isso"))
        assertFalse(Orchestrator.asksCouncil("abre o youtube"))
    }

    @Test fun pedidoComplexo() {
        assertTrue(Orchestrator.isComplex("vale a pena trocar de celular agora?"))
        assertTrue(Orchestrator.isComplex("me ajuda a planejar a semana"))
        assertFalse(Orchestrator.isComplex("que horas são"))
    }

    @Test fun sugereModeloDoGemini() {
        val erro = "This model models/gemini-2.5-flash is no longer available to new users. " +
            "Please update your code to use models/gemini-3.8-flash for the latest"
        assertEquals("gemini-3.8-flash", ProviderRouter.suggestModel(erro))
    }

    @Test fun sugereModeloDoOpenRouter() {
        val erro = "This model is unavailable for free. The paid version is available now - use this slug instead: deepseek/deepseek-chat-v3-0324\",\"code\":404"
        assertEquals("deepseek/deepseek-chat-v3-0324", ProviderRouter.suggestModel(erro))
    }

    @Test fun semSugestao() {
        assertNull(ProviderRouter.suggestModel("Insufficient Balance"))
    }
}
