package com.jeconias.nexo

import com.jeconias.nexo.agent.LocalEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** O Motor Local precisa entender os comandos certos e IGNORAR os que não são comando. */
class LocalEngineTest {
    private val engine = LocalEngine(null)

    @Test fun horas() {
        assertEquals("data_hora", engine.match("Que horas são?")?.tool)
        assertEquals("data_hora", engine.match("Alfredo, que dia é hoje")?.tool)
    }

    @Test fun abrirApp() {
        val m = engine.match("Abre o YouTube")
        assertEquals("abrir_app", m?.tool)
        assertEquals("youtube", m?.args?.getString("nome"))
    }

    @Test fun alarmeComMinutos() {
        val m = engine.match("Coloca um alarme às 6:30")
        assertEquals("criar_alarme", m?.tool)
        assertEquals(6, m?.args?.getInt("hora"))
        assertEquals(30, m?.args?.getInt("minuto"))
    }

    @Test fun alarmeEMeia() {
        val m = engine.match("despertador às 7 e meia")
        assertEquals(7, m?.args?.getInt("hora"))
        assertEquals(30, m?.args?.getInt("minuto"))
    }

    @Test fun naoCriaAlarmeQuandoSoPergunta() {
        assertNull(engine.match("qual alarme eu coloquei para 6 horas?"))
    }

    @Test fun lembreteEmHoras() {
        val m = engine.match("me lembra em 2 horas de ligar pro mecânico")
        assertEquals("criar_lembrete", m?.tool)
        assertEquals(120, m?.args?.getInt("minutos"))
        assertEquals("ligar pro mecanico", m?.args?.getString("mensagem"))
    }

    @Test fun anotar() {
        val m = engine.match("anota comprar parafuso 8mm")
        assertEquals("anotar", m?.tool)
        assertTrue(m!!.args.getString("texto").contains("parafuso"))
    }

    @Test fun pedidoAbertoVaiParaIA() {
        assertNull(engine.match("me ajuda a planejar as compras do mês"))
    }

    @Test fun pararECorrecao() {
        assertTrue(LocalEngine.isStop("Para!"))
        assertTrue(LocalEngine.isCorrection("não era isso"))
        assertFalse(LocalEngine.isCorrection("abre o whatsapp"))
    }
}
