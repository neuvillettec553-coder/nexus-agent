package com.jeconias.nexo

import com.jeconias.nexo.backup.BackupManager
import com.jeconias.nexo.studio.CodeAssistant
import com.jeconias.nexo.studio.Language
import com.jeconias.nexo.studio.Tokenizer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Estúdio (cores, leitura das respostas da IA) e criptografia do backup. */
class StudioTest {
    @Test fun linguagemPeloNome() {
        assertEquals(Language.PYTHON, Language.of("main.py"))
        assertEquals(Language.HTML, Language.of("index.HTML"))
        assertEquals(Language.TEXT, Language.of("LEIAME"))
    }

    @Test fun coresPython() {
        val code = "def soma(a, b):\n    # comentário\n    return a + 2  # fim\nprint(\"ok\")"
        val types = Tokenizer.tokenize(code, Language.PYTHON).map { code.substring(it.start, it.end) to it.type }
        assertTrue(("def" to Tokenizer.Type.KEYWORD) in types)
        assertTrue(("# comentário" to Tokenizer.Type.COMMENT) in types)
        assertTrue(("2" to Tokenizer.Type.NUMBER) in types)
        assertTrue(("\"ok\"" to Tokenizer.Type.STRING) in types)
    }

    @Test fun coresJavaScriptComentarioNaoViraTexto() {
        val code = "// diz 'oi'\nconst x = 'a';"
        val first = Tokenizer.tokenize(code, Language.JAVASCRIPT).first()
        assertEquals(Tokenizer.Type.COMMENT, first.type)
    }

    @Test fun extraiUltimoBlocoDeCodigo() {
        val resp = "Corrigi o erro.\n```python\nprint('a')\n```\nE também:\n```python\nprint('b')\n```"
        assertEquals("print('b')", CodeAssistant.extractCode(resp))
    }

    @Test fun projetoDaIAComTextoEmVolta() {
        val resp = "Aqui está:\n```json\n{\"nome\": \"calc\", \"arquivos\": [{\"caminho\": \"main.py\", \"conteudo\": \"print(1)\"}]}\n```"
        val (name, files) = CodeAssistant.parseScaffold(resp)
        assertEquals("calc", name)
        assertEquals("print(1)", files["main.py"])
    }

    @Test fun backupCriptografaEDescriptografa() {
        val data = "memória do Alfredo".toByteArray()
        val enc = BackupManager.encrypt(data, "senha123")
        assertArrayEquals(data, BackupManager.decrypt(enc, "senha123"))
    }

    @Test fun backupRecusaSenhaErrada() {
        val enc = BackupManager.encrypt("x".toByteArray(), "certa")
        try {
            BackupManager.decrypt(enc, "errada")
            fail("Deveria recusar a senha errada")
        } catch (_: IllegalArgumentException) {
        }
    }
}
