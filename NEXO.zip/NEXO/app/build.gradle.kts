plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.chaquo.python") // Python 3.11 embutido: roda sem internet, dentro do app
}

// Número da compilação do GitHub = número da versão (igual ao Alfredo)
val buildNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "com.jeconias.nexo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jeconias.nexo"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
        // O Python embutido precisa saber a arquitetura do celular (o Realme C85 é arm64).
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // Chave fixa: toda versão nova instala por cima da anterior sem desinstalar
    signingConfigs {
        create("nexo") {
            storeFile = file("../keystore/nexo.jks")
            storePassword = "nexo2026alfredo"
            keyAlias = "nexo"
            keyPassword = "nexo2026alfredo"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("nexo")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("nexo")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        pyc { src = false } // não exige Python instalado na máquina que compila
    }
}

// Profissional: o APK só é gerado se TODOS os testes automáticos passarem.
afterEvaluate {
    tasks.named("assembleRelease").configure { dependsOn("testReleaseUnitTest") }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.luaj:luaj-jse:3.0.1") // interpretador Lua (Java puro, sem internet)
    implementation("androidx.biometric:biometric:1.1.0") // trava por digital (Finanças)
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("com.google.android.gms:play-services-auth:21.2.0") // login Google (Gmail)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
