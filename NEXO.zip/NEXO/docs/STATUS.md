# Status real (versão inicial)

Legenda: IMPLEMENTADO = código pronto, confirmar com o teste · EXPERIMENTAL = funciona com limites · PRÓXIMA FASE = não existe ainda.

| Função | Status | Teste no celular |
|---|---|---|
| Estúdio de programação (projetos, editor, histórico, exportar zip) | IMPLEMENTADO | aba Estúdio |
| Executar Python, JavaScript, Lua, SQL, Shell + prévia HTML/CSS | IMPLEMENTADO | ▶ Rodar no Estúdio |
| IA no editor: explicar, corrigir, melhorar, testes, documentar, revisar | IMPLEMENTADO | 🤖 IA no Estúdio |
| Rodar e corrigir automático (3 tentativas) | IMPLEMENTADO | 🔁 no Estúdio |
| Testes automáticos antes do APK | IMPLEMENTADO | GitHub Actions |
| Executar Java/C/C++/Kotlin/Go/Rust/PHP | PRÓXIMA FASE | precisa de serviço externo |
| Motor Local que aprende atalhos | IMPLEMENTADO | "que horas são", "abre o YouTube", "anota…" → via Motor Local |
| Conselho de IAs + painel FLUXO | IMPLEMENTADO | "consulta o conselho: …" com 2+ IAs |
| Confirmação de ações sensíveis | IMPLEMENTADO | pedir um WhatsApp → "Posso fazer isso?" |
| Backup criptografado | IMPLEMENTADO | Sistema → Backup |
| Diagnóstico automático | IMPLEMENTADO | Sistema → Rodar diagnóstico |
| Pausa de IA sem saldo/limite | IMPLEMENTADO | aba IAs mostra "Em pausa até…" |
| Pesquisa Google via Gemini + DuckDuckGo de reserva | IMPLEMENTADO | perguntar algo atual |
| Drive, Planilhas, Docs, YouTube | IMPLEMENTADO | ativar APIs e reconectar Google |
| Rotas e lugares (abre o Google Maps) | IMPLEMENTADO | “como chego em…” |
| Seleção de ferramentas por pedido, IA lenta abandonada em 40 s, botão Parar | IMPLEMENTADO | conversa |
| Central Financeira (3 frentes + metas, trava por digital) | IMPLEMENTADO | PREDICT → FINANCE CORE |
| Vida: tarefas, hábitos, metas, diário, revisão semanal | IMPLEMENTADO | PREDICT → LIFE |
| Agenda do celular + Resumo da manhã | IMPLEMENTADO | PREDICT |
| Memória por assuntos + revisão semanal com cópia de segurança | IMPLEMENTADO | Cérebro |
| Estúdio por conversa (construtor) + envio ao GitHub | IMPLEMENTADO | Estúdio |
| Conectores: Gmail (OAuth), GitHub (token), MCP com permissões | IMPLEMENTADO | MODELS → CONNECTORS |
| Interface Cognitive Core (COGNITIVE/MODELS/PREDICT/LOG) com painéis projetados | IMPLEMENTADO | tocar nas placas |
| Métricas reais: Autonomia, Adaptação, Integração, Evolução | IMPLEMENTADO | painel EVOLUTION e SYSTEM INTEGRATION |
| Várias IAs com troca automática | IMPLEMENTADO | Desligar a 1ª IA e mandar mensagem |
| AGENTS.md + MEMORY.md a cada mensagem | IMPLEMENTADO | Escrever um fato em MEMORY.md e perguntar |
| Memória evolutiva (`lembrar`) | IMPLEMENTADO | "lembra que…" e conferir MEMORY.md |
| Lembretes | IMPLEMENTADO | "me lembra daqui 2 minutos…" |
| Alarme | IMPLEMENTADO | "alarme às 6:30" e conferir no Relógio |
| Abrir apps | IMPLEMENTADO | "abre o YouTube" |
| Pesquisa na web | IMPLEMENTADO | "pesquise…" (pode falhar se o DuckDuckGo bloquear) |
| Rotinas | IMPLEMENTADO | "a cada 1 hora…" |
| Skills | IMPLEMENTADO | "use a skill lista-de-compras…" |
| Notas | IMPLEMENTADO | "anota…" / "o que eu anotei?" |
| WhatsApp com texto pronto | IMPLEMENTADO | o usuário só toca em enviar |
| Voz escolhível (Gemini, ElevenLabs, celular) | IMPLEMENTADO | aba Voz → Testar → Usar |
| Parada após 2 falhas | IMPLEMENTADO | pedir 2x um app que não existe |
| Registro de ações | IMPLEMENTADO | aba Sistema |
| MCP (servidores remotos) | EXPERIMENTAL | adicionar URL e Conectar |
| Modo 24/7 | EXPERIMENTAL | depende da bateria da Realme |
| Edge-TTS | PRÓXIMA FASE | — |
| Controle de tela (acessibilidade) | PRÓXIMA FASE | — |
| Palavra de ativação ("Alfredo") | PRÓXIMA FASE | — |
| Gmail nativo | PRÓXIMA FASE | hoje só via MCP |

Observação: esta versão foi escrita sem poder compilar no ambiente de criação.
A primeira compilação no GitHub é o primeiro teste real.
