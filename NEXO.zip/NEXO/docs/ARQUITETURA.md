# Arquitetura do NEXO

## Triagem (Orchestrator)
1. **Motor Local** (`agent/LocalEngine.kt`): regras fixas + atalhos aprendidos. Instantâneo e sem IA.
2. **Conselho** (`agent/Orchestrator.kt`): Estrategista (1ª IA) → Crítico (2ª IA) → Juiz (3ª IA). Só em pedidos
   complexos ou quando pedido, com limite diário. Se o Juiz marcar `AÇÃO: SIM`, o agente executa a decisão.
3. **Uma IA** (`agent/AgentLoop.kt`): o loop normal. Pedido simples resolvido com 1 ação vira atalho.
Tudo é registrado em `core/FlowLog.kt` e aparece no painel FLUXO.

## Níveis de confirmação
READ (faz na hora) · ACT (faz e avisa) · SENSITIVE (sempre pergunta). Rotinas automáticas nunca executam SENSITIVE.

## Fluxo de uma mensagem
1. **Conversa (ui)** recebe texto ou voz e chama o **AgentLoop**.
2. **Observar**: `ContextStore` monta o prompt com AGENTS.md + MEMORY.md + lista de skills + data/hora.
3. **Pensar**: `ProviderRouter` envia para a 1ª IA da lista. Se der erro, cota ou queda, tenta a próxima.
4. **Agir**: se a IA pedir ferramentas, o `ToolRegistry` executa cada uma. Tudo vai para o `ActionLog`.
5. **Avaliar**: o resultado volta marcado como SUCESSO ou FALHOU. A IA decide o próximo passo.
   Até 10 passos. Duas falhas seguidas = para e pergunta.
6. A resposta aparece na tela e passa pelo `VoiceManager` (voz escolhida → outras → voz do celular).

## Regras de organização
- Cada pasta tem uma responsabilidade só. Uma tela nunca fala direto com uma IA: passa pelo agente.
- Provedores novos: só acrescentar uma linha em `ProviderCatalog` se a API for no padrão OpenAI.
- Ferramentas novas: criar a classe em `tools/builtin/` e registrar em `BuiltinTools`.
- Ferramentas MCP entram sozinhas com o prefixo `mcp_<id>_`.
- Toda ferramenta devolve `ToolResult(ok, output)`. `ok` só é true se a ação aconteceu de verdade.

## Onde ficam os dados (no celular)
- `files/contexto/AGENTS.md` e `MEMORY.md`
- `files/skills/*.md`
- `files/notas/*.txt`
- `files/logs/acoes.log`
- Chaves e preferências: SharedPreferences `nexo_settings` (só no aparelho)
