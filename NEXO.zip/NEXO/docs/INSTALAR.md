# Como instalar o NEXO

1. Crie um repositório **privado** no GitHub chamado `NEXO`.
2. Envie todos os arquivos desta pasta para ele (mantendo as pastas).
3. A compilação começa sozinha (aba **Actions**). Leva uns 5 a 8 minutos.
4. Quando terminar, vá em **Lançamentos (Releases)** → `NEXO <número>` → baixe o `.apk` no celular.
5. Instale. Na primeira vez, o Android pede para permitir instalar de fonte desconhecida.

## Registro do pacote (regra de verificação de desenvolvedor)
No Android Developer Console, registre o pacote novo **com.jeconias.nexo**, do mesmo
jeito que foi feito com o Alfredo. Se pedir a impressão digital da chave de assinatura:

SHA-256: 50:F3:AB:93:F6:48:B5:59:F3:E8:FA:E6:08:6F:B1:68:31:23:54:22:E1:E3:7F:BB:65:D9:FF:6D:52:D0:EF:99

## Primeiro uso
1. Aba **IAs**: cole pelo menos uma chave (Groq e Gemini são grátis). Toque em **Testar**.
2. Aba **Voz**: toque em **Testar** e depois em **Usar esta voz**.
3. Aba **Sistema**: ligue o **Modo 24/7** e toque em **Liberar bateria**.
   Na Realme, também vale: Configurações → Bateria → NEXO → permitir atividade em segundo plano.
4. Aba **Conversa**: fale com o Alfredo.

## Se a compilação falhar
Abra a execução com X vermelho em **Actions**, copie as últimas linhas do erro e mande
para correção. A versão seguinte sai com o número novo.
